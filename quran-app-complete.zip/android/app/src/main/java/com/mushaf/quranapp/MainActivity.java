package com.mushaf.quranapp;

import android.os.Bundle;
import android.util.Log;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;

public class MainActivity extends BridgeActivity {
    private static final String TAG = "UnityAds";
    public static final String UNITY_GAME_ID = "800394591";
    private static final boolean TEST_MODE = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize Unity Ads SDK with Game ID: 800394591
        UnityAds.initialize(getApplicationContext(), UNITY_GAME_ID, TEST_MODE, new IUnityAdsInitializationListener() {
            @Override
            public void onInitializationComplete() {
                Log.d(TAG, "Unity Ads initialized successfully with Game ID: " + UNITY_GAME_ID);
                // Pre-load default interstitial ad placement
                UnityAds.load("Interstitial_Android", new IUnityAdsLoadListener() {
                    @Override
                    public void onUnityAdsAdLoaded(String placementId) {
                        Log.d(TAG, "Unity Ad loaded: " + placementId);
                    }

                    @Override
                    public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {
                        Log.w(TAG, "Unity Ad load failed for " + placementId + ": " + message);
                    }
                });
            }

            @Override
            public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
                Log.e(TAG, "Unity Ads initialization failed: [" + error + "] " + message);
            }
        });

        // Register JavaScript interface for WebView
        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().addJavascriptInterface(new UnityAdsBridge(), "AndroidUnityAds");
        }
    }

    public class UnityAdsBridge {
        @JavascriptInterface
        public String getGameId() {
            return UNITY_GAME_ID;
        }

        @JavascriptInterface
        public boolean isInitialized() {
            return UnityAds.isInitialized();
        }

        @JavascriptInterface
        public void loadAd(String placementId) {
            UnityAds.load(placementId, new IUnityAdsLoadListener() {
                @Override
                public void onUnityAdsAdLoaded(String placementId) {
                    Log.d(TAG, "Unity Ad ready: " + placementId);
                }

                @Override
                public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {
                    Log.w(TAG, "Unity Ad failed: " + placementId + ", " + message);
                }
            });
        }

        @JavascriptInterface
        public void showAd(String placementId) {
            runOnUiThread(() -> {
                UnityAds.show(MainActivity.this, placementId, new UnityAdsShowOptions(), new IUnityAdsShowListener() {
                    @Override
                    public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {
                        Log.e(TAG, "Unity Ad show failure: " + placementId + " - " + message);
                    }

                    @Override
                    public void onUnityAdsShowStart(String placementId) {
                        Log.d(TAG, "Unity Ad started: " + placementId);
                    }

                    @Override
                    public void onUnityAdsShowClick(String placementId) {
                        Log.d(TAG, "Unity Ad clicked: " + placementId);
                    }

                    @Override
                    public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
                        Log.d(TAG, "Unity Ad completed: " + placementId + " with state: " + state);
                    }
                });
            });
        }
    }
}
