@echo off
echo === 1. Building Vite Production Web Bundle ===
call npm run build

echo === 2. Syncing Capacitor Android Assets & Plugins ===
call npx cap sync android

echo === 3. Compiling Android APK with Gradle ===
cd android
call gradlew.bat assembleDebug
cd ..

echo === SUCCESS! APK built at: android\app\build\outputs\apk\debug\app-debug.apk ===
