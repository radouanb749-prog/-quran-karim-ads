#!/usr/bin/env bash
# Script to build APK directly using Gradle CLI without Android Studio
set -e

echo "=== 1. Building Vite Production Web Bundle ==="
npm run build

echo "=== 2. Syncing Capacitor Android Assets & Plugins ==="
npx cap sync android

echo "=== 3. Compiling Android APK with Gradle ==="
cd android
chmod +x ./gradlew
./gradlew assembleDebug

echo "=== SUCCESS! APK built at: android/app/build/outputs/apk/debug/app-debug.apk ==="
