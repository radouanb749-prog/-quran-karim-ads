import React, { useState, useEffect, useMemo } from 'react';
import { Search, X, Sun, Moon, Compass, Heart, Sparkles, ArrowLeft, CircleDot } from 'lucide-react';
import { SURAHS, Surah } from './data/surahs';
import { Header } from './components/Header';
import { ContinueReadingCard } from './components/ContinueReadingCard';
import { SurahCard } from './components/SurahCard';
import { SurahReader } from './components/SurahReader';
import { SurahDetailsModal } from './components/SurahDetailsModal';
import { ShareModal } from './components/ShareModal';
import { AdhkarSection } from './components/adhkar/AdhkarSection';
import { KhatmahSection } from './components/khatmah/KhatmahSection';
import { KhatmahHomeCard } from './components/khatmah/KhatmahHomeCard';
import { TasbihSection } from './components/tasbih/TasbihSection';
import { FavoriteVersesSidebar } from './components/FavoriteVersesSidebar';
import { executeShare } from './services/shareService';
import { getFavoriteDhikrIds } from './services/adhkarService';
import { getFavoriteVerses, subscribeToFavoriteVersesChange } from './services/favoriteVersesService';
import { updateKhatmahProgressPage } from './services/khatmahService';
import { 
  getGlobalLastRead, 
  getAllSurahProgress, 
  saveSurahProgress,
  getSurahSavedVerse
} from './services/bookmarkService';
import { App as CapApp } from '@capacitor/app';
import { StatusBar, Style as StatusBarStyle } from '@capacitor/status-bar';
import { unityAds } from './services/unityAdsService';

export default function App() {
  // 1. Dark Mode State & Initialization
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('mushaf_theme');
      if (savedTheme) {
        return savedTheme === 'dark';
      }
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
      localStorage.setItem('mushaf_theme', 'dark');
      StatusBar.setStyle({ style: StatusBarStyle.Dark }).catch(() => {});
      StatusBar.setBackgroundColor({ color: '#0c0a09' }).catch(() => {});
    } else {
      root.classList.remove('dark');
      localStorage.setItem('mushaf_theme', 'light');
      StatusBar.setStyle({ style: StatusBarStyle.Light }).catch(() => {});
      StatusBar.setBackgroundColor({ color: '#064e3b' }).catch(() => {});
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode((prev) => !prev);
  };

  // Section State: 'quran', 'adhkar', 'khatmah', or 'tasbih'
  const [activeSection, setActiveSection] = useState<'quran' | 'adhkar' | 'khatmah' | 'tasbih'>('quran');
  const [adhkarInitialTab, setAdhkarInitialTab] = useState<'morning' | 'evening' | 'after_prayer' | 'favorites'>('morning');
  const [favoriteAdhkarCount, setFavoriteAdhkarCount] = useState<number>(() => {
    return getFavoriteDhikrIds().length;
  });

  // Favorite Verses Drawer State
  const [isFavoriteVersesOpen, setIsFavoriteVersesOpen] = useState(false);
  const [favoriteVersesCount, setFavoriteVersesCount] = useState<number>(() => {
    return getFavoriteVerses().length;
  });

  useEffect(() => {
    unityAds.init();
    const updateFavoritesCount = () => {
      setFavoriteVersesCount(getFavoriteVerses().length);
    };
    const unsubscribe = subscribeToFavoriteVersesChange(updateFavoritesCount);
    return () => unsubscribe();
  }, []);

  const handleSelectFavoriteVerse = (surahNumber: number, verseNumber: number) => {
    const target = SURAHS.find((s) => s.number === surahNumber);
    if (target) {
      setActiveSection('quran');
      handleOpenReading(target, verseNumber);
      setIsFavoriteVersesOpen(false);
    }
  };

  const handleOpenAdhkarCategory = (tab: 'morning' | 'evening' | 'after_prayer' | 'favorites') => {
    setAdhkarInitialTab(tab);
    setReadingSurah(null);
    setActiveSection('adhkar');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // 2. Per-Surah Progress Map & Last Read Global State
  const [surahProgressMap, setSurahProgressMap] = useState<Record<number, number>>(() => {
    return getAllSurahProgress();
  });

  const [lastReadSurah, setLastReadSurah] = useState<Surah>(() => {
    const globalProgress = getGlobalLastRead();
    if (globalProgress) {
      const found = SURAHS.find((s) => s.number === globalProgress.surahNumber);
      if (found) return found;
    }
    return SURAHS[0]; // Default: Al-Fatihah
  });

  const [lastReadVerse, setLastReadVerse] = useState<number | null>(() => {
    const globalProgress = getGlobalLastRead();
    return globalProgress ? globalProgress.verseNumber : null;
  });

  // Target verse to scroll to when opening reader
  const [targetVerseForReader, setTargetVerseForReader] = useState<number | null>(null);

  const handleSetBookmark = (surah: Surah, verseNumber?: number) => {
    const actualVerse = verseNumber || surahProgressMap[surah.number] || 1;
    setLastReadSurah(surah);
    setLastReadVerse(actualVerse);
    saveSurahProgress(surah.number, actualVerse);
    setSurahProgressMap((prev) => ({
      ...prev,
      [surah.number]: actualVerse,
    }));
    updateKhatmahProgressPage(surah.page);
  };

  // 3. Active Reading State: whether user is on the reading page or home index
  const [readingSurah, setReadingSurah] = useState<Surah | null>(null);

  const handleOpenReading = (surah: Surah, targetVerse?: number) => {
    // If targetVerse not specified, check if there's a saved verse for this surah
    const savedVerse = targetVerse ?? getSurahSavedVerse(surah.number);
    setTargetVerseForReader(savedVerse);
    setReadingSurah(surah);
    handleSetBookmark(surah, savedVerse || 1);
  };

  // 4. Search and Type Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'مكية' | 'مدنية'>('all');

  // Normalize Arabic text for reliable search (handling hamza variations, alef, etc.)
  const normalizeArabic = (text: string) => {
    return text
      .trim()
      .replace(/[إأآا]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .replace(/[\u064B-\u065F\u0670]/g, ''); // strip diacritics
  };

  // 5. Filtered Surahs List
  const filteredSurahs = useMemo(() => {
    const query = normalizeArabic(searchQuery.toLowerCase());

    return SURAHS.filter((surah) => {
      // Filter by type
      if (typeFilter !== 'all' && surah.type !== typeFilter) {
        return false;
      }

      // Filter by search query
      if (!query) return true;

      const normalizedSurahName = normalizeArabic(surah.name);
      const numberMatches = surah.number.toString() === query;
      const arabicNameMatches = normalizedSurahName.includes(query);
      const englishNameMatches = surah.englishName.toLowerCase().includes(query.toLowerCase());

      return numberMatches || arabicNameMatches || englishNameMatches;
    });
  }, [searchQuery, typeFilter]);

  // Modal details state (if user opens modal directly)
  const [modalSurah, setModalSurah] = useState<Surah | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  const handleShareApp = () => {
    executeShare(
      {
        title: 'القرآن الكريم',
        text: 'اقرأ القرآن الكريم برواية ورش',
      },
      () => {
        // Fallback when Web Share API is unavailable
        setIsShareModalOpen(true);
      }
    );
  };

  const handleNavigateModalSurah = (direction: 'next' | 'prev') => {
    if (!modalSurah) return;
    const targetNumber = direction === 'next' ? modalSurah.number + 1 : modalSurah.number - 1;
    const found = SURAHS.find((s) => s.number === targetNumber);
    if (found) {
      setModalSurah(found);
    }
  };

  // Android Hardware / Gesture Back Button Handler
  useEffect(() => {
    let backListener: { remove: () => void } | null = null;
    CapApp.addListener('backButton', () => {
      if (isModalOpen) {
        setIsModalOpen(false);
      } else if (isShareModalOpen) {
        setIsShareModalOpen(false);
      } else if (isFavoriteVersesOpen) {
        setIsFavoriteVersesOpen(false);
      } else if (readingSurah) {
        setReadingSurah(null);
        setSurahProgressMap(getAllSurahProgress());
      } else if (activeSection !== 'quran') {
        setActiveSection('quran');
      } else {
        CapApp.exitApp().catch(() => {});
      }
    }).then((handle) => {
      backListener = handle;
    }).catch(() => {});

    return () => {
      if (backListener) {
        backListener.remove();
      }
    };
  }, [isModalOpen, isShareModalOpen, isFavoriteVersesOpen, readingSurah, activeSection]);

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900 dark:bg-stone-950 dark:text-stone-100 transition-colors duration-200" dir="rtl">
      {/* Top Header - shown when browsing index or adhkar */}
      {!readingSurah && (
        <Header 
          darkMode={darkMode} 
          toggleDarkMode={toggleDarkMode}
          onShare={handleShareApp}
          activeSection={activeSection}
          onSectionChange={(sec) => {
            setActiveSection(sec);
            setReadingSurah(null);
            setFavoriteAdhkarCount(getFavoriteDhikrIds().length);
          }}
          favoriteAdhkarCount={favoriteAdhkarCount}
          favoriteVersesCount={favoriteVersesCount}
          onOpenFavoriteVerses={() => setIsFavoriteVersesOpen(true)}
          onLogoClick={() => {
            setReadingSurah(null);
            setActiveSection('quran');
            // Refresh progress map from storage
            setSurahProgressMap(getAllSurahProgress());
          }}
        />
      )}

      {/* Main View Area */}
      {readingSurah ? (
        /* Reading Page View: Reads authentic verses from Tanzil Uthmani (Version 1.1) */
        <main className="flex-1 w-full">
          <SurahReader
            surah={readingSurah}
            targetVerse={targetVerseForReader}
            onBack={() => {
              setReadingSurah(null);
              // Refresh map when returning to list
              setSurahProgressMap(getAllSurahProgress());
            }}
            onSelectSurah={(s, v) => handleOpenReading(s, v)}
            isBookmarked={lastReadSurah.number === readingSurah.number}
            onBookmark={(s, v) => handleSetBookmark(s, v)}
            darkMode={darkMode}
            toggleDarkMode={toggleDarkMode}
            onShare={handleShareApp}
          />
        </main>
      ) : activeSection === 'adhkar' ? (
        /* Dedicated Adhkar Section */
        <main className="flex-1 w-full">
          <AdhkarSection
            initialTab={adhkarInitialTab}
            onBackToQuran={() => setActiveSection('quran')}
          />
        </main>
      ) : activeSection === 'khatmah' ? (
        /* Dedicated Khatmah & Stats Section */
        <main className="flex-1 w-full">
          <KhatmahSection
            onBackToQuran={() => setActiveSection('quran')}
            onNavigateToSurahPage={(surah, verse) => handleOpenReading(surah, verse)}
            onOpenFavoriteVerses={() => setIsFavoriteVersesOpen(true)}
          />
        </main>
      ) : activeSection === 'tasbih' ? (
        /* Dedicated Electronic Tasbih Section */
        <main className="flex-1 w-full">
          <TasbihSection
            onBackToQuran={() => setActiveSection('quran')}
          />
        </main>
      ) : (
        /* Home Surahs Index View */
        <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-7">
          
          {/* Continue Reading Card */}
          <ContinueReadingCard
            lastReadSurah={lastReadSurah}
            lastReadVerseNumber={lastReadVerse || surahProgressMap[lastReadSurah.number] || null}
            onContinue={(surah, verse) => handleOpenReading(surah, verse)}
          />

          {/* Quran Khatmah Plan Hero Card */}
          <KhatmahHomeCard
            onOpenKhatmahSection={() => {
              setActiveSection('khatmah');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onReadWard={(surah, verse) => handleOpenReading(surah, verse)}
          />

          {/* Quick Adhkar Access Bar */}
          <section aria-label="الوصول السريع للأذكار" className="bg-white dark:bg-stone-900 rounded-2xl p-4 border border-stone-200 dark:border-stone-800 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950/70 flex items-center justify-center text-amber-700 dark:text-amber-400">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-stone-900 dark:text-stone-100">
                    الأذكار اليومية والأدعية المأثورة
                  </h2>
                  <p className="text-[11px] text-stone-500 dark:text-stone-400">
                    أذكار الصباح والمساء وبعد الصلاة مع مسبحة إلكترونية وحفظ المفضلة
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleOpenAdhkarCategory('morning')}
                className="text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:underline self-end sm:self-auto"
              >
                فتح قسم الأذكار ←
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              <button
                type="button"
                onClick={() => handleOpenAdhkarCategory('morning')}
                className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 hover:bg-amber-50 dark:hover:bg-amber-950/30 text-stone-800 dark:text-stone-200 border border-stone-200/80 dark:border-stone-700 text-xs font-semibold transition-all group active:scale-95"
              >
                <Sun className="w-3.5 h-3.5 text-amber-500 group-hover:scale-110 transition-transform" />
                <span>أذكار الصباح</span>
              </button>

              <button
                type="button"
                onClick={() => handleOpenAdhkarCategory('evening')}
                className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 text-stone-800 dark:text-stone-200 border border-stone-200/80 dark:border-stone-700 text-xs font-semibold transition-all group active:scale-95"
              >
                <Moon className="w-3.5 h-3.5 text-indigo-500 group-hover:scale-110 transition-transform" />
                <span>أذكار المساء</span>
              </button>

              <button
                type="button"
                onClick={() => handleOpenAdhkarCategory('after_prayer')}
                className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 text-stone-800 dark:text-stone-200 border border-stone-200/80 dark:border-stone-700 text-xs font-semibold transition-all group active:scale-95"
              >
                <Compass className="w-3.5 h-3.5 text-emerald-600 group-hover:scale-110 transition-transform" />
                <span>بعد الصلاة</span>
              </button>

              <button
                type="button"
                onClick={() => handleOpenAdhkarCategory('favorites')}
                className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-stone-800 dark:text-stone-200 border border-stone-200/80 dark:border-stone-700 text-xs font-semibold transition-all group active:scale-95"
              >
                <Heart className="w-3.5 h-3.5 text-rose-500 group-hover:scale-110 transition-transform fill-rose-500/20" />
                <span>المفضلة</span>
                {favoriteAdhkarCount > 0 && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-bold">
                    {favoriteAdhkarCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveSection('tasbih');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-stone-50 dark:bg-stone-800/80 hover:bg-amber-50 dark:hover:bg-amber-950/30 text-stone-800 dark:text-stone-200 border border-stone-200/80 dark:border-stone-700 text-xs font-semibold transition-all group active:scale-95 col-span-2 sm:col-span-1"
              >
                <CircleDot className="w-3.5 h-3.5 text-amber-500 group-hover:scale-110 transition-transform" />
                <span>السبحة الإلكترونية</span>
              </button>
            </div>
          </section>

          {/* Favorite Verses Quick Access Banner */}
          {favoriteVersesCount > 0 && (
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 sm:p-4 rounded-2xl bg-rose-50/80 dark:bg-rose-950/25 border border-rose-200/80 dark:border-rose-900/50 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-rose-100 dark:bg-rose-900/60 flex items-center justify-center text-rose-600 dark:text-rose-400 shrink-0">
                  <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-rose-950 dark:text-rose-200">
                    لديك {favoriteVersesCount.toLocaleString('ar-EG')} آيات محفوظة في قائمة المفضلة
                  </h3>
                  <p className="text-[11px] text-rose-700/80 dark:text-rose-300/80">
                    يمكنك استعراضها والعودة لتلاوتها وتدبرها في أي وقت من القائمة الجانبية
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsFavoriteVersesOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-xs transition-colors self-end sm:self-auto shrink-0 active:scale-95"
              >
                <span>عرض الآيات المفضلة</span>
                <ArrowLeft className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Search & Filters Section */}
          <section aria-label="البحث والتصفية" className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
              
              {/* Search Input Box */}
              <div className="relative flex-1">
                <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-stone-400 dark:text-stone-500">
                  <Search className="w-4 h-4 stroke-[2]" />
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث عن اسم السورة أو رقمها..."
                  className="w-full pl-9 pr-10 py-2.5 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 text-sm placeholder-stone-400 dark:placeholder-stone-500 text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-700/50 dark:focus:ring-emerald-500/50 transition-all shadow-xs"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    aria-label="مسح البحث"
                    className="absolute inset-y-0 left-0 pl-3 flex items-center text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Classification Filter Tabs: الكل / مكية / مدنية */}
              <div className="flex items-center gap-1.5 p-1 rounded-xl bg-stone-200/60 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => setTypeFilter('all')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    typeFilter === 'all'
                      ? 'bg-white dark:bg-stone-800 text-emerald-800 dark:text-emerald-300 shadow-xs'
                      : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
                  }`}
                >
                  الكل ({SURAHS.length})
                </button>
                <button
                  type="button"
                  onClick={() => setTypeFilter('مكية')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    typeFilter === 'مكية'
                      ? 'bg-white dark:bg-stone-800 text-emerald-800 dark:text-emerald-300 shadow-xs'
                      : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
                  }`}
                >
                  مكية (٨٦)
                </button>
                <button
                  type="button"
                  onClick={() => setTypeFilter('مدنية')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    typeFilter === 'مدنية'
                      ? 'bg-white dark:bg-stone-800 text-emerald-800 dark:text-emerald-300 shadow-xs'
                      : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
                  }`}
                >
                  مدنية (٢٨)
                </button>
              </div>

            </div>

            {/* Results Summary Bar */}
            <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400 px-1">
              <span>
                عرض {filteredSurahs.length.toLocaleString('ar-EG')} سورة
                {searchQuery && ` مطابقة لـ "${searchQuery}"`}
              </span>
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="text-emerald-700 dark:text-emerald-400 hover:underline"
                >
                  إلغاء التصفية
                </button>
              )}
            </div>
          </section>

          {/* Surahs List / Grid */}
          <section aria-label="فهرس السور">
            {filteredSurahs.length === 0 ? (
              <div className="text-center py-16 px-4 bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 space-y-3">
                <div className="w-12 h-12 rounded-full bg-stone-100 dark:bg-stone-800 flex items-center justify-center mx-auto text-stone-400">
                  <Search className="w-6 h-6" />
                </div>
                <h3 className="text-base font-semibold text-stone-800 dark:text-stone-200">
                  لم يتم العثور على أي سورة
                </h3>
                <p className="text-xs text-stone-500 dark:text-stone-400 max-w-sm mx-auto">
                  تأكد من كتابة اسم السورة أو رقمها بشكل صحيح، أو أزل كلمات البحث لعرض كل السور.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setTypeFilter('all');
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-700 hover:bg-emerald-800 text-white transition-colors"
                >
                  إعادة ضبط البحث
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {filteredSurahs.map((surah) => (
                  <SurahCard
                    key={surah.number}
                    surah={surah}
                    isBookmarked={lastReadSurah.number === surah.number}
                    savedVerseNumber={surahProgressMap[surah.number] || null}
                    onSelect={(s, v) => handleOpenReading(s, v)}
                    onBookmark={(e, s) => {
                      e.stopPropagation();
                      handleSetBookmark(s);
                    }}
                  />
                ))}
              </div>
            )}
          </section>

        </main>
      )}

      {/* Elegant Bottom Footer - only on home index */}
      {!readingSurah && (
        <footer className="mt-auto border-t border-stone-200/80 dark:border-stone-800 py-6 text-center text-xs text-stone-500 dark:text-stone-400">
          <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <p className="font-amiri text-sm text-stone-700 dark:text-stone-300">
                المصحف — قراءة وتدبر آيات الذكر الحكيم والأذكار اليومية المأثورة
              </p>
              <p className="text-[11px] text-stone-400 dark:text-stone-500 mt-0.5">
                النص القرآني المعتمد: Tanzil Quran Text (Uthmani Version 1.1) • جاهز للنشر في المتاجر (Unity Ads ID: 800394591)
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs text-stone-500 dark:text-stone-400 shrink-0">
              <a
                href="/quran-app-complete.zip"
                download="quran-app-complete.zip"
                className="hover:text-emerald-700 dark:hover:text-emerald-400 underline underline-offset-2 font-medium"
              >
                تحميل المشروع كاملاً (ZIP)
              </a>
              <span>•</span>
              <button
                type="button"
                onClick={handleShareApp}
                className="hover:text-emerald-700 dark:hover:text-emerald-400 underline underline-offset-2 font-medium cursor-pointer"
              >
                نشر ومشاركة التطبيق
              </button>
            </div>
          </div>
        </footer>
      )}

      {/* Surah Details Modal */}
      <SurahDetailsModal
        surah={modalSurah}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        isBookmarked={modalSurah?.number === lastReadSurah.number}
        onBookmark={(surah) => handleSetBookmark(surah)}
        onNavigateSurah={handleNavigateModalSurah}
        onRead={(surah) => handleOpenReading(surah)}
      />

      {/* Share Modal (Fallback when Web Share API is unavailable or restricted) */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />

      {/* Favorite Verses Side Drawer */}
      <FavoriteVersesSidebar
        isOpen={isFavoriteVersesOpen}
        onClose={() => setIsFavoriteVersesOpen(false)}
        onSelectVerse={handleSelectFavoriteVerse}
      />
    </div>
  );
}
