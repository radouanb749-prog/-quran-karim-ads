import React, { useState } from 'react';
import { 
  X, 
  Heart, 
  Bookmark, 
  Copy, 
  Check, 
  Share2, 
  Sparkles, 
  CheckCircle2,
  BookOpen,
  Volume2,
  Play,
  Pause
} from 'lucide-react';
import { Verse } from '../services/quranService';
import { Surah } from '../data/surahs';
import { TajweedVerseText } from './TajweedVerseText';
import { getVerseSajda } from '../services/divisionService';

interface AyahActionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  verse: Verse | null;
  surah: Surah;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  isSavedAsBookmark: boolean;
  onSaveAsBookmark: () => void;
  onOpenTajweedLegend?: () => void;
  tajweedActive?: boolean;
  onPlayVerse?: (verseNumber: number) => void;
  isPlayingCurrentVerse?: boolean;
  onOpenTafsir?: () => void;
  onOpenSajda?: () => void;
}

export const AyahActionsModal: React.FC<AyahActionsModalProps> = ({
  isOpen,
  onClose,
  verse,
  surah,
  isFavorite,
  onToggleFavorite,
  isSavedAsBookmark,
  onSaveAsBookmark,
  onOpenTajweedLegend,
  tajweedActive = false,
  onPlayVerse,
  isPlayingCurrentVerse = false,
  onOpenTafsir,
  onOpenSajda,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !verse) return null;

  const handleCopy = async () => {
    try {
      const textToCopy = `﴿ ${verse.text} ﴾\n[سورة ${surah.name}: الآية ${verse.number}]`;
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const handleShare = async () => {
    const textToShare = `﴿ ${verse.text} ﴾\n[سورة ${surah.name}: الآية ${verse.number}]`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `آية من سورة ${surah.name}`,
          text: textToShare,
        });
      } catch {
        handleCopy();
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs">
      <div 
        className="w-full max-w-lg bg-white dark:bg-stone-900 rounded-t-3xl sm:rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in slide-in-from-bottom duration-200"
        dir="rtl"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between bg-stone-50/80 dark:bg-stone-950/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 flex items-center justify-center text-emerald-800 dark:text-emerald-300 font-bold font-mono text-sm">
              {verse.number.toLocaleString('ar-EG')}
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <span>سورة {surah.name}</span>
                <span className="text-xs text-stone-500 dark:text-stone-400 font-normal">
                  • الآية {verse.number.toLocaleString('ar-EG')}
                </span>
              </h3>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">
                الجزء {surah.juz.toLocaleString('ar-EG')} • الصفحة {surah.page.toLocaleString('ar-EG')}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Verse Arabic Text */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4">
          <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200/80 dark:border-stone-800">
            <p className="font-amiri text-xl sm:text-2xl text-stone-900 dark:text-stone-100 leading-loose text-justify select-text">
              <TajweedVerseText 
                text={verse.text} 
                enabled={tajweedActive} 
                onRuleClick={onOpenTajweedLegend} 
              />
            </p>
          </div>

          {/* Audio Playback Button */}
          {onPlayVerse && (
            <button
              type="button"
              onClick={() => {
                onPlayVerse(verse.number);
                onClose();
              }}
              className="w-full flex items-center justify-center gap-2.5 p-3.5 rounded-2xl font-bold text-xs sm:text-sm bg-emerald-700 hover:bg-emerald-800 text-white shadow-md active:scale-95 transition-all"
            >
              {isPlayingCurrentVerse ? (
                <>
                  <Pause className="w-4 h-4 fill-current" />
                  <span>الاستماع قيد التشغيل (إيقاف مؤقت)</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4" />
                  <span>الاستماع إلى تلاوة هذه الآية</span>
                </>
              )}
            </button>
          )}

          {/* Tafsir Action Button */}
          {onOpenTafsir && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenTafsir();
              }}
              className="w-full flex items-center justify-center gap-2.5 p-3.5 rounded-2xl font-bold text-xs sm:text-sm bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-900 dark:text-amber-200 shadow-xs active:scale-95 transition-all"
            >
              <BookOpen className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span>تفسير الآية (الميسر، السعدي، ابن كثير)</span>
            </button>
          )}

          {/* Sajda Dua Action Button if verse has a Sajda */}
          {verse && getVerseSajda(surah.number, verse.number) && onOpenSajda && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenSajda();
              }}
              className="w-full flex items-center justify-center gap-2.5 p-3.5 rounded-2xl font-bold text-xs sm:text-sm bg-gradient-to-r from-amber-500/25 via-amber-400/20 to-amber-500/25 hover:from-amber-500/35 hover:to-amber-500/35 border border-amber-500/50 text-amber-950 dark:text-amber-100 shadow-xs active:scale-95 transition-all"
            >
              <span className="font-serif font-bold text-lg text-amber-700 dark:text-amber-300">۩</span>
              <span>موضع سجدة تلاوة • عرض دعاء وأحكام السجدة</span>
            </button>
          )}

          {/* Action Buttons Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            
            {/* 1. Favorite Toggle Button */}
            <button
              type="button"
              onClick={() => {
                onToggleFavorite();
              }}
              className={`flex items-center justify-center gap-2.5 p-3 rounded-2xl font-bold text-xs sm:text-sm border transition-all active:scale-95 ${
                isFavorite
                  ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-300 shadow-xs'
                  : 'bg-white dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-50'
              }`}
            >
              <Heart 
                className={`w-4 h-4 transition-transform ${
                  isFavorite ? 'fill-rose-500 text-rose-500 scale-110' : 'text-stone-400'
                }`} 
              />
              <span>{isFavorite ? 'محفوظة في المفضلة' : 'إضافة إلى المفضلة'}</span>
            </button>

            {/* 2. Reading Bookmark Button */}
            <button
              type="button"
              onClick={() => {
                onSaveAsBookmark();
              }}
              className={`flex items-center justify-center gap-2.5 p-3 rounded-2xl font-bold text-xs sm:text-sm border transition-all active:scale-95 ${
                isSavedAsBookmark
                  ? 'bg-amber-50 dark:bg-amber-950/60 border-amber-300 dark:border-amber-800 text-amber-800 dark:text-amber-300 shadow-xs'
                  : 'bg-white dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-50'
              }`}
            >
              <Bookmark 
                className={`w-4 h-4 transition-transform ${
                  isSavedAsBookmark ? 'fill-amber-500 text-amber-600 scale-110' : 'text-stone-400'
                }`} 
              />
              <span>{isSavedAsBookmark ? 'موضع التوقف الحالي' : 'تحديد كموضع توقف'}</span>
            </button>

            {/* 3. Copy Verse */}
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center justify-center gap-2.5 p-3 rounded-2xl font-bold text-xs sm:text-sm border bg-white dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-50 transition-colors active:scale-95"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700 dark:text-emerald-400">تم النسخ بنجاح</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-stone-500" />
                  <span>نسخ نص الآية</span>
                </>
              )}
            </button>

            {/* 4. Share Verse */}
            <button
              type="button"
              onClick={handleShare}
              className="flex items-center justify-center gap-2.5 p-3 rounded-2xl font-bold text-xs sm:text-sm border bg-white dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-50 transition-colors active:scale-95"
            >
              <Share2 className="w-4 h-4 text-stone-500" />
              <span>مشاركة الآية</span>
            </button>

          </div>

          {/* Tajweed guide link if active */}
          {onOpenTajweedLegend && (
            <div className="pt-2 text-center">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenTajweedLegend();
                }}
                className="inline-flex items-center gap-1.5 text-xs text-emerald-700 dark:text-emerald-400 hover:underline"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>دليل وتفاصيل أحكام التجويد الملونة</span>
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
