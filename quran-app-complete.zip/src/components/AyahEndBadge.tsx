import React from 'react';

interface AyahEndBadgeProps {
  number: number;
  className?: string;
}

export const AyahEndBadge: React.FC<AyahEndBadgeProps> = ({ number, className = '' }) => {
  const arabicDigits = number.toLocaleString('ar-EG');

  return (
    <span
      className={`inline-flex items-center justify-center align-middle mx-1.5 select-none relative font-amiri text-emerald-800 dark:text-emerald-300 font-bold ${className}`}
      title={`آية ${arabicDigits}`}
    >
      <svg
        viewBox="0 0 36 36"
        className="w-7 h-7 text-amber-600/30 dark:text-amber-400/40 inline-block align-middle"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle
          cx="18"
          cy="18"
          r="14"
          className="stroke-amber-600 dark:stroke-amber-400"
          strokeWidth="1.2"
        />
        <circle
          cx="18"
          cy="18"
          r="11.5"
          className="stroke-emerald-700/60 dark:stroke-emerald-400/60"
          strokeWidth="0.8"
          strokeDasharray="2 2"
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center text-[12px] font-bold text-stone-800 dark:text-stone-100">
        {arabicDigits}
      </span>
    </span>
  );
};
