import React from 'react';
import { Bookmark, ArrowLeft, BookOpen, Layers } from 'lucide-react';
import { Surah } from '../data/surahs';

interface ContinueReadingCardProps {
  lastReadSurah: Surah;
  lastReadVerseNumber?: number | null;
  onContinue: (surah: Surah, verseNumber?: number) => void;
}

export const ContinueReadingCard: React.FC<ContinueReadingCardProps> = ({
  lastReadSurah,
  lastReadVerseNumber,
  onContinue,
}) => {
  return (
    <section aria-label="متابعة القراءة" className="w-full">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-950 text-white p-5 sm:p-7 shadow-lg shadow-emerald-950/15 border border-emerald-700/30">
        
        {/* Subtle decorative Islamic arabesque pattern in background */}
        <div className="absolute -left-12 -bottom-12 w-48 h-48 opacity-10 pointer-events-none">
          <svg viewBox="0 0 100 100" fill="currentColor">
            <polygon points="50,0 65,35 100,50 65,65 50,100 35,65 0,50 35,35" />
            <circle cx="50" cy="50" r="30" stroke="currentColor" strokeWidth="4" fill="none" />
          </svg>
        </div>
        <div className="absolute -right-8 -top-8 w-36 h-36 opacity-10 pointer-events-none">
          <svg viewBox="0 0 100 100" fill="currentColor">
            <polygon points="50,0 65,35 100,50 65,65 50,100 35,65 0,50 35,35" />
          </svg>
        </div>

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-5">
          
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 text-emerald-200/90 text-xs sm:text-sm font-medium">
              <Bookmark className="w-4 h-4 text-amber-300 fill-amber-300/30 stroke-[2]" />
              <span>متابعة القراءة</span>
              {lastReadVerseNumber && (
                <span className="bg-amber-400/20 text-amber-300 border border-amber-300/30 px-2 py-0.5 rounded-full text-[11px] font-semibold">
                  توقفت عند الآية {lastReadVerseNumber.toLocaleString('ar-EG')}
                </span>
              )}
            </div>

            <div>
              <div className="flex items-baseline gap-3">
                <h2 className="font-amiri text-2xl sm:text-3xl font-bold tracking-normal text-white">
                  سورة {lastReadSurah.name}
                </h2>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-700/60 text-emerald-200 border border-emerald-600/40">
                  {lastReadSurah.type}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-3 sm:gap-4 mt-2 text-xs sm:text-sm text-emerald-100/80">
                <span className="inline-flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-emerald-300" />
                  الصفحة {lastReadSurah.page.toLocaleString('ar-EG')}
                </span>
                <span className="inline-block w-1 h-1 rounded-full bg-emerald-400/50" />
                <span className="inline-flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-emerald-300" />
                  الجزء {lastReadSurah.juz.toLocaleString('ar-EG')}
                </span>
                <span className="inline-block w-1 h-1 rounded-full bg-emerald-400/50" />
                <span>
                  {lastReadSurah.versesCount.toLocaleString('ar-EG')} آية
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center">
            <button
              onClick={() => onContinue(lastReadSurah, lastReadVerseNumber || undefined)}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-900 font-semibold text-sm transition-all duration-150 shadow-md hover:shadow-lg active:scale-98"
            >
              <span>{lastReadVerseNumber ? `متابعة من الآية ${lastReadVerseNumber.toLocaleString('ar-EG')}` : 'متابعة التلاوة'}</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>

        </div>
      </div>
    </section>
  );
};
