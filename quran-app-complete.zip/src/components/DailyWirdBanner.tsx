import React from 'react';
import { 
  Bell, 
  Clock, 
  BookOpen, 
  CheckCircle2, 
  Settings, 
  X, 
  Flame, 
  Sparkles,
  ArrowLeft
} from 'lucide-react';
import { 
  DailyWirdConfig, 
  formatArabicTime, 
  isReminderTimeReached, 
  isWirdCompletedToday, 
  isWirdDismissedToday 
} from '../services/reminderService';

interface DailyWirdBannerProps {
  config: DailyWirdConfig;
  onOpenModal: () => void;
  onStartReading: () => void;
  onMarkCompleted: () => void;
  onDismiss: () => void;
}

export const DailyWirdBanner: React.FC<DailyWirdBannerProps> = ({
  config,
  onOpenModal,
  onStartReading,
  onMarkCompleted,
  onDismiss,
}) => {
  const isDismissed = isWirdDismissedToday(config);
  const isCompleted = isWirdCompletedToday(config);
  const isTimeDue = isReminderTimeReached(config.time);

  // If user dismissed for today and it's not opened, we can hide it
  if (isDismissed) {
    return null;
  }

  // Case 1: Daily Reminder is disabled - Show invitation to enable it
  if (!config.enabled) {
    return (
      <div 
        className="relative overflow-hidden rounded-2xl p-4 sm:p-5 bg-gradient-to-r from-emerald-950/80 via-emerald-900/70 to-stone-900/90 text-stone-100 border border-emerald-700/40 shadow-md backdrop-blur-sm"
        dir="rtl"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-amiri text-lg font-bold text-white">
                  خصص وقتاً يومياً لوردك القرآني
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
                  تنبيه يومي
                </span>
              </div>
              <p className="text-xs text-emerald-100/75 mt-0.5">
                اضبط منبهاً يومياً في الوقت والمقدار الذي يناسبك للمحافظة على تلاوة وتدبر كتاب الله.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
            <button
              type="button"
              onClick={onOpenModal}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs transition-all shadow-sm active:scale-95"
            >
              <Bell className="w-3.5 h-3.5" />
              <span>ضبط المنبه اليومي</span>
            </button>
            <button
              type="button"
              onClick={onDismiss}
              className="p-2 text-stone-400 hover:text-stone-200 transition-colors"
              title="إخفاء التذكير"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Case 2: Today's wird is marked completed
  if (isCompleted) {
    return (
      <div 
        className="relative overflow-hidden rounded-2xl p-4 sm:p-5 bg-gradient-to-r from-emerald-900/90 via-teal-900/80 to-emerald-950/90 text-white border border-emerald-500/40 shadow-lg backdrop-blur-sm"
        dir="rtl"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shrink-0">
              <CheckCircle2 className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h3 className="font-amiri text-lg font-bold text-white flex items-center gap-2">
                  ما شاء الله! أتممت ورد اليوم بنجاح
                </h3>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-300/30 text-xs font-semibold">
                  <Flame className="w-3 h-3 fill-current text-amber-400" />
                  {(config.streakDays || 1).toLocaleString('ar-EG')} أيام متتالية
                </span>
              </div>
              <p className="text-xs text-emerald-100/80 mt-0.5">
                تقبل الله طاعاتكم وثبت أجركم • {config.customTitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
            <button
              type="button"
              onClick={onStartReading}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs transition-colors border border-white/15"
            >
              <BookOpen className="w-3.5 h-3.5 text-emerald-300" />
              <span>مواصلة التلاوة</span>
            </button>
            <button
              type="button"
              onClick={onOpenModal}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-emerald-200 hover:text-white transition-colors border border-white/10"
              title="إعدادات الورد"
            >
              <Settings className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onDismiss}
              className="p-2 text-emerald-200/70 hover:text-white transition-colors"
              title="إخفاء الإشعار"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Case 3: Reminder time reached (Due right now) or active for today
  if (isTimeDue) {
    return (
      <aside 
        aria-label="إشعار الورد اليومي"
        className="relative overflow-hidden rounded-2xl p-4 sm:p-5.5 bg-gradient-to-r from-amber-950 via-stone-900 to-emerald-950 text-white border-2 border-amber-500/70 shadow-xl shadow-amber-950/20 backdrop-blur-md animate-in fade-in slide-in-from-top-3 duration-300"
        dir="rtl"
      >
        {/* Subtle decorative pulsing halo */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-44 h-44 bg-amber-500/10 rounded-full blur-2xl pointer-events-none animate-pulse" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          <div className="flex items-start gap-3.5">
            <div className="relative w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-amber-300 shrink-0">
              <Bell className="w-5 h-5 fill-amber-300/40 animate-bounce" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full ring-2 ring-stone-900 animate-ping" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full ring-2 ring-stone-900" />
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2.5 flex-wrap">
                <h3 className="font-amiri text-lg sm:text-xl font-bold text-amber-200">
                  تنبيه: حان موعد وردك اليومي من القرآن الكريم
                </h3>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-300/40 text-xs font-semibold">
                  <Clock className="w-3 h-3" />
                  {formatArabicTime(config.time)}
                </span>
                {config.streakDays > 0 && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[11px] font-semibold">
                    <Flame className="w-3 h-3 fill-current text-amber-400" />
                    سلسلة: {config.streakDays.toLocaleString('ar-EG')} أيام
                  </span>
                )}
              </div>

              <p className="text-xs sm:text-sm text-stone-200">
                مقدار الورد المحدد: <strong className="text-white font-semibold underline decoration-amber-400/50 underline-offset-4">{config.customTitle}</strong> • اغتنم بركة التلاوة والتدبر
              </p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap shrink-0 pt-1 md:pt-0">
            <button
              type="button"
              onClick={onStartReading}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs sm:text-sm transition-all shadow-md active:scale-95 cursor-pointer"
            >
              <span>ابدأ القراءة الآن</span>
              <ArrowLeft className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onMarkCompleted}
              className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-emerald-700/80 hover:bg-emerald-600 text-white font-semibold text-xs transition-colors border border-emerald-500/50"
              title="تحديد الورد كمنجز لهذا اليوم"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
              <span className="hidden sm:inline">تمت القراءة</span>
            </button>

            <button
              type="button"
              onClick={onOpenModal}
              className="p-2.5 rounded-xl bg-stone-800/80 hover:bg-stone-700 text-stone-300 hover:text-white transition-colors border border-stone-700"
              title="تعديل وقت ومنبه الورد"
            >
              <Settings className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onDismiss}
              className="p-2.5 text-stone-400 hover:text-stone-200 transition-colors"
              title="إخفاء لليوم"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

        </div>
      </aside>
    );
  }

  // Case 4: Reminder is enabled, but the scheduled time is upcoming later today
  return (
    <div 
      className="relative overflow-hidden rounded-2xl p-4 sm:p-5 bg-gradient-to-r from-stone-900/90 via-emerald-950/70 to-stone-900/90 text-stone-200 border border-emerald-800/40 shadow-md backdrop-blur-sm"
      dir="rtl"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-amiri text-base font-bold text-white">
                تذكير الورد اليومي محدد عند {formatArabicTime(config.time)}
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {config.customTitle}
              </span>
            </div>
            <p className="text-xs text-stone-400 mt-0.5">
              سيظهر لك تنبيه عند حلول الوقت المحدد، أو يمكنك البدء مبكراً الآن.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
          <button
            type="button"
            onClick={onStartReading}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-800/80 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors border border-emerald-600/40"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>ابدأ مبكراً</span>
          </button>
          <button
            type="button"
            onClick={onOpenModal}
            className="p-2 rounded-xl bg-stone-800 text-stone-300 hover:text-white transition-colors border border-stone-700"
            title="تعديل الموعد"
          >
            <Settings className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onDismiss}
            className="p-2 text-stone-500 hover:text-stone-300 transition-colors"
            title="إخفاء"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
