import React, { useState } from 'react';
import { 
  X, 
  Bell, 
  Clock, 
  BookOpen, 
  Volume2, 
  VolumeX, 
  Check, 
  Flame, 
  Calendar, 
  Sparkles,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { 
  DailyWirdConfig, 
  WIRD_PRESETS, 
  TARGET_PRESETS, 
  saveDailyWirdConfig, 
  formatArabicTime,
  playGentleChime,
  requestNotificationPermission,
  sendBrowserNotification,
  getTodayDateString
} from '../services/reminderService';

interface DailyWirdModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: DailyWirdConfig;
  onConfigChange: (newConfig: DailyWirdConfig) => void;
  onStartReading: () => void;
}

export const DailyWirdModal: React.FC<DailyWirdModalProps> = ({
  isOpen,
  onClose,
  config,
  onConfigChange,
  onStartReading,
}) => {
  const [enabled, setEnabled] = useState(config.enabled);
  const [time, setTime] = useState(config.time || '06:30');
  const [targetType, setTargetType] = useState(config.targetType || 'hizb');
  const [targetAmount, setTargetAmount] = useState(config.targetAmount || 1);
  const [customTitle, setCustomTitle] = useState(config.customTitle || 'حزب كامل');
  const [notificationSound, setNotificationSound] = useState(config.notificationSound);
  const [browserNotifications, setBrowserNotifications] = useState(config.browserNotifications);
  const [notificationStatus, setNotificationStatus] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSelectPreset = (presetTime: string) => {
    setTime(presetTime);
  };

  const handleSelectTarget = (type: 'pages' | 'hizb' | 'juz', amount: number, title: string) => {
    setTargetType(type);
    setTargetAmount(amount);
    setCustomTitle(title);
  };

  const handleTestSound = () => {
    playGentleChime();
  };

  const handleRequestBrowserPerm = async () => {
    const granted = await requestNotificationPermission();
    if (granted) {
      setBrowserNotifications(true);
      setNotificationStatus('تم تفعيل إشعارات المتصفح بنجاح! ستتلقى تنبيهاً في الوقت المحدد.');
      sendBrowserNotification(
        'المصحف — منبه الورد اليومي',
        `تم ضبط تنبيه وردك اليومي بنجاح (${customTitle}) في تمام الساعة ${formatArabicTime(time)}.`
      );
    } else {
      setBrowserNotifications(false);
      setNotificationStatus('تعذر تفعيل الإشعارات، يُرجى التحقق من أذونات المتصفح.');
    }
    setTimeout(() => setNotificationStatus(null), 4000);
  };

  const handleSave = () => {
    const updated: DailyWirdConfig = {
      ...config,
      enabled,
      time,
      targetType,
      targetAmount,
      customTitle,
      notificationSound,
      browserNotifications,
    };
    saveDailyWirdConfig(updated);
    onConfigChange(updated);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 700);
  };

  const isCompletedToday = config.lastCompletedDate === getTodayDateString();

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/70 backdrop-blur-sm animate-in fade-in duration-200"
      dir="rtl"
    >
      <div 
        className="w-full max-w-lg bg-white dark:bg-stone-900 rounded-3xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative px-6 py-5 bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 text-amber-300">
              <Bell className="w-5 h-5 fill-amber-300/30" />
            </div>
            <div>
              <h2 className="font-amiri text-xl font-bold">منبه الورد القرآني اليومي</h2>
              <p className="text-xs text-emerald-100/80">
                حافظ على عهدك اليومي مع كتاب الله تعالى
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body with custom scroll */}
        <div className="p-6 space-y-6 overflow-y-auto">
          
          {/* Main Activation Switch */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60">
            <div className="space-y-0.5">
              <span className="text-sm font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                تفعيل التنبيه اليومي للورد
              </span>
              <p className="text-xs text-stone-600 dark:text-stone-400">
                إظهار إشعار تذكيري في أعلى الصفحة الرئيسية عند حلول الوقت
              </p>
            </div>
            <button
              type="button"
              onClick={() => setEnabled(!enabled)}
              className={`relative inline-flex h-7 w-13 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                enabled ? 'bg-emerald-700' : 'bg-stone-300 dark:bg-stone-700'
              }`}
              role="switch"
              aria-checked={enabled}
            >
              <span
                className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                  enabled ? '-translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Time Picker Section */}
          <div className={`space-y-3 transition-opacity ${enabled ? 'opacity-100' : 'opacity-50 pointer-events-none'}`}>
            <label className="text-xs font-bold text-stone-700 dark:text-stone-300 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
              وقت التنبيه اليومي
            </label>

            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full px-4 py-3 text-lg font-mono font-bold text-center rounded-2xl bg-stone-100 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-stone-100 focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                />
              </div>
              <div className="px-4 py-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-800/60 text-center min-w-[100px]">
                <div className="text-[11px] text-amber-700 dark:text-amber-400 font-medium">الوقت المختار</div>
                <div className="text-sm font-bold text-stone-800 dark:text-stone-200 mt-0.5">
                  {formatArabicTime(time)}
                </div>
              </div>
            </div>

            {/* Quick Time Presets */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1">
              {WIRD_PRESETS.map((preset) => {
                const isSelected = time === preset.time;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => handleSelectPreset(preset.time)}
                    className={`px-3 py-2 rounded-xl text-xs flex items-center gap-2 border transition-all ${
                      isSelected
                        ? 'bg-emerald-100 dark:bg-emerald-950/60 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold shadow-xs'
                        : 'bg-white dark:bg-stone-800/80 border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-800'
                    }`}
                  >
                    <span>{preset.icon}</span>
                    <div className="text-right flex-1 truncate">
                      <div className="leading-tight">{preset.label}</div>
                      <div className="text-[10px] text-stone-400 font-mono">{formatArabicTime(preset.time)}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Wird Goal / Amount */}
          <div className={`space-y-3 transition-opacity ${enabled ? 'opacity-100' : 'opacity-50 pointer-events-none'}`}>
            <label className="text-xs font-bold text-stone-700 dark:text-stone-300 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
              مقدار الورد اليومي المستهدف
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {TARGET_PRESETS.map((preset, index) => {
                const isSelected = targetType === preset.type && targetAmount === preset.amount;
                return (
                  <button
                    key={index}
                    type="button"
                    onClick={() => handleSelectTarget(preset.type, preset.amount, preset.title)}
                    className={`p-3 rounded-2xl text-right border transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600 dark:border-emerald-500 ring-1 ring-emerald-600/30'
                        : 'bg-white dark:bg-stone-800/60 border-stone-200 dark:border-stone-800 hover:border-stone-300 dark:hover:border-stone-700'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold text-stone-900 dark:text-stone-100">
                        {preset.title}
                      </div>
                      <div className="text-[10px] text-stone-500 dark:text-stone-400 mt-0.5">
                        المدة التقديرية: {preset.duration}
                      </div>
                    </div>
                    {isSelected && (
                      <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                        <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Preferences: Audio chime & Browser notifications */}
          <div className={`space-y-2 pt-2 border-t border-stone-200 dark:border-stone-800 transition-opacity ${enabled ? 'opacity-100' : 'opacity-50 pointer-events-none'}`}>
            <div className="flex items-center justify-between p-3 rounded-xl hover:bg-stone-100 dark:hover:bg-stone-800/50 transition-colors">
              <div className="flex items-center gap-2.5">
                {notificationSound ? (
                  <Volume2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                ) : (
                  <VolumeX className="w-4 h-4 text-stone-400" />
                )}
                <div>
                  <div className="text-xs font-semibold text-stone-800 dark:text-stone-200">نغمة التذكير الهادئة</div>
                  <div className="text-[10px] text-stone-500">رنين وقور وهادئ عند حلول الوقت</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleTestSound}
                  className="px-2 py-1 text-[11px] rounded-lg bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-300"
                >
                  تجربة النغمة
                </button>
                <input
                  type="checkbox"
                  checked={notificationSound}
                  onChange={(e) => setNotificationSound(e.target.checked)}
                  className="w-4 h-4 rounded-sm text-emerald-600 focus:ring-emerald-500 accent-emerald-600 cursor-pointer"
                />
              </div>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl hover:bg-stone-100 dark:hover:bg-stone-800/50 transition-colors">
              <div className="flex items-center gap-2.5">
                <Bell className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <div>
                  <div className="text-xs font-semibold text-stone-800 dark:text-stone-200">إشعارات المتصفح</div>
                  <div className="text-[10px] text-stone-500">استلام تنبيه حتى لو كان المتصفح مصغراً</div>
                </div>
              </div>
              <button
                type="button"
                onClick={handleRequestBrowserPerm}
                className="px-2.5 py-1 text-[11px] font-medium rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300/60 dark:border-emerald-700 hover:bg-emerald-200"
              >
                {browserNotifications ? 'مُفعّلة ✓' : 'تفعيل إذن الإشعار'}
              </button>
            </div>

            {notificationStatus && (
              <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{notificationStatus}</span>
              </div>
            )}
          </div>

          {/* Reading Streak & Stats */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/30 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                <Flame className="w-5 h-5 fill-current" />
              </div>
              <div>
                <div className="text-xs font-bold text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
                  سلسلة المداومة:
                  <span className="text-amber-600 dark:text-amber-400 font-mono text-sm">
                    {(config.streakDays || 0).toLocaleString('ar-EG')} أيام متتالية
                  </span>
                </div>
                <div className="text-[10px] text-stone-500 dark:text-stone-400 mt-0.5">
                  {isCompletedToday ? 'أنجزت ورد اليوم بنجاح ✨' : 'بانتظار إنجازك لورد اليوم'}
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-1 text-[11px] text-stone-400">
              <Calendar className="w-3.5 h-3.5" />
              <span>اليوم: {new Date().toLocaleDateString('ar-EG', { weekday: 'short' })}</span>
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 bg-stone-50 dark:bg-stone-950 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              handleSave();
              onStartReading();
            }}
            className="px-4 py-2.5 rounded-xl bg-stone-200 dark:bg-stone-800 text-stone-800 dark:text-stone-200 hover:bg-stone-300 dark:hover:bg-stone-700 text-xs font-bold transition-colors flex items-center gap-1.5"
          >
            <BookOpen className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>ابدأ القراءة فوراً</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-stone-600 dark:text-stone-400 hover:bg-stone-200/60 dark:hover:bg-stone-800 text-xs font-semibold transition-colors"
            >
              إلغاء
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-md active:scale-98 flex items-center gap-1.5"
            >
              {savedSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-white" />
                  <span>تم الحفظ!</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>حفظ الإعدادات</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
