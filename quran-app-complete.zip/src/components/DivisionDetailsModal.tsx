import React from 'react';
import { X, Navigation, BookOpen } from 'lucide-react';
import { QuranDivisionMarker } from '../data/quranDivisions';
import { SURAHS } from '../data/surahs';

interface DivisionDetailsModalProps {
  marker: QuranDivisionMarker | null;
  onClose: () => void;
  onJumpToVerse?: (verseNumber: number) => void;
}

export const DivisionDetailsModal: React.FC<DivisionDetailsModalProps> = ({
  marker,
  onClose,
  onJumpToVerse,
}) => {
  if (!marker) return null;

  const surah = SURAHS.find((s) => s.number === marker.surahNumber);

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in"
      onClick={onClose}
      dir="rtl"
    >
      <div 
        className="w-full max-w-md bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl p-6 overflow-hidden relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          type="button"
          className="absolute top-4 left-4 p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Decorative Top Icon */}
        <div className="flex items-center justify-center mb-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-300/40 dark:border-amber-700/40 flex items-center justify-center shadow-xs">
            <span className="text-3xl font-bold font-amiri leading-none">۞</span>
          </div>
        </div>

        {/* Title */}
        <div className="text-center mb-6">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100/70 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300/40 dark:border-emerald-700/40 mb-2">
            علامة تقسيم المصحف الشريف
          </span>
          <h3 className="font-amiri text-2xl font-bold text-stone-900 dark:text-stone-100">
            {marker.name}
          </h3>
          <p className="text-stone-500 dark:text-stone-400 text-xs mt-1">
            وفق الرواية المعتمدة (رواية ورش عن نافع)
          </p>
        </div>

        {/* Information Grid */}
        <div className="space-y-2.5 mb-6 text-sm">
          <div className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 dark:bg-stone-950/50 border border-stone-200/70 dark:border-stone-800/70">
            <span className="text-stone-500 dark:text-stone-400">العلاقة الحسابية للحزب:</span>
            <span className="font-semibold text-stone-900 dark:text-stone-100">
              {marker.mathFraction}
            </span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 dark:bg-stone-950/50 border border-stone-200/70 dark:border-stone-800/70">
            <span className="text-stone-500 dark:text-stone-400">الحزب والجزء:</span>
            <span className="font-semibold text-stone-900 dark:text-stone-100">
              الحزب {marker.hizbNumber.toLocaleString('ar-EG')} (الجزء {marker.juzNumber.toLocaleString('ar-EG')})
            </span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 dark:bg-stone-950/50 border border-stone-200/70 dark:border-stone-800/70">
            <span className="text-stone-500 dark:text-stone-400">الموضع القرآني:</span>
            <span className="font-semibold text-stone-900 dark:text-stone-100">
              سورة {surah?.name || marker.surahNumber} • الآية {marker.verseNumber.toLocaleString('ar-EG')}
            </span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 dark:bg-stone-950/50 border border-stone-200/70 dark:border-stone-800/70">
            <span className="text-stone-500 dark:text-stone-400">ترتيب الثمن في المصحف:</span>
            <span className="font-semibold font-mono text-emerald-700 dark:text-emerald-400">
              {marker.globalEighthIndex.toLocaleString('ar-EG')} / ٤٨٠
            </span>
          </div>
        </div>

        {/* Action Button */}
        {onJumpToVerse && (
          <button
            onClick={() => {
              onJumpToVerse(marker.verseNumber);
              onClose();
            }}
            type="button"
            className="w-full py-3 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-98"
          >
            <Navigation className="w-4 h-4 rotate-45" />
            <span>الانتقال إلى موضع الآية ({marker.verseNumber.toLocaleString('ar-EG')})</span>
          </button>
        )}
      </div>
    </div>
  );
};
