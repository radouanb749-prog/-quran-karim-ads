import React from 'react';
import { Surah } from '../data/surahs';
import { Verse } from '../services/quranService';
import { AyahEndBadge } from './AyahEndBadge';
import { QuranDivisionMarker } from '../data/quranDivisions';
import { QuranDivisionBadge } from './QuranDivisionBadge';
import { Bookmark, Heart, Volume2 } from 'lucide-react';
import { TajweedVerseText } from './TajweedVerseText';

interface FatihaSpecialLayoutProps {
  surah: Surah;
  verses: Verse[];
  savedVerseNumber: number | null;
  activeHighlightVerse: number | null;
  verseRefs: React.MutableRefObject<Map<number, HTMLElement>>;
  fontSizeClass: string;
  onSaveVerse: (verseNumber: number) => void;
  onSelectDivisionModal: (division: QuranDivisionMarker) => void;
  getVerseDivision: (surahNum: number, verseNum: number) => QuranDivisionMarker | undefined;
  viewMode: 'page' | 'mushaf' | 'lines';
  tajweedActive?: boolean;
  onOpenTajweedLegend?: () => void;
  isVerseFavorite?: (verseNum: number) => boolean;
  onOpenAyahModal?: (verse: Verse) => void;
  currentPlayingVerse?: number | null;
  fontFamilyClass?: string;
  isPlayingAudio?: boolean;
  onToggleAudio?: () => void;
}

/**
 * Special Traditional Illuminated Mushaf Layout for Surat Al-Fatihah (Surah 1)
 * Inspired by classic illuminated frontispieces (اللوحة الافتتاحية المذهبة لفاتحة الكتاب)
 * featuring double decorative borders, Islamic arabesque corners, illuminated title plaque,
 * and elegant bottom closing ornament.
 */
export const FatihaSpecialLayout: React.FC<FatihaSpecialLayoutProps> = ({
  surah,
  verses,
  savedVerseNumber,
  activeHighlightVerse,
  verseRefs,
  fontSizeClass,
  onSaveVerse,
  onSelectDivisionModal,
  getVerseDivision,
  viewMode,
  tajweedActive = false,
  onOpenTajweedLegend,
  isVerseFavorite,
  onOpenAyahModal,
  currentPlayingVerse,
  fontFamilyClass = 'font-quran',
  isPlayingAudio = false,
  onToggleAudio,
}) => {
  // First verse of Al-Fatihah is Bismillah in Hafs/standard Mushaf, or included in verses array
  // In our data, verse 1 is "بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ"
  const isFirstVerseBismillah = verses.length > 0 && verses[0].text.includes('بِسْمِ ٱللَّهِ');
  const bismillahVerse = isFirstVerseBismillah ? verses[0] : null;
  const remainingVerses = isFirstVerseBismillah ? verses.slice(1) : verses;

  return (
    <div 
      className={`relative w-full mx-auto select-text transition-all ${
        viewMode === 'page' ? 'max-w-3xl px-1 sm:px-3 py-1' : 'max-w-3xl px-2 sm:px-4 py-3'
      }`}
      dir="rtl"
    >
      {/* Outer Grand Illuminated Border */}
      <div className="relative rounded-3xl p-3 sm:p-6 md:p-8 bg-gradient-to-b from-amber-50/70 via-stone-50/90 to-amber-50/60 dark:from-stone-900/90 dark:via-stone-950/95 dark:to-stone-900/90 border-2 sm:border-3 border-amber-600/70 dark:border-amber-500/60 shadow-xl overflow-hidden">
        
        {/* Subtle Islamic Geometric Pattern Background Overlay */}
        <div 
          className="absolute inset-0 opacity-[0.035] dark:opacity-[0.06] pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(#b45309 1px, transparent 1px), radial-gradient(#047857 1px, transparent 1px)`,
            backgroundSize: '24px 24px',
            backgroundPosition: '0 0, 12px 12px',
          }}
        />

        {/* Inner Secondary Gilded Border with Interlaced Corner Motifs */}
        <div className="relative rounded-2xl border border-amber-500/50 dark:border-amber-400/40 p-3 sm:p-5 md:p-6 bg-white/70 dark:bg-stone-900/70 backdrop-blur-xs">
          
          {/* Ornate Islamic Corner Arabesque SVGs */}
          {/* Top-Right Corner */}
          <svg
            className="absolute top-1.5 right-1.5 w-7 h-7 sm:w-10 sm:h-10 text-amber-600/70 dark:text-amber-400/70 pointer-events-none"
            viewBox="0 0 48 48"
            fill="none"
            stroke="currentColor"
          >
            <path d="M4 4h20c8.837 0 16 7.163 16 16v20" strokeWidth="1.5" strokeLinecap="round" />
            <path d="M8 8h12c6.627 0 12 5.373 12 12v12" strokeWidth="1" strokeLinecap="round" opacity="0.6" />
            <circle cx="12" cy="12" r="3" fill="currentColor" fillOpacity="0.3" strokeWidth="1" />
            <path d="M24 4l-4 4 4 4" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M40 24l-4 4 4 4" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>

          {/* Top-Left Corner */}
          <svg
            className="absolute top-1.5 left-1.5 w-7 h-7 sm:w-10 sm:h-10 text-amber-600/70 dark:text-amber-400/70 pointer-events-none scale-x-[-1]"
            viewBox="0 0 48 48"
            fill="none"
            stroke="currentColor"
          >
            <path d="M4 4h20c8.837 0 16 7.163 16 16v20" strokeWidth="1.5" strokeLinecap="round" />
            <path d="M8 8h12c6.627 0 12 5.373 12 12v12" strokeWidth="1" strokeLinecap="round" opacity="0.6" />
            <circle cx="12" cy="12" r="3" fill="currentColor" fillOpacity="0.3" strokeWidth="1" />
            <path d="M24 4l-4 4 4 4" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M40 24l-4 4 4 4" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>

          {/* Bottom-Right Corner */}
          <svg
            className="absolute bottom-1.5 right-1.5 w-7 h-7 sm:w-10 sm:h-10 text-amber-600/70 dark:text-amber-400/70 pointer-events-none scale-y-[-1]"
            viewBox="0 0 48 48"
            fill="none"
            stroke="currentColor"
          >
            <path d="M4 4h20c8.837 0 16 7.163 16 16v20" strokeWidth="1.5" strokeLinecap="round" />
            <path d="M8 8h12c6.627 0 12 5.373 12 12v12" strokeWidth="1" strokeLinecap="round" opacity="0.6" />
            <circle cx="12" cy="12" r="3" fill="currentColor" fillOpacity="0.3" strokeWidth="1" />
            <path d="M24 4l-4 4 4 4" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M40 24l-4 4 4 4" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>

          {/* Bottom-Left Corner */}
          <svg
            className="absolute bottom-1.5 left-1.5 w-7 h-7 sm:w-10 sm:h-10 text-amber-600/70 dark:text-amber-400/70 pointer-events-none scale-[-1]"
            viewBox="0 0 48 48"
            fill="none"
            stroke="currentColor"
          >
            <path d="M4 4h20c8.837 0 16 7.163 16 16v20" strokeWidth="1.5" strokeLinecap="round" />
            <path d="M8 8h12c6.627 0 12 5.373 12 12v12" strokeWidth="1" strokeLinecap="round" opacity="0.6" />
            <circle cx="12" cy="12" r="3" fill="currentColor" fillOpacity="0.3" strokeWidth="1" />
            <path d="M24 4l-4 4 4 4" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M40 24l-4 4 4 4" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>

          {/* TOP GRAND ILLUMINATED CARTOUCHE (لوحة رأس السورة المذهبة) */}
          <header className="relative mb-5 sm:mb-7 pt-2 text-center">
            
            {/* Top Ornamental Arch Cresting */}
            <div className="flex items-center justify-center gap-2 mb-2 text-amber-600 dark:text-amber-400 opacity-85">
              <span className="h-px w-8 sm:w-16 bg-gradient-to-l from-amber-500 to-transparent" />
              <span className="text-xs sm:text-sm select-none">❖ ۞ ❖</span>
              <span className="h-px w-8 sm:w-16 bg-gradient-to-r from-amber-500 to-transparent" />
            </div>

            {/* Central Illuminated Plaque */}
            <div className="inline-block relative px-6 sm:px-12 py-2.5 sm:py-3 rounded-2xl bg-gradient-to-r from-amber-600/20 via-emerald-800/15 to-amber-600/20 dark:from-amber-500/25 dark:via-emerald-900/30 dark:to-amber-500/25 border-2 border-amber-600/60 dark:border-amber-400/50 shadow-sm">
              
              {/* Outer Decorative Wing Anchors */}
              <span className="absolute -right-3 top-1/2 -translate-y-1/2 text-amber-600 dark:text-amber-400 text-lg sm:text-xl font-bold select-none">
                ༺
              </span>
              <span className="absolute -left-3 top-1/2 -translate-y-1/2 text-amber-600 dark:text-amber-400 text-lg sm:text-xl font-bold select-none">
                ༻
              </span>

              {/* Title: سُورَةُ الْفَاتِحَةِ */}
              <h1 className="font-amiri text-2xl sm:text-4xl md:text-5xl font-bold text-emerald-950 dark:text-emerald-100 tracking-wide">
                سُورَةُ الْفَاتِحَةِ
              </h1>

              {/* Metadata Sub-Bar */}
              <div className="mt-1 flex items-center justify-center gap-2 sm:gap-3 text-[10px] sm:text-xs text-amber-900 dark:text-amber-200 font-medium">
                <span className="px-2 py-0.5 rounded-full bg-emerald-700/15 dark:bg-emerald-400/15 text-emerald-900 dark:text-emerald-200 border border-emerald-600/30 font-bold">
                  {surah.type}
                </span>
                <span>•</span>
                <span>سَبْعُ آيَاتٍ</span>
                <span>•</span>
                <span>نُزُولُهَا: ٥</span>
              </div>
            </div>

            {/* Saved Bookmark indicator inside Al-Fatihah */}
            {savedVerseNumber && (
              <div className="mt-2.5 flex items-center justify-center gap-2 flex-wrap">
                <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-500/15 text-amber-900 dark:text-amber-200 border border-amber-400/50 text-[11px] font-medium animate-in fade-in">
                  <Bookmark className="w-3 h-3 fill-current text-amber-600 dark:text-amber-400" />
                  <span>موضع التوقف الحالي: الآية {savedVerseNumber.toLocaleString('ar-EG')}</span>
                </div>
              </div>
            )}
          </header>

          {/* BISMILLAH ILLUMINATED SECTION (بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ) */}
          {bismillahVerse && (
            <div 
              ref={(el) => {
                if (el) verseRefs.current.set(bismillahVerse.number, el);
                else verseRefs.current.delete(bismillahVerse.number);
              }}
              id={`ayah-1-${bismillahVerse.number}`}
              className={`relative text-center my-3 sm:my-4 py-2.5 sm:py-3.5 px-4 rounded-xl border border-amber-500/35 dark:border-amber-400/30 bg-amber-500/5 dark:bg-amber-400/5 transition-all duration-300 ${
                currentPlayingVerse === bismillahVerse.number
                  ? 'bg-emerald-100/90 dark:bg-emerald-950/80 ring-2 ring-emerald-500 border-emerald-500 shadow-md'
                  : activeHighlightVerse === bismillahVerse.number
                  ? 'verse-highlight-active ring-2 ring-amber-500'
                  : savedVerseNumber === bismillahVerse.number
                  ? 'bg-amber-100/70 dark:bg-amber-950/40 border-amber-500'
                  : ''
              }`}
            >
              <div className="flex items-center justify-center gap-2 sm:gap-3">
                <span className={`${fontFamilyClass} text-2xl sm:text-3xl md:text-4xl text-emerald-950 dark:text-emerald-100 leading-loose`}>
                  <TajweedVerseText 
                    text={bismillahVerse.text} 
                    enabled={tajweedActive} 
                    onRuleClick={onOpenTajweedLegend} 
                  />
                </span>

                {/* Ayah End Badge with actions/bookmark on tap */}
                <span
                  onPointerDown={(e) => e.stopPropagation()}
                  onPointerUp={(e) => e.stopPropagation()}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onOpenAyahModal) {
                      onOpenAyahModal(bismillahVerse);
                    } else {
                      onSaveVerse(bismillahVerse.number);
                    }
                  }}
                  className="inline-flex items-center gap-1 cursor-pointer hover:scale-115 active:scale-95 transition-transform shrink-0"
                  title="خيارات الآية (حفظ في المفضلة، موضع التوقف، نسخ)"
                >
                  <AyahEndBadge number={bismillahVerse.number} />
                  {isVerseFavorite && isVerseFavorite(bismillahVerse.number) && (
                    <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500 inline animate-in zoom-in-50" />
                  )}
                </span>
              </div>
            </div>
          )}

          {/* INNER TEXT SANCTUM (آيات سورة الفاتحة المباركة) */}
          <div className="relative my-4 sm:my-6 px-1 sm:px-4 py-2">
            
            {/* Elegant Divider between Bismillah & Verses */}
            <div className="flex items-center justify-center gap-2 mb-4 sm:mb-6 opacity-40 dark:opacity-30">
              <span className="h-px flex-1 bg-gradient-to-r from-transparent via-amber-600 to-transparent" />
              <span className="text-amber-700 dark:text-amber-300 text-xs">۞</span>
              <span className="h-px flex-1 bg-gradient-to-r from-transparent via-amber-600 to-transparent" />
            </div>

            {/* Verses Flow */}
            <div 
              className={`${fontFamilyClass} text-center text-stone-900 dark:text-stone-100 leading-[2.6] sm:leading-[2.8] md:leading-[3.1] ${fontSizeClass}`}
            >
              {remainingVerses.map((verse) => {
                const isSaved = savedVerseNumber === verse.number;
                const isPulsing = activeHighlightVerse === verse.number;
                const division = getVerseDivision(1, verse.number);

                return (
                  <React.Fragment key={verse.number}>
                    {/* Inline division marker if present */}
                    {division && (
                      <span
                        onPointerDown={(e) => e.stopPropagation()}
                        onPointerUp={(e) => e.stopPropagation()}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectDivisionModal(division);
                        }}
                        className="inline-block align-middle mx-1"
                      >
                        <QuranDivisionBadge marker={division} mode="inline" />
                      </span>
                    )}

                    <span
                      ref={(el) => {
                        if (el) verseRefs.current.set(verse.number, el);
                        else verseRefs.current.delete(verse.number);
                      }}
                      id={`ayah-1-${verse.number}`}
                      className={`inline transition-all duration-200 rounded px-1 select-text ${
                        currentPlayingVerse === verse.number
                          ? 'bg-emerald-200/90 dark:bg-emerald-950/90 text-emerald-950 dark:text-emerald-100 ring-2 ring-emerald-500 rounded-lg shadow-sm font-semibold'
                          : isPulsing
                          ? 'verse-highlight-active'
                          : isSaved
                          ? 'bg-amber-100/70 dark:bg-amber-950/40 text-emerald-950 dark:text-emerald-200 border-b-2 border-amber-500'
                          : 'hover:bg-emerald-500/10 dark:hover:bg-emerald-500/15'
                      }`}
                    >
                      <span className="inline align-middle">
                        <TajweedVerseText 
                          text={verse.text} 
                          enabled={tajweedActive} 
                          onRuleClick={onOpenTajweedLegend} 
                        />
                      </span>

                      {/* Interactive Ayah End Circle Badge & Favorite indicator */}
                      <span
                        onPointerDown={(e) => e.stopPropagation()}
                        onPointerUp={(e) => e.stopPropagation()}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onOpenAyahModal) {
                            onOpenAyahModal(verse);
                          } else {
                            onSaveVerse(verse.number);
                          }
                        }}
                        className="inline-flex items-center gap-1 cursor-pointer hover:scale-115 active:scale-95 transition-transform align-middle mx-1"
                        title="خيارات الآية (حفظ في المفضلة، موضع التوقف، نسخ)"
                      >
                        <AyahEndBadge number={verse.number} />
                        {isVerseFavorite && isVerseFavorite(verse.number) && (
                          <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500 inline align-middle animate-in zoom-in-50" />
                        )}
                      </span>
                      {' '}
                    </span>
                  </React.Fragment>
                );
              })}
            </div>

          </div>

          {/* BOTTOM ORNAMENTAL CLOSING FINIAL (خاتمة إطار سورة الفاتحة) */}
          <footer className="relative mt-5 sm:mt-8 pt-4 sm:pt-6 border-t border-amber-500/30 dark:border-amber-400/25 flex flex-col items-center justify-center text-center space-y-2">
            
            {/* Ornate Medallion */}
            <div className="flex items-center gap-3 text-amber-700 dark:text-amber-400">
              <span className="w-8 sm:w-14 h-px bg-gradient-to-l from-amber-600 to-transparent" />
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30">
                <span className="text-xs">۞</span>
                <span className="font-amiri text-sm sm:text-base font-bold text-emerald-950 dark:text-emerald-200">
                  خاتمة سورة الفاتحة
                </span>
                <span className="text-xs">۞</span>
              </div>
              <span className="w-8 sm:w-14 h-px bg-gradient-to-r from-amber-600 to-transparent" />
            </div>

            <p className="text-[11px] sm:text-xs text-stone-500 dark:text-stone-400 font-sans">
              أمُّ الكتاب وفاتحة القرآن الكريم برواية ورش عن نافع
            </p>
          </footer>

        </div>
      </div>
    </div>
  );
};
