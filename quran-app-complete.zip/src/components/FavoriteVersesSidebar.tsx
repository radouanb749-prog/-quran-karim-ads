import React, { useState, useEffect, useMemo } from 'react';
import { 
  Heart, 
  X, 
  Search, 
  Trash2, 
  ExternalLink, 
  Copy, 
  Check, 
  Share2, 
  ArrowRight,
  BookOpen,
  Sparkles,
  ArrowUpDown
} from 'lucide-react';
import { 
  FavoriteVerse, 
  getFavoriteVerses, 
  removeFavoriteVerse, 
  clearAllFavoriteVerses, 
  subscribeToFavoriteVersesChange 
} from '../services/favoriteVersesService';

interface FavoriteVersesSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectVerse: (surahNumber: number, verseNumber: number) => void;
}

export const FavoriteVersesSidebar: React.FC<FavoriteVersesSidebarProps> = ({
  isOpen,
  onClose,
  onSelectVerse,
}) => {
  const [favoriteVerses, setFavoriteVerses] = useState<FavoriteVerse[]>(() => getFavoriteVerses());
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'date' | 'mushaf'>('date');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Subscribe to changes
  useEffect(() => {
    const unsubscribe = subscribeToFavoriteVersesChange(() => {
      setFavoriteVerses(getFavoriteVerses());
    });
    return () => unsubscribe();
  }, []);

  // Update when drawer opens
  useEffect(() => {
    if (isOpen) {
      setFavoriteVerses(getFavoriteVerses());
    }
  }, [isOpen]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const handleCopy = async (verse: FavoriteVerse) => {
    try {
      const textToCopy = `﴿ ${verse.verseText} ﴾\n[سورة ${verse.surahName}: الآية ${verse.verseNumber}]`;
      await navigator.clipboard.writeText(textToCopy);
      setCopiedId(verse.id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      // Fallback
    }
  };

  const handleShare = async (verse: FavoriteVerse) => {
    const shareText = `﴿ ${verse.verseText} ﴾\n[سورة ${verse.surahName}: الآية ${verse.verseNumber}]`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `آية من سورة ${verse.surahName}`,
          text: shareText,
        });
      } catch {
        handleCopy(verse);
      }
    } else {
      handleCopy(verse);
    }
  };

  const handleRemove = (surahNumber: number, verseNumber: number) => {
    removeFavoriteVerse(surahNumber, verseNumber);
    setFavoriteVerses(getFavoriteVerses());
  };

  const handleClearAll = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في حذف جميع الآيات من المفضلة؟')) {
      clearAllFavoriteVerses();
      setFavoriteVerses([]);
    }
  };

  // Filter & sort verses
  const filteredVerses = useMemo(() => {
    let list = [...favoriteVerses];

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      list = list.filter(
        (v) =>
          v.verseText.toLowerCase().includes(q) ||
          v.surahName.toLowerCase().includes(q) ||
          v.verseNumber.toString() === q
      );
    }

    if (sortBy === 'date') {
      list.sort((a, b) => b.addedAt - a.addedAt);
    } else {
      // Mushaf order: sort by surah then verse
      list.sort((a, b) => {
        if (a.surahNumber !== b.surahNumber) {
          return a.surahNumber - b.surahNumber;
        }
        return a.verseNumber - b.verseNumber;
      });
    }

    return list;
  }, [favoriteVerses, searchQuery, sortBy]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end" dir="rtl">
      {/* Backdrop overlay */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Slide-over Drawer Panel */}
      <aside 
        className="relative w-full max-w-md bg-stone-50 dark:bg-stone-900 border-r border-stone-200 dark:border-stone-800 shadow-2xl flex flex-col h-full z-10 animate-in slide-in-from-right duration-250 ease-out"
        role="dialog"
        aria-modal="true"
        aria-label="قائمة الآيات المفضلة"
      >
        {/* Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 dark:border-stone-800 bg-white/80 dark:bg-stone-950/80 backdrop-blur-md flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 flex items-center justify-center text-rose-600 dark:text-rose-400 shadow-xs">
              <Heart className="w-5 h-5 fill-rose-500 text-rose-500" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-base sm:text-lg text-stone-900 dark:text-stone-100">
                  الآيات المفضلة
                </h2>
                <span className="text-xs px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 font-bold border border-rose-200/60 dark:border-rose-800/60">
                  {favoriteVerses.length.toLocaleString('ar-EG')}
                </span>
              </div>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">
                الآيات الكريمة التي قمت بحفظها لسرعة العودة والتدبر
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
            title="إغلاق القائمة"
            aria-label="إغلاق القائمة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Sorting Toolbar */}
        {favoriteVerses.length > 0 && (
          <div className="p-3 sm:p-4 border-b border-stone-200/80 dark:border-stone-800 bg-white dark:bg-stone-900/60 space-y-2.5">
            <div className="relative">
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-stone-400">
                <Search className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث في الآيات المفضلة أو اسم السورة..."
                className="w-full pl-8 pr-9 py-2 rounded-xl bg-stone-100 dark:bg-stone-800 border border-stone-200/80 dark:border-stone-700 text-xs sm:text-sm text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-700"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute inset-y-0 left-0 pl-2.5 flex items-center text-stone-400 hover:text-stone-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              {/* Sort Switcher */}
              <div className="flex items-center gap-1.5 text-stone-600 dark:text-stone-400">
                <ArrowUpDown className="w-3.5 h-3.5" />
                <span>الترتيب:</span>
                <button
                  type="button"
                  onClick={() => setSortBy('date')}
                  className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
                    sortBy === 'date'
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold'
                      : 'hover:text-stone-900 dark:hover:text-stone-200'
                  }`}
                >
                  الأحدث
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => setSortBy('mushaf')}
                  className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
                    sortBy === 'mushaf'
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold'
                      : 'hover:text-stone-900 dark:hover:text-stone-200'
                  }`}
                >
                  المصحف
                </button>
              </div>

              {/* Clear All Button */}
              <button
                type="button"
                onClick={handleClearAll}
                className="text-[11px] text-stone-400 hover:text-rose-600 transition-colors"
                title="مسح الكل"
              >
                مسح الكل
              </button>
            </div>
          </div>
        )}

        {/* Drawer Content / List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filteredVerses.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 flex items-center justify-center text-rose-500">
                <Heart className="w-8 h-8 text-rose-400 fill-rose-500/20" />
              </div>
              <div className="space-y-1.5">
                <h3 className="font-bold text-base text-stone-900 dark:text-stone-100">
                  {searchQuery ? 'لا توجد نتائج مطابقة' : 'لا توجد آيات مفضلة حتى الآن'}
                </h3>
                <p className="text-xs text-stone-500 dark:text-stone-400 max-w-xs leading-relaxed">
                  {searchQuery
                    ? 'جرب البحث بكلمات أخرى أو مسح حقل البحث.'
                    : 'أثناء قراءتك في المصحف، اضغط على رمز القلب ❤️ بجانب أي آية كريمة لإضافتها إلى قائمتك المفضلة والعودة إليها بنقرة واحدة.'}
                </p>
              </div>
            </div>
          ) : (
            filteredVerses.map((verse) => (
              <div
                key={verse.id}
                className="bg-white dark:bg-stone-850 rounded-2xl p-4 border border-stone-200/90 dark:border-stone-800 shadow-xs hover:border-emerald-500/50 transition-all space-y-3 group"
              >
                {/* Verse Card Header */}
                <div className="flex items-center justify-between gap-2 border-b border-stone-100 dark:border-stone-800 pb-2.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-sm text-emerald-950 dark:text-emerald-200">
                      سورة {verse.surahName}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100/70 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-mono font-medium">
                      الآية {verse.verseNumber.toLocaleString('ar-EG')}
                    </span>
                    {verse.juz && (
                      <span className="text-[11px] text-stone-400">
                        الجزء {verse.juz.toLocaleString('ar-EG')}
                      </span>
                    )}
                  </div>

                  {/* Actions: Copy & Delete */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleCopy(verse)}
                      className="p-1.5 rounded-lg text-stone-400 hover:text-emerald-700 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
                      title="نسخ نص الآية"
                    >
                      {copiedId === verse.id ? (
                        <Check className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleShare(verse)}
                      className="p-1.5 rounded-lg text-stone-400 hover:text-emerald-700 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
                      title="مشاركة الآية"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleRemove(verse.surahNumber, verse.verseNumber)}
                      className="p-1.5 rounded-lg text-stone-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                      title="إزالة من المفضلة"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Verse Arabic Text */}
                <div className="select-text">
                  <p className="font-amiri text-base sm:text-lg text-stone-900 dark:text-stone-100 leading-loose text-justify">
                    ﴿ {verse.verseText} ﴾
                  </p>
                </div>

                {/* Go To Verse In Reader Button */}
                <div className="pt-1 flex items-center justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      onSelectVerse(verse.surahNumber, verse.verseNumber);
                      onClose();
                    }}
                    className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white dark:bg-emerald-700 dark:hover:bg-emerald-600 text-xs font-bold shadow-xs active:scale-95 transition-all"
                  >
                    <span>فتح وتلاوة في المصحف</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Drawer Footer */}
        {favoriteVerses.length > 0 && (
          <div className="p-3 border-t border-stone-200 dark:border-stone-800 bg-white/60 dark:bg-stone-950/60 text-center text-xs text-stone-500 dark:text-stone-400">
            يمكنك حفظ المزيد من الآيات في أي وقت أثناء التلاوة بالضغط على رمز القلب ❤️
          </div>
        )}
      </aside>
    </div>
  );
};
