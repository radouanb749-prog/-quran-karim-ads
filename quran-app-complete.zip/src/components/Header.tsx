import React from 'react';
import { Moon, Sun, BookOpen, Share2, Sparkles, Heart, Calendar, CircleDot } from 'lucide-react';

interface HeaderProps {
  darkMode: boolean;
  toggleDarkMode: () => void;
  onShare?: () => void;
  onLogoClick?: () => void;
  activeSection?: 'quran' | 'adhkar' | 'khatmah' | 'tasbih';
  onSectionChange?: (section: 'quran' | 'adhkar' | 'khatmah' | 'tasbih') => void;
  favoriteAdhkarCount?: number;
  favoriteVersesCount?: number;
  onOpenFavoriteVerses?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  darkMode, 
  toggleDarkMode, 
  onShare,
  onLogoClick,
  activeSection = 'quran',
  onSectionChange,
  favoriteAdhkarCount = 0,
  favoriteVersesCount = 0,
  onOpenFavoriteVerses,
}) => {
  return (
    <header className="sticky top-0 z-30 border-b border-stone-200/80 dark:border-stone-800 bg-stone-50/90 dark:bg-stone-950/90 backdrop-blur-md transition-colors duration-200">
      <div className="max-w-5xl mx-auto px-2 sm:px-6 py-1.5 sm:py-0 sm:h-16 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 sm:gap-2">
        
        {/* Main Row on Mobile (or Left/Center on Desktop): Logo & Navigation Tabs */}
        <div className="flex items-center justify-between gap-1.5 sm:gap-4 w-full sm:w-auto">
          {/* App Title & Official Logo */}
          <div 
            onClick={onLogoClick} 
            role={onLogoClick ? "button" : undefined}
            tabIndex={onLogoClick ? 0 : undefined}
            className={`flex items-center gap-1.5 sm:gap-2.5 shrink-0 ${onLogoClick ? 'cursor-pointer select-none group' : ''}`}
          >
            <div className="w-8 h-8 sm:w-11 sm:h-11 rounded-xl overflow-hidden shadow-xs ring-1 ring-emerald-800/20 dark:ring-emerald-500/30 group-hover:scale-105 transition-transform shrink-0 bg-emerald-950">
              <img
                src="/app-logo.png"
                alt="شعار تطبيق القرآن الكريم"
                className="w-full h-full object-cover select-none"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h1 className="font-amiri text-base sm:text-2xl font-bold tracking-tight text-emerald-950 dark:text-emerald-100 flex items-center gap-1 sm:gap-2">
                <span className="group-hover:text-emerald-700 dark:group-hover:text-emerald-300 transition-colors">المصحف</span>
                <span className="hidden md:inline-block text-[11px] sm:text-xs px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-sans font-medium border border-emerald-200/60 dark:border-emerald-800/60">
                  القرآن الكريم
                </span>
              </h1>
            </div>
          </div>

          {/* Center / Navigation Switcher (المصحف / الأذكار / الختمة / السبحة) */}
          {onSectionChange && (
            <nav className="flex items-center bg-stone-200/70 dark:bg-stone-900 p-0.5 sm:p-1 rounded-xl sm:rounded-2xl border border-stone-200 dark:border-stone-800 shadow-inner shrink-0">
              <button
                type="button"
                onClick={() => onSectionChange('quran')}
                className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg sm:rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 ${
                  activeSection === 'quran'
                    ? 'bg-white dark:bg-stone-800 text-emerald-800 dark:text-emerald-300 shadow-xs'
                    : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>المصحف</span>
              </button>
              <button
                type="button"
                onClick={() => onSectionChange('adhkar')}
                className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg sm:rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 relative ${
                  activeSection === 'adhkar'
                    ? 'bg-white dark:bg-stone-800 text-emerald-800 dark:text-emerald-300 shadow-xs'
                    : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>الأذكار</span>
                {favoriteAdhkarCount > 0 && (
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 inline-block" title="توجد أذكار مفضلة" />
                )}
              </button>
              <button
                type="button"
                onClick={() => onSectionChange('khatmah')}
                className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg sm:rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 relative ${
                  activeSection === 'khatmah'
                    ? 'bg-white dark:bg-stone-800 text-emerald-800 dark:text-emerald-300 shadow-xs'
                    : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
                }`}
              >
                <Calendar className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>الختمة</span>
              </button>
              <button
                type="button"
                onClick={() => onSectionChange('tasbih')}
                className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg sm:rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 relative ${
                  activeSection === 'tasbih'
                    ? 'bg-white dark:bg-stone-800 text-emerald-800 dark:text-emerald-300 shadow-xs'
                    : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
                }`}
              >
                <CircleDot className="w-3.5 h-3.5 text-amber-500" />
                <span>السبحة</span>
              </button>
            </nav>
          )}
        </div>

        {/* Row 2 on Mobile (Under the navigation buttons): Action buttons (المفضلة، مشاركة، الوضع الليلي) */}
        <div className="flex items-center justify-end sm:justify-start gap-1 sm:gap-2 w-full sm:w-auto pt-0.5 sm:pt-0">
          {/* Favorite Verses Drawer Button */}
          {onOpenFavoriteVerses && (
            <button
              onClick={onOpenFavoriteVerses}
              type="button"
              className="flex items-center gap-1 sm:flex-col sm:justify-center px-2 py-0.5 sm:py-1 rounded-lg sm:rounded-xl text-stone-700 dark:text-stone-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-stone-200 dark:border-stone-800 transition-colors focus:outline-hidden focus:ring-2 focus:ring-emerald-700/40 active:scale-95 relative sm:min-w-[48px]"
              aria-label="الآيات المفضلة"
              title="عرض الآيات المفضلة"
            >
              <Heart className={`w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[2] ${favoriteVersesCount > 0 ? 'fill-rose-500 text-rose-500' : 'text-stone-600 dark:text-stone-400'}`} />
              <span className="text-[10px] font-medium leading-tight">المفضلة</span>
              {favoriteVersesCount > 0 && (
                <span className="bg-rose-500 text-white text-[9px] font-bold px-1 rounded-full flex items-center justify-center">
                  {favoriteVersesCount > 9 ? '+9' : favoriteVersesCount}
                </span>
              )}
            </button>
          )}

          {/* Share Button */}
          {onShare && (
            <button
              onClick={onShare}
              type="button"
              className="flex items-center gap-1 sm:flex-col sm:justify-center px-2 py-0.5 sm:py-1 rounded-lg sm:rounded-xl text-stone-700 dark:text-stone-300 hover:bg-stone-200/60 dark:hover:bg-stone-800 border border-stone-200 dark:border-stone-800 transition-colors focus:outline-hidden focus:ring-2 focus:ring-emerald-700/40 active:scale-95 sm:min-w-[48px]"
              aria-label="مشاركة التطبيق"
              title="مشاركة"
            >
              <Share2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-800 dark:text-emerald-400 stroke-[2]" />
              <span className="text-[10px] font-medium leading-tight">مشاركة</span>
            </button>
          )}

          {/* Dark Mode Toggle Button */}
          <button
            onClick={toggleDarkMode}
            type="button"
            className="flex items-center gap-1 sm:flex-col sm:justify-center px-2 py-0.5 sm:py-1 rounded-lg sm:rounded-xl text-stone-700 dark:text-stone-300 hover:bg-stone-200/60 dark:hover:bg-stone-800 border border-stone-200 dark:border-stone-800 transition-colors focus:outline-hidden focus:ring-2 focus:ring-emerald-700/40 active:scale-95 sm:min-w-[48px]"
            aria-label={darkMode ? 'التبديل إلى الوضع النهاري' : 'التبديل إلى الوضع الليلي'}
            title={darkMode ? 'الوضع النهاري' : 'الوضع الليلي'}
          >
            {darkMode ? (
              <>
                <Sun className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400 stroke-[2]" />
                <span className="text-[10px] font-medium leading-tight">النهاري</span>
              </>
            ) : (
              <>
                <Moon className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-900 dark:text-emerald-400 stroke-[2]" />
                <span className="text-[10px] font-medium leading-tight">الليلي</span>
              </>
            )}
          </button>
        </div>

      </div>
    </header>
  );
};
