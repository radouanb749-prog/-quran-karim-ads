import React from 'react';

interface IslamicStarBadgeProps {
  number: number;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const IslamicStarBadge: React.FC<IslamicStarBadgeProps> = ({
  number,
  className = '',
  size = 'md',
}) => {
  const sizeMap = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-14 h-14 text-lg font-bold',
  };

  // Convert numbers to Arabic-Indic digits or standard Arabic numerals
  // Many readers appreciate standard Arabic numerals (١, ٢, ٣...) or standard numerals
  const arabicDigits = number.toLocaleString('ar-EG');

  return (
    <div
      className={`relative inline-flex items-center justify-center font-amiri font-semibold select-none shrink-0 ${sizeMap[size]} ${className}`}
    >
      <svg
        viewBox="0 0 40 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="absolute inset-0 w-full h-full text-emerald-700/20 dark:text-emerald-400/30 group-hover:text-emerald-700/30 transition-colors"
      >
        {/* Eight-pointed Islamic star (Rub el Hizb inspired) */}
        <rect
          x="7"
          y="7"
          width="26"
          height="26"
          rx="2"
          className="stroke-emerald-800 dark:stroke-emerald-400"
          strokeWidth="1.5"
          fill="currentColor"
        />
        <rect
          x="7"
          y="7"
          width="26"
          height="26"
          rx="2"
          transform="rotate(45 20 20)"
          className="stroke-emerald-800 dark:stroke-emerald-400"
          strokeWidth="1.5"
          fill="currentColor"
        />
        <circle cx="20" cy="20" r="11" className="fill-stone-50 dark:fill-stone-900" />
      </svg>
      <span className="relative z-10 text-emerald-900 dark:text-emerald-300 font-bold">
        {arabicDigits}
      </span>
    </div>
  );
};
