import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Repeat, 
  Repeat1, 
  Volume2, 
  VolumeX, 
  X, 
  Sparkles, 
  ChevronUp, 
  ChevronDown, 
  User, 
  Gauge, 
  Loader2,
  Check,
  Disc3,
  SlidersHorizontal
} from 'lucide-react';
import { 
  Reciter, 
  RECITERS, 
  RepeatMode, 
  REPEAT_OPTIONS, 
  getAyahAudioUrl, 
  saveSelectedReciter, 
  saveSelectedRepeatMode 
} from '../services/quranAudioService';
import { Surah } from '../data/surahs';
import { Verse } from '../services/quranService';

interface QuranAudioPlayerBarProps {
  surah: Surah;
  verses: Verse[];
  currentPlayingVerseNumber: number | null;
  isPlaying: boolean;
  onPlayVerse: (verseNumber: number) => void;
  onPause: () => void;
  onResume: () => void;
  onClose: () => void;
  selectedReciter: Reciter;
  onChangeReciter: (reciter: Reciter) => void;
  repeatMode: RepeatMode;
  onChangeRepeatMode: (mode: RepeatMode) => void;
  repeatCount: number;
}

export const QuranAudioPlayerBar: React.FC<QuranAudioPlayerBarProps> = ({
  surah,
  verses,
  currentPlayingVerseNumber,
  isPlaying,
  onPlayVerse,
  onPause,
  onResume,
  onClose,
  selectedReciter,
  onChangeReciter,
  repeatMode,
  onChangeRepeatMode,
  repeatCount,
}) => {
  const [showRecitersModal, setShowRecitersModal] = useState(false);
  const [showRepeatModal, setShowRepeatModal] = useState(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  if (currentPlayingVerseNumber === null) return null;

  const currentVerse = verses.find((v) => v.number === currentPlayingVerseNumber);
  const currentRepeatOption = REPEAT_OPTIONS.find((r) => r.mode === repeatMode) || REPEAT_OPTIONS[0];

  const handleNextVerse = () => {
    if (currentPlayingVerseNumber < verses.length) {
      onPlayVerse(currentPlayingVerseNumber + 1);
    }
  };

  const handlePrevVerse = () => {
    if (currentPlayingVerseNumber > 1) {
      onPlayVerse(currentPlayingVerseNumber - 1);
    }
  };

  const cyclePlaybackRate = () => {
    const rates = [1, 1.25, 0.75];
    const nextIdx = (rates.indexOf(playbackRate) + 1) % rates.length;
    setPlaybackRate(rates[nextIdx]);
  };

  return (
    <div 
      className="fixed bottom-0 inset-x-0 z-40 p-2 sm:p-4 pointer-events-none"
      dir="rtl"
    >
      <div 
        className="max-w-4xl mx-auto bg-stone-900/95 dark:bg-stone-950/95 text-stone-100 rounded-2xl sm:rounded-3xl shadow-2xl border border-stone-800 backdrop-blur-md pointer-events-auto p-3 sm:p-4 transition-all animate-in slide-in-from-bottom duration-300"
      >
        {/* Main Player Row */}
        <div className="flex items-center justify-between gap-2 sm:gap-4">
          
          {/* Right/Info: Surah, Verse, Reciter */}
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
            <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-emerald-900/80 border border-emerald-700/60 flex items-center justify-center shrink-0 shadow-inner">
              <span className="font-mono font-bold text-xs sm:text-sm text-emerald-300">
                {currentPlayingVerseNumber.toLocaleString('ar-EG')}
              </span>
              {isPlaying && (
                <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
              )}
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h4 className="font-bold text-xs sm:text-sm text-stone-100 truncate">
                  سورة {surah.name}
                </h4>
                <span className="text-[11px] text-emerald-400 font-medium">
                  • الآية {currentPlayingVerseNumber.toLocaleString('ar-EG')}
                </span>
                {repeatMode !== 'none' && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                    {currentRepeatOption.badge}
                    {currentRepeatOption.maxRepeats > 1 && ` (${repeatCount}/${currentRepeatOption.maxRepeats})`}
                  </span>
                )}
              </div>

              {/* Reciter trigger button */}
              <button
                type="button"
                onClick={() => setShowRecitersModal(true)}
                className="text-[11px] text-stone-400 hover:text-emerald-300 flex items-center gap-1 transition-colors mt-0.5"
                title="تغيير القارئ (الافتراضي: الشيخ محمود خليل الحصري)"
              >
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                <span className="truncate max-w-[140px] sm:max-w-xs font-medium text-emerald-200">{selectedReciter.name}</span>
                <span className="text-[10px] text-emerald-400">▼</span>
              </button>
            </div>
          </div>

          {/* Center: Controls (Prev, Play/Pause, Next) */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Previous Verse (In Arabic RTL, Right is Previous) */}
            <button
              type="button"
              onClick={handlePrevVerse}
              disabled={currentPlayingVerseNumber <= 1}
              className="p-2 sm:p-2.5 rounded-xl text-stone-300 hover:text-white hover:bg-white/10 disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
              title="الآية السابقة"
            >
              <SkipForward className="w-4 h-4" />
            </button>

            {/* Play / Pause Main Button */}
            <button
              type="button"
              onClick={isPlaying ? onPause : onResume}
              className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white flex items-center justify-center shadow-lg transition-all"
              title={isPlaying ? 'إيقاف مؤقت' : 'تشغيل'}
            >
              {isPlaying ? (
                <Pause className="w-5 h-5 fill-current" />
              ) : (
                <Play className="w-5 h-5 fill-current ml-0.5" />
              )}
            </button>

            {/* Next Verse */}
            <button
              type="button"
              onClick={handleNextVerse}
              disabled={currentPlayingVerseNumber >= verses.length}
              className="p-2 sm:p-2.5 rounded-xl text-stone-300 hover:text-white hover:bg-white/10 disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
              title="الآية التالية"
            >
              <SkipBack className="w-4 h-4" />
            </button>
          </div>

          {/* Left: Repetition & Secondary Tools */}
          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            
            {/* Repetition Toggle Button */}
            <button
              type="button"
              onClick={() => setShowRepeatModal(true)}
              className={`p-2 sm:px-2.5 sm:py-2 rounded-xl text-xs font-semibold flex items-center gap-1 border transition-colors ${
                repeatMode !== 'none'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-xs'
                  : 'bg-white/5 hover:bg-white/10 text-stone-300 border-white/10'
              }`}
              title="التحكم في تكرار التلاوة"
            >
              <Repeat className={`w-3.5 h-3.5 ${repeatMode !== 'none' ? 'text-amber-400' : 'text-stone-400'}`} />
              <span className="hidden md:inline">{currentRepeatOption.badge}</span>
            </button>

            {/* Close / Stop Audio Button */}
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-white/10 transition-colors"
              title="إغلاق المشغل الصوتي"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

        </div>

        {/* Small Verse Text Preview */}
        {currentVerse && (
          <div className="mt-2 pt-2 border-t border-stone-800/80 text-center">
            <p className="font-amiri text-xs sm:text-sm text-stone-300 truncate px-2 select-text">
              ﴿ {currentVerse.text} ﴾
            </p>
          </div>
        )}
      </div>

      {/* Reciter Selector Modal */}
      {showRecitersModal && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs pointer-events-auto"
          onClick={() => setShowRecitersModal(false)}
        >
          <div 
            className="w-full max-w-sm bg-stone-900 border border-stone-800 rounded-3xl shadow-2xl p-5 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2">
                <User className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm sm:text-base text-stone-100">
                  اختر القارئ الصوتي
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowRecitersModal(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5 max-h-72 overflow-y-auto">
              {RECITERS.map((reciter) => {
                const isSelected = selectedReciter.id === reciter.id;
                return (
                  <button
                    key={reciter.id}
                    type="button"
                    onClick={() => {
                      onChangeReciter(reciter);
                      saveSelectedReciter(reciter.id);
                      setShowRecitersModal(false);
                    }}
                    className={`w-full p-3 rounded-2xl flex items-center justify-between transition-all ${
                      isSelected
                        ? 'bg-emerald-900/60 border border-emerald-600/80 text-white font-bold shadow-xs'
                        : 'bg-stone-800/60 hover:bg-stone-800 border border-stone-700/50 text-stone-300'
                    }`}
                  >
                    <div className="text-right">
                      <div className="text-xs sm:text-sm">{reciter.name}</div>
                      {reciter.subName && (
                        <div className="text-[10px] text-stone-400">{reciter.subName}</div>
                      )}
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-emerald-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Repeat Mode Selector Modal */}
      {showRepeatModal && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs pointer-events-auto"
          onClick={() => setShowRepeatModal(false)}
        >
          <div 
            className="w-full max-w-sm bg-stone-900 border border-stone-800 rounded-3xl shadow-2xl p-5 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2">
                <Repeat className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm sm:text-base text-stone-100">
                  إعدادات تكرار التلاوة
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowRepeatModal(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-stone-400 leading-relaxed">
              خاصية ممتازة لتثبيت الحفظ والتدبر، كرر الآية الواحدة عدداً محدداً من المرات أو كرر السورة كاملة.
            </p>

            <div className="space-y-1.5 max-h-72 overflow-y-auto">
              {REPEAT_OPTIONS.map((option) => {
                const isSelected = repeatMode === option.mode;
                return (
                  <button
                    key={option.mode}
                    type="button"
                    onClick={() => {
                      onChangeRepeatMode(option.mode);
                      saveSelectedRepeatMode(option.mode);
                      setShowRepeatModal(false);
                    }}
                    className={`w-full p-3 rounded-2xl flex items-center justify-between transition-all ${
                      isSelected
                        ? 'bg-amber-950/60 border border-amber-600/80 text-white font-bold shadow-xs'
                        : 'bg-stone-800/60 hover:bg-stone-800 border border-stone-700/50 text-stone-300'
                    }`}
                  >
                    <div className="text-right">
                      <div className="text-xs sm:text-sm">{option.label}</div>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
