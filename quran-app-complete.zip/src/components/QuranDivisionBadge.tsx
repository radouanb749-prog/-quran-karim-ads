import React, { useState } from 'react';
import { QuranDivisionMarker } from '../data/quranDivisions';

interface QuranDivisionBadgeProps {
  marker: QuranDivisionMarker;
  mode?: 'inline' | 'banner';
  onClick?: () => void;
}

export const QuranDivisionBadge: React.FC<QuranDivisionBadgeProps> = ({
  marker,
  mode = 'inline',
  onClick,
}) => {
  const [showTooltip, setShowTooltip] = useState(false);

  // Determine color scheme based on division type
  const getStyleClasses = () => {
    switch (marker.type) {
      case 'juz':
        return {
          pill: 'bg-gradient-to-r from-amber-500/15 via-amber-400/20 to-amber-500/15 text-amber-900 dark:text-amber-200 border-amber-400/50 dark:border-amber-600/60 shadow-xs ring-1 ring-amber-400/30',
          starColor: 'text-amber-600 dark:text-amber-400',
          lineColor: 'from-transparent via-amber-400/40 to-transparent',
        };
      case 'hizb':
        return {
          pill: 'bg-emerald-500/15 text-emerald-950 dark:text-emerald-200 border-emerald-400/50 dark:border-emerald-600/60 shadow-xs ring-1 ring-emerald-400/30',
          starColor: 'text-emerald-600 dark:text-emerald-400',
          lineColor: 'from-transparent via-emerald-500/40 to-transparent',
        };
      case 'hizbHalf':
        return {
          pill: 'bg-amber-500/10 text-amber-900 dark:text-amber-300 border-amber-300/40 dark:border-amber-700/50',
          starColor: 'text-amber-600 dark:text-amber-400',
          lineColor: 'from-transparent via-amber-400/30 to-transparent',
        };
      case 'hizbQuarter':
        return {
          pill: 'bg-teal-500/10 text-teal-900 dark:text-teal-300 border-teal-300/40 dark:border-teal-700/50',
          starColor: 'text-teal-600 dark:text-teal-400',
          lineColor: 'from-transparent via-teal-400/30 to-transparent',
        };
      case 'hizbEighth':
      default:
        return {
          pill: 'bg-stone-200/50 dark:bg-stone-800/60 text-stone-700 dark:text-stone-300 border-stone-300/60 dark:border-stone-700/60',
          starColor: 'text-stone-500 dark:text-stone-400',
          lineColor: 'from-transparent via-stone-300/40 dark:via-stone-700/40 to-transparent',
        };
    }
  };

  const styles = getStyleClasses();

  if (mode === 'banner') {
    return (
      <div 
        onPointerDown={(e) => e.stopPropagation()}
        onPointerUp={(e) => e.stopPropagation()}
        className="w-full my-4 py-2 flex items-center justify-center gap-3 select-none"
        dir="rtl"
      >
        <span className={`h-px flex-1 bg-gradient-to-r ${styles.lineColor}`} />
        
        <div 
          onClick={(e) => {
            e.stopPropagation();
            onClick?.();
          }}
          className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs sm:text-sm font-semibold transition-all duration-150 cursor-pointer hover:scale-102 ${styles.pill}`}
          title={`${marker.name} — ${marker.mathFraction}`}
        >
          <span className={`text-base font-bold ${styles.starColor}`}>۞</span>
          <span className="font-amiri tracking-wide">{marker.name}</span>
          <span className="text-[11px] px-1.5 py-0.5 rounded-md bg-white/40 dark:bg-black/20 opacity-85 font-mono">
            {marker.badge}
          </span>
        </div>

        <span className={`h-px flex-1 bg-gradient-to-l ${styles.lineColor}`} />
      </div>
    );
  }

  // Inline mode: fits naturally inside the continuous text flow between ayahs
  return (
    <span 
      onPointerDown={(e) => e.stopPropagation()}
      onPointerUp={(e) => e.stopPropagation()}
      className="relative inline-flex items-center align-middle mx-1.5 select-none"
      dir="rtl"
    >
      <span
        onClick={(e) => {
          e.stopPropagation();
          setShowTooltip((prev) => !prev);
          onClick?.();
        }}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        role="button"
        tabIndex={0}
        aria-label={marker.name}
        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 my-1 rounded-full border text-[11px] sm:text-xs font-semibold cursor-pointer transition-all duration-150 hover:shadow-sm hover:scale-105 active:scale-95 ${styles.pill}`}
      >
        <span className={`text-sm sm:text-base font-bold leading-none ${styles.starColor}`}>
          ۞
        </span>
        <span className="font-amiri font-bold tracking-wide">
          {marker.shortName}
        </span>
        {marker.type === 'juz' || marker.type === 'hizb' ? (
          <span className="font-mono text-[10px] px-1 rounded bg-black/5 dark:bg-white/10">
            {marker.type === 'juz' ? marker.juzNumber.toLocaleString('ar-EG') : marker.hizbNumber.toLocaleString('ar-EG')}
          </span>
        ) : null}
      </span>

      {/* Popover / Tooltip on tap or hover */}
      {showTooltip && (
        <span 
          className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-40 w-52 p-2.5 rounded-xl bg-stone-900/95 text-stone-100 text-[11px] leading-relaxed shadow-xl backdrop-blur-md border border-stone-700 text-center animate-in fade-in zoom-in-95 pointer-events-none"
        >
          <span className="block font-amiri font-bold text-amber-300 text-xs mb-1">
            ۞ {marker.name}
          </span>
          <span className="block text-stone-300 mb-0.5">
            العلاقة: {marker.mathFraction}
          </span>
          <span className="block text-stone-400 text-[10px]">
            الجزء {marker.juzNumber.toLocaleString('ar-EG')} • الحزب {marker.hizbNumber.toLocaleString('ar-EG')} • الثمن {marker.eighthInHizb.toLocaleString('ar-EG')} من ٨
          </span>
          <span className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-stone-900/95" />
        </span>
      )}
    </span>
  );
};
