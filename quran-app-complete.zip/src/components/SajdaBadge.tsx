import React from 'react';
import { SajdaMarker } from '../data/quranDivisions';

interface SajdaBadgeProps {
  marker: SajdaMarker;
  onClick?: () => void;
  mode?: 'inline' | 'pill' | 'banner';
}

export const SajdaBadge: React.FC<SajdaBadgeProps> = ({ 
  marker, 
  onClick,
  mode = 'inline' 
}) => {
  if (mode === 'banner') {
    return (
      <div
        onPointerDown={(e) => e.stopPropagation()}
        onPointerUp={(e) => e.stopPropagation()}
        onClick={(e) => {
          e.stopPropagation();
          if (onClick) onClick();
        }}
        className={`w-full my-3 p-3 rounded-2xl flex items-center justify-between gap-3 border transition-all ${
          onClick ? 'cursor-pointer hover:shadow-md hover:scale-[1.01] active:scale-[0.99]' : ''
        } bg-gradient-to-r from-amber-500/15 via-amber-500/10 to-amber-500/15 dark:from-amber-950/40 dark:via-amber-900/30 dark:to-amber-950/40 border-amber-500/40 dark:border-amber-600/50 shadow-xs`}
        title="انقر لعرض دعاء سجدة التلاوة والأحكام"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/25 text-amber-800 dark:text-amber-200 flex items-center justify-center font-serif text-lg font-bold shadow-2xs">
            ۩
          </div>
          <div>
            <div className="text-xs sm:text-sm font-bold text-amber-950 dark:text-amber-100 flex items-center gap-2">
              <span>موضع سجدة تلاوة</span>
              <span className="text-[10px] px-2 py-0.2 rounded-full bg-amber-500/25 text-amber-900 dark:text-amber-200 font-medium">
                {marker.type === 'obligatory' ? 'مؤكدة' : 'مستحبة'}
              </span>
            </div>
            <div className="text-[11px] text-amber-800/80 dark:text-amber-300/80">
              يُستحب للقارئ والمستمع السجود والدعاء بالمأثور
            </div>
          </div>
        </div>

        {onClick && (
          <span className="text-[11px] font-semibold text-amber-800 dark:text-amber-300 bg-white/80 dark:bg-stone-900/80 px-2.5 py-1 rounded-lg border border-amber-300/40 dark:border-amber-700/40 shrink-0">
            عرض الدعاء ۩
          </span>
        )}
      </div>
    );
  }

  return (
    <button
      type="button"
      onPointerDown={(e) => e.stopPropagation()}
      onPointerUp={(e) => e.stopPropagation()}
      onClick={(e) => {
        e.stopPropagation();
        if (onClick) onClick();
      }}
      className={`inline-flex items-center gap-1.5 mx-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold select-none align-middle transition-all ${
        onClick 
          ? 'cursor-pointer hover:scale-108 hover:shadow-xs active:scale-95 ring-1 ring-amber-500/30' 
          : 'cursor-default'
      } bg-gradient-to-r from-amber-500/20 via-amber-400/15 to-amber-500/20 text-amber-900 dark:text-amber-200 border border-amber-400/60 dark:border-amber-600/60 shadow-2xs`}
      title="موضع سجدة تلاوة - انقر لعرض دعاء وأحكام سجود التلاوة"
      aria-label="سجدة تلاوة - عرض الدعاء"
    >
      <span className="text-sm font-bold text-amber-700 dark:text-amber-300 font-serif">۩</span>
      <span className="font-amiri text-xs font-bold">{marker.name}</span>
      <span className="text-[10px] text-amber-700 dark:text-amber-400 font-sans hidden sm:inline">
        (دعاء السجدة)
      </span>
    </button>
  );
};
