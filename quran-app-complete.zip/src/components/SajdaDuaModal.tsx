import React, { useState } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  Volume2, 
  Sparkles, 
  BookOpen, 
  HelpCircle,
  Share2
} from 'lucide-react';
import { SajdaMarker } from '../data/quranDivisions';
import { Surah } from '../data/surahs';
import { Verse } from '../services/quranService';

interface SajdaDuaModalProps {
  isOpen: boolean;
  onClose: () => void;
  marker: SajdaMarker | null;
  surah: Surah;
  verse?: Verse | null;
  onPlayVerse?: (verseNumber: number) => void;
  onOpenTafsir?: (verse: Verse) => void;
}

export const DUA_SUJOOD_TILAWAT = [
  {
    id: 1,
    title: 'الدعاء المأثور الأول (الأشهر)',
    source: 'سنن أبي داود والترمذي والنسائي (صحيح)',
    arabic: '«سَجَدَ وَجْهِي لِلَّذِي خَلَقَهُ، وَصَوَّرَهُ، وَشَقَّ سَمْعَهُ وَبَصَرَهُ، بِحَوْلِهِ وَقُوَّتِهِ، ﴿فَتَبَارَكَ اللَّهُ أَحْسَنُ الْخَالِقِينَ﴾»',
  },
  {
    id: 2,
    title: 'الدعاء المأثور الثاني',
    source: 'جامع الترمذي وصحيح ابن حبان',
    arabic: '«اللَّهُمَّ اكْتُبْ لِي بِهَا عِنْدَكَ أَجْرًا، وَضَعْ عَنِّي بِهَا وِزْرًا، وَاجْعَلْهَا لِي عِنْدَكَ ذُخْرًا، وَتَقَبَّلْهَا مِنِّي كَمَا تَقَبَّلْتَهَا مِنْ عَبْدِكَ دَاوُدَ»',
  },
  {
    id: 3,
    title: 'التسبيح المشروع في السجود',
    source: 'صحيح مسلم',
    arabic: '«سُبْحَانَ رَبِّيَ الأَعْلَى» (ثلاث مرات)',
  },
];

export const SajdaDuaModal: React.FC<SajdaDuaModalProps> = ({
  isOpen,
  onClose,
  marker,
  surah,
  verse,
  onPlayVerse,
  onOpenTafsir,
}) => {
  const [copiedId, setCopiedId] = useState<number | null>(null);

  if (!isOpen || !marker) return null;

  const handleCopyDua = async (text: string, id: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {}
  };

  const handleShareAll = async () => {
    const combined = `[دعاء سجود التلاوة - سورة ${surah.name} الآية ${marker.verseNumber}]\n\n` +
      DUA_SUJOOD_TILAWAT.map((d) => `• ${d.title}:\n${d.arabic}`).join('\n\n');
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: `دعاء سجود التلاوة - سورة ${surah.name}`,
          text: combined,
        });
      } catch {
        handleCopyDua(combined, 999);
      }
    } else {
      handleCopyDua(combined, 999);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs"
      dir="rtl"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-lg bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between bg-gradient-to-r from-amber-500/10 via-stone-50/90 to-amber-500/10 dark:from-amber-950/40 dark:via-stone-900 dark:to-amber-950/40">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/20 dark:bg-amber-400/20 text-amber-700 dark:text-amber-300 flex items-center justify-center border border-amber-500/30 text-2xl font-serif select-none shadow-xs">
              ۩
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <span>سجدة تلاوة</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-900 dark:text-amber-200 font-semibold border border-amber-500/30">
                  {marker.type === 'obligatory' ? 'موضع سجدة مؤكدة' : 'موضع سجدة مستحبة'}
                </span>
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                سورة {surah.name} • الآية {marker.verseNumber.toLocaleString('ar-EG')} (السجدة رقم {marker.index.toLocaleString('ar-EG')} في القرآن الكريم)
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          
          {/* Ayah Snippet (if provided) */}
          {verse && (
            <div className="p-3.5 sm:p-4 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200/80 dark:border-stone-800 space-y-2">
              <div className="flex items-center justify-between text-[11px] text-stone-500">
                <span className="font-semibold text-amber-700 dark:text-amber-400 flex items-center gap-1">
                  <span>۩ موضع السجدة في الآية:</span>
                </span>
                <div className="flex items-center gap-2">
                  {onPlayVerse && (
                    <button
                      type="button"
                      onClick={() => onPlayVerse(verse.number)}
                      className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 hover:underline font-medium text-[11px]"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>استماع للآية</span>
                    </button>
                  )}
                  {onOpenTafsir && (
                    <button
                      type="button"
                      onClick={() => onOpenTafsir(verse)}
                      className="inline-flex items-center gap-1 text-amber-700 dark:text-amber-400 hover:underline font-medium text-[11px]"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>التفسير</span>
                    </button>
                  )}
                </div>
              </div>
              <p className="font-amiri text-base sm:text-lg text-emerald-950 dark:text-emerald-100 leading-relaxed text-center select-text">
                ﴿ {verse.text} ﴾
              </p>
            </div>
          )}

          {/* Title for Supplications */}
          <div className="flex items-center justify-between pt-1">
            <span className="text-xs font-bold text-stone-800 dark:text-stone-200 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>ما يُقال ويُدعى به في سجود التلاوة:</span>
            </span>
            <button
              type="button"
              onClick={handleShareAll}
              className="text-[11px] text-amber-700 dark:text-amber-400 hover:underline inline-flex items-center gap-1 font-semibold"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>مشاركة الأدعية</span>
            </button>
          </div>

          {/* Cards for each Dua */}
          <div className="space-y-3">
            {DUA_SUJOOD_TILAWAT.map((dua) => {
              const isCopied = copiedId === dua.id;
              return (
                <div 
                  key={dua.id}
                  className="p-3.5 sm:p-4 rounded-2xl bg-amber-500/5 dark:bg-amber-400/5 border border-amber-500/25 dark:border-amber-400/20 space-y-2 relative group"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-amber-900 dark:text-amber-200">
                      {dua.title}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyDua(dua.arabic, dua.id)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-white dark:bg-stone-800 border border-amber-300/40 dark:border-amber-700/40 text-stone-700 dark:text-stone-200 hover:bg-amber-100/50 transition-colors shadow-2xs"
                      title="نسخ الدعاء"
                    >
                      {isCopied ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span className="text-emerald-700 dark:text-emerald-400">تم النسخ</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3 text-stone-500" />
                          <span>نسخ</span>
                        </>
                      )}
                    </button>
                  </div>

                  <p className="font-amiri text-base sm:text-lg text-stone-900 dark:text-stone-100 leading-loose select-text bg-white/70 dark:bg-stone-900/60 p-3 rounded-xl border border-amber-200/50 dark:border-amber-900/40 text-justify">
                    {dua.arabic}
                  </p>

                  <div className="text-[10px] text-stone-400 dark:text-stone-500">
                    المصدر: {dua.source}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Fiqh Guide & Benefits */}
          <div className="p-3 sm:p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-300/40 dark:border-emerald-800/60 text-xs text-stone-700 dark:text-stone-300 space-y-1.5">
            <div className="font-bold text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>فائدة فقهية في صفة سجود التلاوة:</span>
            </div>
            <p className="text-[11px] leading-relaxed text-stone-600 dark:text-stone-300">
              • سجود التلاوة سُنّة مؤكدة؛ يسجد القارئ والمستمع سجدة واحدة يكبر فيها عند الهبوط، ويدعو بما تيسر من هذه الأدعية، ثم يرفع رأسه بدون تشهد ولا تسليم (خارج الصلاة).
            </p>
            <p className="text-[11px] leading-relaxed text-stone-600 dark:text-stone-300">
              • الراجح من أقوال أهل العلم أنه يصح للقارئ أن يسجد ولو كان على غير طهارة أو لم يستقبل القبلة تيسيراً للتدبر والخشوع.
            </p>
          </div>

        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 border-t border-stone-200 dark:border-stone-800 bg-stone-50/80 dark:bg-stone-950/80 flex items-center justify-between gap-2">
          <div className="text-[11px] text-stone-500">
            مجموع سجدات التلاوة في القرآن: <span className="font-bold text-amber-700 dark:text-amber-400">١٥ موضعاً</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm shadow-xs transition-colors active:scale-95"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
