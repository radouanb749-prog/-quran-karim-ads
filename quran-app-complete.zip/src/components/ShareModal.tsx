import React, { useState } from 'react';
import { X, Copy, Check, Share2, Send, MessageCircle, Download, ExternalLink, Sparkles } from 'lucide-react';
import { getShareUrl, APP_SHARE_INFO } from '../services/shareService';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const url = getShareUrl();
  const shareText = APP_SHARE_INFO.text || 'اقرأ القرآن الكريم برواية ورش';
  const shareTitle = APP_SHARE_INFO.title || 'القرآن الكريم';

  const handleCopy = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(url);
      } else {
        // Fallback for older browsers or restricted permissions
        const textarea = document.createElement('textarea');
        textarea.value = url;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const shareWhatsApp = () => {
    const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareText}\n${url}`)}`;
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  };

  const shareTelegram = () => {
    const tgUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(shareText)}`;
    window.open(tgUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in"
      onClick={onClose}
      dir="rtl"
    >
      <div 
        className="w-full max-w-lg bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl p-5 sm:p-6 overflow-hidden relative max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          type="button"
          aria-label="إغلاق"
          className="absolute top-4 left-4 p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Official App Logo */}
        <div className="flex items-center justify-center mb-3">
          <div className="w-14 h-14 rounded-2xl overflow-hidden shadow-md ring-1 ring-emerald-600/30 bg-emerald-950">
            <img
              src="/app-logo.png"
              alt="شعار القرآن الكريم"
              className="w-full h-full object-cover select-none"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Title & Description */}
        <div className="text-center mb-5">
          <h3 className="font-amiri text-2xl font-bold text-stone-900 dark:text-stone-100">
            مشاركة ونشر التطبيق
          </h3>
          <p className="text-stone-500 dark:text-stone-400 text-xs mt-1">
            رابط مباشر وتصدير كامل لملفات التطبيق مع كافة الميزات
          </p>
        </div>

        {/* Section 1: Direct Link */}
        <div className="space-y-3 mb-5">
          <label className="block text-xs font-bold text-stone-700 dark:text-stone-300">
            الرابط المباشر للتطبيق (يعمل في أي متصفح خارج المعاينة)
          </label>
          <div className="relative flex items-center">
            <input
              type="text"
              readOnly
              value={url}
              className="w-full py-2.5 pr-3 pl-24 rounded-2xl bg-stone-100 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 text-xs font-mono text-stone-700 dark:text-stone-300 focus:outline-hidden select-all"
            />
            <button
              onClick={handleCopy}
              type="button"
              className={`absolute left-1.5 top-1.5 bottom-1.5 px-3 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                copied
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs active:scale-95'
              }`}
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>تم النسخ!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>نسخ الرابط</span>
                </>
              )}
            </button>
          </div>

          {/* Quick Direct Social Channels */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={shareWhatsApp}
              type="button"
              className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-950 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200 text-xs font-semibold transition-colors"
            >
              <MessageCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>مشاركة عبر واتساب</span>
            </button>
            <button
              onClick={shareTelegram}
              type="button"
              className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-950 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-800 dark:text-stone-200 text-xs font-semibold transition-colors"
            >
              <Send className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              <span>مشاركة عبر تيليجرام</span>
            </button>
          </div>
        </div>

        {/* Section 2: Complete Project Download / Export Package */}
        <div className="rounded-2xl p-4 bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-800/60 space-y-3 mb-5">
          <div className="flex items-start gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-600 text-white shrink-0 mt-0.5 shadow-xs">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-xs sm:text-sm text-emerald-950 dark:text-emerald-200">
                تحميل حزمة المشروع كاملاً (ZIP) للنشر في المتاجر
              </h4>
              <p className="text-[11px] text-emerald-800/80 dark:text-emerald-300/80 leading-relaxed mt-0.5">
                حزمة أرشيف (ZIP) متكاملة تتضمن مشروع أندرويد جاهز للرفع على متجر Google Play مع إعلانات Unity Ads مدمجة برقم المعرف <span className="font-mono font-bold text-emerald-900 dark:text-emerald-100 bg-emerald-200/50 dark:bg-emerald-900/50 px-1.5 py-0.5 rounded">Game ID: 800394591</span>، بالإضافة إلى كود الويب كاملاً للنشر على الويب.
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1">
            <a
              href="/quran-app-complete.zip"
              download="quran-app-complete.zip"
              className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-all active:scale-95 text-center"
            >
              <Download className="w-4 h-4" />
              <span>تحميل المشروع كاملاً (ZIP)</span>
            </a>

            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-white dark:bg-stone-850 hover:bg-stone-50 border border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200 text-xs font-semibold transition-colors"
            >
              <span>فتح كنافذة مستقلة</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Done / Close Button */}
        <button
          onClick={onClose}
          type="button"
          className="w-full py-2.5 rounded-2xl bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 font-semibold text-xs transition-colors"
        >
          إغلاق
        </button>
      </div>
    </div>
  );
};
