import React from 'react';
import { Bookmark, BookOpen } from 'lucide-react';
import { Surah } from '../data/surahs';
import { IslamicStarBadge } from './IslamicStarBadge';

interface SurahCardProps {
  surah: Surah;
  isBookmarked: boolean;
  savedVerseNumber?: number | null;
  onSelect: (surah: Surah, verseNumber?: number) => void;
  onBookmark: (e: React.MouseEvent, surah: Surah) => void;
}

export const SurahCard: React.FC<SurahCardProps> = ({
  surah,
  isBookmarked,
  savedVerseNumber,
  onSelect,
  onBookmark,
}) => {
  return (
    <div
      onClick={() => onSelect(surah, savedVerseNumber || undefined)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onSelect(surah, savedVerseNumber || undefined);
        }
      }}
      className={`group relative flex items-center justify-between p-4 rounded-xl border transition-all duration-200 cursor-pointer text-right outline-hidden focus-visible:ring-2 focus-visible:ring-emerald-600 ${
        isBookmarked
          ? 'bg-emerald-50/80 dark:bg-emerald-950/30 border-emerald-500/60 dark:border-emerald-600/60 shadow-xs'
          : 'bg-white dark:bg-stone-900 border-stone-200/90 dark:border-stone-800 hover:border-emerald-600/40 dark:hover:border-emerald-500/40 hover:shadow-xs'
      }`}
    >
      <div className="flex items-center gap-3.5 min-w-0">
        <IslamicStarBadge number={surah.number} size="md" />

        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-amiri text-xl font-bold text-stone-900 dark:text-stone-100 group-hover:text-emerald-800 dark:group-hover:text-emerald-400 transition-colors truncate">
              سورة {surah.name}
            </h3>
            {isBookmarked && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-600 text-white font-medium">
                موضعي
              </span>
            )}
            {savedVerseNumber && !isBookmarked && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-700 dark:text-amber-300 font-medium border border-amber-400/30">
                آية {savedVerseNumber.toLocaleString('ar-EG')}
              </span>
            )}
          </div>
          
          <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400 mt-0.5">
            <span className="font-mono text-[11px] text-stone-400 dark:text-stone-500">
              {surah.englishName}
            </span>
            <span>•</span>
            <span>{surah.versesCount.toLocaleString('ar-EG')} آية</span>
            <span>•</span>
            <span className="inline-flex items-center gap-1">
              <BookOpen className="w-3 h-3 text-stone-400" />
              ص {surah.page.toLocaleString('ar-EG')}
            </span>
            <span>•</span>
            <span>جزء {surah.juz.toLocaleString('ar-EG')}</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <span
          className={`text-[11px] px-2 py-0.5 rounded-md font-medium ${
            surah.type === 'مكية'
              ? 'bg-amber-100/70 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800/50'
              : 'bg-emerald-100/70 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/50'
          }`}
        >
          {surah.type}
        </span>

        <button
          onClick={(e) => onBookmark(e, surah)}
          type="button"
          aria-label={isBookmarked ? 'محفوظة كموضع قراءة' : 'تحديد كموضع قراءة'}
          title={isBookmarked ? 'محفوظة كموضع قراءة' : 'تحديد كموضع قراءة'}
          className={`p-1.5 rounded-lg transition-colors ${
            isBookmarked
              ? 'text-amber-500 dark:text-amber-400 hover:bg-amber-100/50 dark:hover:bg-amber-950/50'
              : 'text-stone-300 dark:text-stone-600 hover:text-amber-500 dark:hover:text-amber-400 hover:bg-stone-100 dark:hover:bg-stone-800'
          }`}
        >
          <Bookmark
            className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`}
          />
        </button>
      </div>
    </div>
  );
};
