import React from 'react';
import { X, Bookmark, BookOpen, Layers, ChevronRight, ChevronLeft, Check } from 'lucide-react';
import { Surah } from '../data/surahs';
import { IslamicStarBadge } from './IslamicStarBadge';

interface SurahDetailsModalProps {
  surah: Surah | null;
  isOpen: boolean;
  onClose: () => void;
  isBookmarked: boolean;
  onBookmark: (surah: Surah) => void;
  onNavigateSurah: (direction: 'next' | 'prev') => void;
  onRead?: (surah: Surah) => void;
}

export const SurahDetailsModal: React.FC<SurahDetailsModalProps> = ({
  surah,
  isOpen,
  onClose,
  isBookmarked,
  onBookmark,
  onNavigateSurah,
  onRead,
}) => {
  if (!isOpen || !surah) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-xs transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-surah-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-stone-50 dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-200/80 dark:border-stone-800 bg-white/60 dark:bg-stone-950/40">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300">
              بطاقة السورة
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => onNavigateSurah('prev')}
              disabled={surah.number <= 1}
              aria-label="السورة السابقة"
              title="السورة السابقة"
              className="p-1.5 rounded-lg text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-200/60 dark:hover:bg-stone-800 disabled:opacity-30 disabled:pointer-events-none transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <button
              onClick={() => onNavigateSurah('next')}
              disabled={surah.number >= 114}
              aria-label="السورة التالية"
              title="السورة التالية"
              className="p-1.5 rounded-lg text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-200/60 dark:hover:bg-stone-800 disabled:opacity-30 disabled:pointer-events-none transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              aria-label="إغلاق"
              className="p-1.5 rounded-lg text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-200/60 dark:hover:bg-stone-800 transition-colors mr-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto">
          {/* Main Surah Card Header */}
          <div className="text-center py-4 bg-emerald-50/70 dark:bg-emerald-950/30 rounded-xl border border-emerald-100 dark:border-emerald-900/40">
            <div className="flex justify-center mb-3">
              <IslamicStarBadge number={surah.number} size="lg" />
            </div>

            <h2
              id="modal-surah-title"
              className="font-amiri text-3xl sm:text-4xl font-bold text-emerald-950 dark:text-emerald-200"
            >
              سورة {surah.name}
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1 font-mono">
              {surah.englishName}
            </p>
          </div>

          {/* Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-3 bg-white dark:bg-stone-950 rounded-xl border border-stone-200 dark:border-stone-800">
              <span className="text-xs text-stone-500 dark:text-stone-400 block mb-1">
                النزول
              </span>
              <span className="font-semibold text-stone-900 dark:text-stone-100 text-sm">
                {surah.type}
              </span>
            </div>

            <div className="p-3 bg-white dark:bg-stone-950 rounded-xl border border-stone-200 dark:border-stone-800">
              <span className="text-xs text-stone-500 dark:text-stone-400 block mb-1">
                عدد الآيات
              </span>
              <span className="font-semibold text-stone-900 dark:text-stone-100 text-sm">
                {surah.versesCount.toLocaleString('ar-EG')} آية
              </span>
            </div>

            <div className="p-3 bg-white dark:bg-stone-950 rounded-xl border border-stone-200 dark:border-stone-800">
              <span className="text-xs text-stone-500 dark:text-stone-400 block mb-1">
                الصفحة
              </span>
              <span className="font-semibold text-stone-900 dark:text-stone-100 text-sm">
                {surah.page.toLocaleString('ar-EG')}
              </span>
            </div>

            <div className="p-3 bg-white dark:bg-stone-950 rounded-xl border border-stone-200 dark:border-stone-800">
              <span className="text-xs text-stone-500 dark:text-stone-400 block mb-1">
                الجزء
              </span>
              <span className="font-semibold text-stone-900 dark:text-stone-100 text-sm">
                {surah.juz.toLocaleString('ar-EG')}
              </span>
            </div>
          </div>

          {/* Friendly notice regarding authentic text & divisions integration */}
          <div className="p-4 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200/80 dark:border-emerald-900/50 text-emerald-900 dark:text-emerald-200/90 text-xs sm:text-sm leading-relaxed flex items-start gap-3">
            <BookOpen className="w-5 h-5 shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400" />
            <div>
              <p className="font-semibold mb-0.5">النص القرآني الموثوق وتقسيم الأحزاب</p>
              <p className="text-stone-600 dark:text-stone-400 text-xs leading-normal">
                النص القرآني برسم المصحف العثماني برواية ورش، مع نظام دقيق لعلامات تقسيم الأثمان، الأرباع، الأنصاف، والأحزاب كما في المصحف الشريف.
              </p>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-stone-200 dark:border-stone-800 bg-white/60 dark:bg-stone-950/40 flex items-center justify-between gap-3">
          {onRead && (
            <button
              onClick={() => {
                onClose();
                onRead(surah);
              }}
              className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold transition-all shadow-xs"
            >
              <BookOpen className="w-4 h-4" />
              <span>قراءة السورة</span>
            </button>
          )}

          <button
            onClick={() => onBookmark(surah)}
            className={`inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
              isBookmarked
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700'
                : 'border border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'
            }`}
          >
            {isBookmarked ? (
              <>
                <Check className="w-4 h-4" />
                <span>محفوظة</span>
              </>
            ) : (
              <>
                <Bookmark className="w-4 h-4" />
                <span>حفظ موضع</span>
              </>
            )}
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 text-sm font-medium transition-colors"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
