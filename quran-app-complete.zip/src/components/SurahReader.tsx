import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowRight, 
  Bookmark, 
  ChevronRight, 
  ChevronLeft, 
  Check, 
  ZoomIn, 
  ZoomOut, 
  AlignJustify, 
  ListFilter,
  CheckCircle2,
  Navigation,
  Compass,
  ChevronDown,
  Moon,
  Sun,
  Share2,
  X,
  Sparkles,
  Palette,
  Heart,
  Headphones,
  Volume2,
  Play,
  Pause,
  Type,
  BookOpen
} from 'lucide-react';
import { Surah, SURAHS } from '../data/surahs';
import { getSurahVerses, Verse } from '../services/quranService';
import { getSurahSavedVerse, saveSurahProgress } from '../services/bookmarkService';
import { 
  getSurahDivisions, 
  getVerseDivision, 
  getVerseSajda, 
  getActiveDivisionForPosition, 
  formatDivisionTitle 
} from '../services/divisionService';
import { QuranDivisionMarker, SajdaMarker, SAJDA_MARKERS } from '../data/quranDivisions';
import { isTajweedEnabled, setTajweedEnabled } from '../services/tajweedService';
import { 
  getFavoriteVerses, 
  toggleFavoriteVerse, 
  subscribeToFavoriteVersesChange 
} from '../services/favoriteVersesService';
import { 
  Reciter, 
  RepeatMode, 
  RECITERS,
  getAyahAudioUrl, 
  getSavedReciter, 
  saveSelectedReciter, 
  getSavedRepeatMode, 
  saveSelectedRepeatMode 
} from '../services/quranAudioService';
import { 
  QuranFontFamily, 
  QuranLineSpacing, 
  FONT_FAMILY_OPTIONS, 
  FONT_SIZE_LEVELS, 
  LINE_SPACING_OPTIONS,
  getSavedFontFamily,
  getSavedFontSizeLevel,
  getSavedLineSpacing,
  saveFontSizeLevel
} from '../services/typographyService';
import { AyahEndBadge } from './AyahEndBadge';
import { IslamicStarBadge } from './IslamicStarBadge';
import { QuranDivisionBadge } from './QuranDivisionBadge';
import { SajdaBadge } from './SajdaBadge';
import { DivisionDetailsModal } from './DivisionDetailsModal';
import { FatihaSpecialLayout } from './FatihaSpecialLayout';
import { TajweedVerseText } from './TajweedVerseText';
import { TajweedLegendModal } from './TajweedLegendModal';
import { AyahActionsModal } from './AyahActionsModal';
import { FavoriteVersesSidebar } from './FavoriteVersesSidebar';
import { QuranAudioPlayerBar } from './QuranAudioPlayerBar';
import { TypographySettingsModal } from './TypographySettingsModal';
import { TafsirModal } from './TafsirModal';
import { SajdaDuaModal } from './SajdaDuaModal';

interface SurahReaderProps {
  surah: Surah;
  targetVerse?: number | null;
  onBack: () => void;
  onSelectSurah: (surah: Surah, targetVerse?: number) => void;
  isBookmarked: boolean;
  onBookmark: (surah: Surah, verseNumber?: number) => void;
  darkMode?: boolean;
  toggleDarkMode?: () => void;
  onShare?: () => void;
}

export const SurahReader: React.FC<SurahReaderProps> = ({
  surah,
  targetVerse,
  onBack,
  onSelectSurah,
  isBookmarked,
  onBookmark,
  darkMode,
  toggleDarkMode,
  onShare,
}) => {
  const [verses, setVerses] = useState<Verse[]>([]);
  const [fontFamily, setFontFamily] = useState<QuranFontFamily>(() => getSavedFontFamily());
  const [fontSizeLevel, setFontSizeLevel] = useState<number>(() => getSavedFontSizeLevel());
  const [lineSpacing, setLineSpacing] = useState<QuranLineSpacing>(() => getSavedLineSpacing());
  const [showTypographyModal, setShowTypographyModal] = useState<boolean>(false);
  
  // Default to Full Page mode (وضع ملء الصفحة هو الافتراضي)
  const [viewMode, setViewMode] = useState<'mushaf' | 'lines' | 'page'>('page');
  const previousViewMode = useRef<'mushaf' | 'lines'>('mushaf');

  // Immersive Reading Mode: Controls are hidden by default
  const [showControls, setShowControls] = useState<boolean>(false);

  // Gesture tracking to distinguish between a tap and a scroll/drag
  const pointerStartPos = useRef<{ x: number; y: number; time: number } | null>(null);

  const handlePointerDown = (e: React.PointerEvent) => {
    // Only primary mouse button or touch
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    pointerStartPos.current = {
      x: e.clientX,
      y: e.clientY,
      time: Date.now(),
    };
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!pointerStartPos.current) return;
    const dx = Math.abs(e.clientX - pointerStartPos.current.x);
    const dy = Math.abs(e.clientY - pointerStartPos.current.y);
    const dt = Date.now() - pointerStartPos.current.time;
    pointerStartPos.current = null;

    // A real tap: finger/pointer did not move more than 8px and took less than 400ms
    // During scroll/swipe gestures, movement will exceed 8px, so controls will NOT appear automatically during scrolling
    if (dx < 8 && dy < 8 && dt < 400) {
      setShowControls((prev) => !prev);
    }
  };

  // Currently stopped/saved verse in this surah
  const [savedVerseNumber, setSavedVerseNumber] = useState<number | null>(() => {
    return targetVerse || getSurahSavedVerse(surah.number);
  });

  // Track the temporarily highlighted verse for smooth visual cue
  const [activeHighlightVerse, setActiveHighlightVerse] = useState<number | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Active division tracking (current position in reading)
  const [activeDivision, setActiveDivision] = useState<QuranDivisionMarker | null>(() => {
    return getActiveDivisionForPosition(surah.number, targetVerse || 1) || null;
  });

  // Floating notification when user scrolls into / crosses a new division marker
  const [divisionNotice, setDivisionNotice] = useState<QuranDivisionMarker | null>(null);
  const lastNotifiedDivisionId = useRef<string | null>(null);

  // Modal inspection for division details
  const [selectedDivisionModal, setSelectedDivisionModal] = useState<QuranDivisionMarker | null>(null);
  const [showDivisionsMenu, setShowDivisionsMenu] = useState(false);

  // Colored Tajweed Rules State
  const [tajweedActive, setTajweedActive] = useState<boolean>(() => isTajweedEnabled());
  const [showTajweedModal, setShowTajweedModal] = useState<boolean>(false);

  // Favorite Verses State
  const [favoriteVerseNumbers, setFavoriteVerseNumbers] = useState<Set<number>>(() => {
    const favs = getFavoriteVerses();
    return new Set(favs.filter((f) => f.surahNumber === surah.number).map((f) => f.verseNumber));
  });
  const [totalFavoriteVersesCount, setTotalFavoriteVersesCount] = useState<number>(() => getFavoriteVerses().length);
  const [selectedAyahForModal, setSelectedAyahForModal] = useState<Verse | null>(null);
  const [selectedAyahForTafsir, setSelectedAyahForTafsir] = useState<Verse | null>(null);
  const [selectedSajdaModal, setSelectedSajdaModal] = useState<SajdaMarker | null>(null);
  const [showFavoriteSidebar, setShowFavoriteSidebar] = useState<boolean>(false);

  useEffect(() => {
    const syncFavorites = () => {
      const favs = getFavoriteVerses();
      setTotalFavoriteVersesCount(favs.length);
      setFavoriteVerseNumbers(new Set(favs.filter((f) => f.surahNumber === surah.number).map((f) => f.verseNumber)));
    };
    syncFavorites();
    const unsubscribe = subscribeToFavoriteVersesChange(syncFavorites);
    return () => unsubscribe();
  }, [surah.number]);

  const handleToggleFavoriteVerse = (verse: Verse) => {
    if (navigator.vibrate) {
      navigator.vibrate(30);
    }
    const isNowFav = toggleFavoriteVerse({
      surahNumber: surah.number,
      surahName: surah.name,
      verseNumber: verse.number,
      verseText: verse.text,
      juz: surah.juz,
      page: surah.page,
    });
    showToast(
      isNowFav
        ? `تمت إضافة الآية (${verse.number.toLocaleString('ar-EG')}) من سورة ${surah.name} إلى المفضلة ❤️`
        : `تمت إزالة الآية (${verse.number.toLocaleString('ar-EG')}) من المفضلة`
    );
  };

  const handleToggleTajweed = () => {
    const next = !tajweedActive;
    setTajweedActive(next);
    setTajweedEnabled(next);
    showToast(next ? 'تم تفعيل أحكام التجويد الملونة' : 'تم تعطيل أحكام التجويد الملونة');
  };

  // Audio Recitation State
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [currentPlayingVerse, setCurrentPlayingVerse] = useState<number | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [selectedReciter, setSelectedReciter] = useState<Reciter>(() => getSavedReciter());
  const [showRecitersMenu, setShowRecitersMenu] = useState<boolean>(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>(() => getSavedRepeatMode());
  const [currentVerseRepeatCount, setCurrentVerseRepeatCount] = useState<number>(1);

  // Mirrors in refs to avoid stale closures in audio event handlers
  const currentPlayingVerseRef = useRef<number | null>(null);
  currentPlayingVerseRef.current = currentPlayingVerse;

  const repeatModeRef = useRef<RepeatMode>(repeatMode);
  repeatModeRef.current = repeatMode;

  const repeatCountRef = useRef<number>(currentVerseRepeatCount);
  repeatCountRef.current = currentVerseRepeatCount;

  const selectedReciterRef = useRef<Reciter>(selectedReciter);
  selectedReciterRef.current = selectedReciter;

  const versesRef = useRef<Verse[]>(verses);
  versesRef.current = verses;

  const surahRef = useRef<Surah>(surah);
  surahRef.current = surah;

  const playVerseAudio = (verseNum: number) => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }
    const audio = audioRef.current;
    const reciter = selectedReciterRef.current;
    const url = getAyahAudioUrl(surahRef.current.number, verseNum, reciter.folder);

    audio.src = url;
    audio.currentTime = 0;
    audio.play().then(() => {
      setIsPlayingAudio(true);
    }).catch((e) => {
      console.error('Audio play error:', e);
      setIsPlayingAudio(false);
    });

    setCurrentPlayingVerse(verseNum);
    setCurrentVerseRepeatCount(1);
    handleScrollToVerse(verseNum);
  };

  const handlePauseAudio = () => {
    audioRef.current?.pause();
    setIsPlayingAudio(false);
  };

  const handleResumeAudio = () => {
    if (currentPlayingVerseRef.current !== null && audioRef.current) {
      audioRef.current.play().then(() => {
        setIsPlayingAudio(true);
      }).catch(() => setIsPlayingAudio(false));
    } else {
      playVerseAudio(savedVerseNumber || 1);
    }
  };

  const handleToggleAudioPlayback = () => {
    if (isPlayingAudio) {
      handlePauseAudio();
    } else if (currentPlayingVerse !== null) {
      handleResumeAudio();
    } else {
      playVerseAudio(savedVerseNumber || 1);
    }
  };

  const handleCloseAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
    }
    setCurrentPlayingVerse(null);
    setIsPlayingAudio(false);
  };

  const handleChangeReciter = (reciter: Reciter) => {
    setSelectedReciter(reciter);
    saveSelectedReciter(reciter.id);
    if (currentPlayingVerseRef.current !== null && audioRef.current) {
      const isCurrentlyActive = isPlayingAudio;
      const url = getAyahAudioUrl(surah.number, currentPlayingVerseRef.current, reciter.folder);
      audioRef.current.src = url;
      audioRef.current.currentTime = 0;
      if (isCurrentlyActive) {
        audioRef.current.play().catch(() => {});
      }
    }
  };

  const handleChangeRepeatMode = (mode: RepeatMode) => {
    setRepeatMode(mode);
    saveSelectedRepeatMode(mode);
  };

  // Audio lifecycle & ended handler setup
  useEffect(() => {
    const audio = new Audio();
    audioRef.current = audio;

    const handleEnded = () => {
      const currentNum = currentPlayingVerseRef.current;
      if (currentNum === null) return;

      const mode = repeatModeRef.current;
      const currentCount = repeatCountRef.current;
      const totalVerses = versesRef.current.length;
      const currentSurah = surahRef.current;

      // 1. Infinite repeat of this verse (للحفظ)
      if (mode === 'verse_infinite') {
        audio.currentTime = 0;
        audio.play().catch(() => {});
        setCurrentVerseRepeatCount((prev) => prev + 1);
        return;
      }

      // 2. Counted repeats for this verse (2x, 3x, 5x)
      let targetRepeats = 1;
      if (mode === 'verse_2x') targetRepeats = 2;
      else if (mode === 'verse_3x') targetRepeats = 3;
      else if (mode === 'verse_5x') targetRepeats = 5;

      if (targetRepeats > 1 && currentCount < targetRepeats) {
        audio.currentTime = 0;
        audio.play().catch(() => {});
        setCurrentVerseRepeatCount((prev) => prev + 1);
        return;
      }

      // 3. Move to next verse
      if (currentNum < totalVerses) {
        const nextVerse = currentNum + 1;
        playVerseAudio(nextVerse);
      } else {
        // End of Surah reached
        if (mode === 'surah') {
          playVerseAudio(1);
        } else {
          setIsPlayingAudio(false);
          setCurrentPlayingVerse(null);
          showToast(`تمت تلاوة سورة ${currentSurah.name} كاملة بفضل الله 🌿`);
        }
      }
    };

    const handleError = () => {
      setIsPlayingAudio(false);
    };

    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.pause();
      audio.src = '';
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, []);

  // Stop audio if surah changes
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    setIsPlayingAudio(false);
    setCurrentPlayingVerse(null);
  }, [surah.number]);

  // All divisions in current Surah
  const surahDivisions = useRef<QuranDivisionMarker[]>([]);
  surahDivisions.current = getSurahDivisions(surah.number);

  // References to scroll targets
  const verseRefs = useRef<Map<number, HTMLElement>>(new Map());

  // Load verses when surah changes
  useEffect(() => {
    const data = getSurahVerses(surah.number);
    setVerses(data);

    // Retrieve saved verse for this surah or use prop targetVerse
    const initialVerse = targetVerse ?? getSurahSavedVerse(surah.number);
    setSavedVerseNumber(initialVerse);

    const initialDiv = getActiveDivisionForPosition(surah.number, initialVerse || 1);
    setActiveDivision(initialDiv || null);
    lastNotifiedDivisionId.current = initialDiv?.id || null;

    // Scroll to the saved/target verse if exists, otherwise scroll to top
    if (initialVerse && initialVerse > 0) {
      setActiveHighlightVerse(initialVerse);
      const timer = setTimeout(() => {
        const el = verseRefs.current.get(initialVerse);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 250);

      const clearTimer = setTimeout(() => {
        setActiveHighlightVerse(null);
      }, 4000);

      return () => {
        clearTimeout(timer);
        clearTimeout(clearTimer);
      };
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [surah.number, targetVerse]);

  // Scroll listener to update active division as user reads/scrolls
  useEffect(() => {
    let timeoutId: NodeJS.Timeout | null = null;

    const handleScroll = () => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        // Find visible verse near the top-middle of the screen
        const viewportMiddle = window.innerHeight * 0.35;
        let bestVerse = 1;
        let minDistance = Infinity;

        verseRefs.current.forEach((el, verseNum) => {
          const rect = el.getBoundingClientRect();
          const distance = Math.abs(rect.top - viewportMiddle);
          if (rect.top <= viewportMiddle && distance < minDistance) {
            minDistance = distance;
            bestVerse = verseNum;
          }
        });

        const currentDiv = getActiveDivisionForPosition(surah.number, bestVerse);
        if (currentDiv) {
          setActiveDivision(currentDiv);

          // Check if crossed into a new division marker during manual/auto scrolling
          if (lastNotifiedDivisionId.current && lastNotifiedDivisionId.current !== currentDiv.id) {
            lastNotifiedDivisionId.current = currentDiv.id;
            setDivisionNotice(currentDiv);
            setTimeout(() => {
              setDivisionNotice((prev) => (prev?.id === currentDiv.id ? null : prev));
            }, 3500);
          } else if (!lastNotifiedDivisionId.current) {
            lastNotifiedDivisionId.current = currentDiv.id;
          }
        }
      }, 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [surah.number]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  const handleSaveVerse = (verseNum: number) => {
    setSavedVerseNumber(verseNum);
    setActiveHighlightVerse(verseNum);
    saveSurahProgress(surah.number, verseNum);
    onBookmark(surah, verseNum);
    showToast(`تم حفظ موضع التوقف: الآية (${verseNum.toLocaleString('ar-EG')}) من سورة ${surah.name}`);
  };

  const handleScrollToVerse = (verseNum: number) => {
    const el = verseRefs.current.get(verseNum);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setActiveHighlightVerse(verseNum);
      setTimeout(() => {
        setActiveHighlightVerse(null);
      }, 3000);
    }
    setShowDivisionsMenu(false);
  };

  const handleScrollToSavedVerse = () => {
    if (!savedVerseNumber) return;
    handleScrollToVerse(savedVerseNumber);
  };

  const getCurrentlyVisibleVerse = (): number => {
    const viewportMiddle = window.innerHeight * 0.35;
    let bestVerse = savedVerseNumber || 1;
    let minDistance = Infinity;

    verseRefs.current.forEach((el, verseNum) => {
      const rect = el.getBoundingClientRect();
      const distance = Math.abs(rect.top - viewportMiddle);
      if (distance < minDistance) {
        minDistance = distance;
        bestVerse = verseNum;
      }
    });

    return bestVerse;
  };

  const handleSelectViewMode = (mode: 'mushaf' | 'lines') => {
    const currentVerse = getCurrentlyVisibleVerse();
    previousViewMode.current = mode;
    setViewMode(mode);

    setTimeout(() => {
      const el = verseRefs.current.get(currentVerse);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 80);
  };

  const handleToggleFullPage = () => {
    const currentVerse = getCurrentlyVisibleVerse();
    
    if (viewMode === 'page') {
      setViewMode(previousViewMode.current || 'mushaf');
    } else {
      if (viewMode === 'mushaf' || viewMode === 'lines') {
        previousViewMode.current = viewMode;
      }
      setViewMode('page');
    }

    setTimeout(() => {
      const el = verseRefs.current.get(currentVerse);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 80);
  };

  const activeFontFamilyOption = FONT_FAMILY_OPTIONS.find((f) => f.id === fontFamily) || FONT_FAMILY_OPTIONS[0];
  const fontFamilyClass = activeFontFamilyOption.fontClass;

  const activeLineSpacingOption = LINE_SPACING_OPTIONS.find((s) => s.id === lineSpacing) || LINE_SPACING_OPTIONS[1];

  const fontSizes = FONT_SIZE_LEVELS.map((f) => `${f.sizeClass} ${activeLineSpacingOption.lineHeightClass}`);

  // Compact balanced line-height for traditional Mushaf Full Page mode
  const pageFontSizes = FONT_SIZE_LEVELS.map((f) => `${f.pageSizeClass} ${activeLineSpacingOption.pageLineHeightClass}`);

  // Sajda markers in current Surah
  const surahSajdas = SAJDA_MARKERS.filter((s) => s.surahNumber === surah.number);

  const handlePrevSurah = () => {
    if (surah.number > 1) {
      const prev = SURAHS.find((s) => s.number === surah.number - 1);
      if (prev) onSelectSurah(prev);
    }
  };

  const handleNextSurah = () => {
    if (surah.number < 114) {
      const next = SURAHS.find((s) => s.number === surah.number + 1);
      if (next) onSelectSurah(next);
    }
  };

  return (
    <div 
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
      className={`w-full mx-auto transition-all duration-200 min-h-screen ${
        viewMode === 'page' 
          ? 'max-w-4xl px-1 sm:px-3 pt-2 sm:pt-4 pb-8' 
          : 'max-w-4xl px-2 sm:px-6 pt-3 sm:pt-6 pb-12 space-y-6'
      }`}
    >
      
      {/* Toast Notification for Bookmarks */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl bg-emerald-900/95 text-white border border-emerald-500/40 shadow-xl backdrop-blur-md flex items-center gap-2 text-xs sm:text-sm font-medium animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Floating Notification when reaching a Division Marker while reading/scrolling */}
      {divisionNotice && (
        <div 
          onPointerDown={(e) => e.stopPropagation()}
          onPointerUp={(e) => e.stopPropagation()}
          onClick={(e) => {
            e.stopPropagation();
            setSelectedDivisionModal(divisionNotice);
          }}
          className="fixed top-4 sm:top-6 left-1/2 -translate-x-1/2 z-40 px-4 py-2 rounded-2xl bg-stone-900/95 text-stone-100 border border-amber-500/50 shadow-2xl backdrop-blur-md flex items-center gap-2.5 text-xs sm:text-sm font-medium cursor-pointer transition-all hover:scale-102 animate-in fade-in slide-in-from-top-4"
          dir="rtl"
        >
          <span className="text-amber-400 text-base font-bold">۞</span>
          <span className="text-stone-300">وصلت إلى:</span>
          <span className="font-amiri font-bold text-amber-300 text-sm sm:text-base">
            {formatDivisionTitle(divisionNotice)}
          </span>
          <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-200 border border-amber-500/30 font-mono">
            {divisionNotice.badge}
          </span>
        </div>
      )}

      {/* Floating Overlay Controls Bar (appears over the Quran content on tap without pushing text) */}
      <div 
        onPointerDown={(e) => e.stopPropagation()}
        onPointerUp={(e) => e.stopPropagation()}
        onClick={(e) => e.stopPropagation()}
        className={`fixed top-0 inset-x-0 z-40 transition-all duration-200 ease-out transform ${
          showControls
            ? 'translate-y-0 opacity-100 pointer-events-auto shadow-xl'
            : '-translate-y-full opacity-0 pointer-events-none'
        }`}
      >
        <div className="bg-stone-50/95 dark:bg-stone-950/95 backdrop-blur-md border-b border-stone-200/90 dark:border-stone-800 px-3 sm:px-6 py-2.5 space-y-2">
          
          {/* Row 1: App Navigation, Surah Info, Theme, Share, Dismiss */}
          <div className="flex items-center justify-between gap-2">
            
            {/* Back button & Surah title summary */}
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              <button
                onClick={onBack}
                type="button"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-stone-200 dark:border-stone-800 bg-white/80 dark:bg-stone-900/80 text-stone-700 dark:text-stone-300 hover:bg-stone-200/60 dark:hover:bg-stone-800 text-xs sm:text-sm font-semibold transition-colors shrink-0 shadow-2xs active:scale-95"
                title="العودة إلى فهرس السور"
              >
                <ArrowRight className="w-4 h-4" />
                <span>الفهرس</span>
              </button>

              <div className="flex items-center gap-1.5 sm:gap-2 text-xs truncate">
                <span className="font-amiri text-base sm:text-lg font-bold text-emerald-950 dark:text-emerald-100 truncate">
                  سُورَةُ {surah.name}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 font-medium border border-emerald-200/60 dark:border-emerald-800/60 shrink-0">
                  {surah.type}
                </span>
                <span className="hidden md:inline text-stone-400 dark:text-stone-500">
                  {surah.versesCount.toLocaleString('ar-EG')} آية • ص {surah.page.toLocaleString('ar-EG')} • ج {surah.juz.toLocaleString('ar-EG')}
                </span>
              </div>
            </div>

            {/* Quick Surah Prev / Next, Share, Dark Mode, Dismiss */}
            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              
              {/* Prev / Next Surah */}
              <div className="flex items-center bg-stone-200/60 dark:bg-stone-900 rounded-lg p-0.5 border border-stone-200 dark:border-stone-800">
                <button
                  onClick={handlePrevSurah}
                  disabled={surah.number <= 1}
                  type="button"
                  title="السورة السابقة"
                  className="p-1.5 rounded-md text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 disabled:opacity-25 transition-colors"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNextSurah}
                  disabled={surah.number >= 114}
                  type="button"
                  title="السورة التالية"
                  className="p-1.5 rounded-md text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 disabled:opacity-25 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </div>

              {/* Share Button */}
              {onShare && (
                <button
                  onClick={onShare}
                  type="button"
                  className="p-2 rounded-xl text-stone-700 dark:text-stone-300 hover:bg-stone-200/60 dark:hover:bg-stone-800 border border-stone-200 dark:border-stone-800 bg-white/80 dark:bg-stone-900/80 transition-colors shadow-2xs active:scale-95"
                  title="مشاركة"
                >
                  <Share2 className="w-4 h-4 text-emerald-800 dark:text-emerald-400" />
                </button>
              )}

              {/* Dark Mode Toggle */}
              {toggleDarkMode && (
                <button
                  onClick={toggleDarkMode}
                  type="button"
                  className="p-2 rounded-xl text-stone-700 dark:text-stone-300 hover:bg-stone-200/60 dark:hover:bg-stone-800 border border-stone-200 dark:border-stone-800 bg-white/80 dark:bg-stone-900/80 transition-colors shadow-2xs active:scale-95"
                  title={darkMode ? 'الوضع النهاري' : 'الوضع الليلي'}
                >
                  {darkMode ? (
                    <Sun className="w-4 h-4 text-amber-400" />
                  ) : (
                    <Moon className="w-4 h-4 text-emerald-900 dark:text-emerald-400" />
                  )}
                </button>
              )}

              {/* Dismiss Toolbar */}
              <button
                onClick={() => setShowControls(false)}
                type="button"
                className="p-2 rounded-xl text-stone-500 hover:text-stone-800 dark:text-stone-400 dark:hover:text-stone-100 hover:bg-stone-200/60 dark:hover:bg-stone-800 border border-stone-200/70 dark:border-stone-800 transition-colors"
                title="إخفاء شريط الأدوات ومتابعة القراءة الكاملة"
              >
                <X className="w-4 h-4" />
              </button>

            </div>

          </div>

          {/* Row 2: Reading Options (Division, Saved Verse Jump, View Modes, Zoom, Bookmark Save) */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-stone-200/60 dark:border-stone-800/60">
            
            {/* Division Indicator & Saved Verse Jump */}
            <div className="flex items-center gap-2">
              {/* Active Division Indicator / Menu Trigger */}
              {activeDivision && (
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setShowDivisionsMenu((prev) => !prev)}
                    title="موضع التقسيم القرآني الحالي (انقر لعرض أثمان السورة)"
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-900 dark:text-amber-200 border border-amber-300/40 dark:border-amber-700/50 text-xs font-semibold transition-colors"
                  >
                    <span className="text-amber-600 dark:text-amber-400 font-bold">۞</span>
                    <span className="font-amiri">{activeDivision.shortName}</span>
                    <span className="text-[10px] font-mono px-1 rounded bg-black/5 dark:bg-white/10">
                      {activeDivision.hizbNumber.toLocaleString('ar-EG')}
                    </span>
                    <ChevronDown className={`w-3 h-3 text-amber-600 transition-transform ${showDivisionsMenu ? 'rotate-180' : ''}`} />
                  </button>

                  {/* Dropdown for All Division Markers in this Surah */}
                  {showDivisionsMenu && (
                    <div 
                      className="absolute left-0 mt-2 z-50 w-72 max-h-80 overflow-y-auto rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xl p-2 space-y-1 animate-in fade-in zoom-in-95"
                      dir="rtl"
                    >
                      <div className="px-3 py-1.5 text-xs font-semibold text-stone-500 dark:text-stone-400 border-b border-stone-100 dark:border-stone-800 flex items-center justify-between">
                        <span>تقسيمات المصحف في السورة</span>
                        <span className="font-mono text-[11px]">{surahDivisions.current.length} مواضع</span>
                      </div>

                      {surahDivisions.current.length > 0 ? (
                        surahDivisions.current.map((div) => {
                          const isCurrent = activeDivision.id === div.id;
                          return (
                            <button
                              key={div.id}
                              type="button"
                              onClick={() => handleScrollToVerse(div.verseNumber)}
                              className={`w-full text-right px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors ${
                                isCurrent
                                  ? 'bg-amber-500/15 text-amber-900 dark:text-amber-200 font-bold'
                                  : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <span className="text-amber-600 dark:text-amber-400 text-sm">۞</span>
                                <span className="font-amiri text-sm">{div.name}</span>
                              </div>
                              <span className="text-stone-400 dark:text-stone-500 font-mono text-[11px]">
                                آية {div.verseNumber.toLocaleString('ar-EG')}
                              </span>
                            </button>
                          );
                        })
                      ) : (
                        <div className="px-3 py-4 text-center text-xs text-stone-500 dark:text-stone-400">
                          هذه السورة تقع ضمن نطاق:
                          <div className="mt-1 font-amiri font-bold text-stone-800 dark:text-stone-200">
                            {activeDivision.name}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Quick jump to saved verse button (if saved in this surah) */}
              {savedVerseNumber && (
                <button
                  type="button"
                  onClick={handleScrollToSavedVerse}
                  title={`الانتقال إلى الآية المحفوظة (${savedVerseNumber.toLocaleString('ar-EG')})`}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-stone-200/60 dark:bg-stone-800 hover:bg-stone-200 text-stone-700 dark:text-stone-300 border border-stone-300/40 dark:border-stone-700 text-xs font-semibold transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5 rotate-45 text-emerald-600 dark:text-emerald-400" />
                  <span>الآية {savedVerseNumber.toLocaleString('ar-EG')}</span>
                </button>
              )}
            </div>

            {/* View Mode Toggle, Tajweed Toggle, Font Zoom, Bookmark Button */}
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap sm:flex-nowrap">
              
              {/* Tajweed Colored Rules Controls */}
              <div className="flex items-center bg-stone-200/60 dark:bg-stone-900 p-0.5 rounded-lg border border-stone-200 dark:border-stone-800">
                <button
                  type="button"
                  onClick={handleToggleTajweed}
                  title={tajweedActive ? 'أحكام التجويد الملونة مفعّلة (انقر للتعطيل)' : 'تفعيل أحكام التجويد الملونة'}
                  className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium transition-all ${
                    tajweedActive
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 shadow-xs font-semibold'
                      : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-100'
                  }`}
                >
                  <Sparkles className={`w-3.5 h-3.5 ${tajweedActive ? 'text-amber-500 fill-amber-500' : 'text-stone-400'}`} />
                  <span className="hidden sm:inline">التجويد</span>
                  {tajweedActive && (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setShowTajweedModal(true)}
                  title="دليل ألوان أحكام التجويد"
                  className="p-1 rounded-md text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 transition-colors"
                >
                  <Palette className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* View Mode Toggle: Mushaf Continuous vs Verse-by-verse vs Full Page Fill */}
              <div className="flex items-center bg-stone-200/60 dark:bg-stone-900 p-0.5 rounded-lg border border-stone-200 dark:border-stone-800">
                <button
                  type="button"
                  onClick={() => handleSelectViewMode('mushaf')}
                  title="عرض المصحف المتصل"
                  className={`p-1.5 rounded-md transition-colors ${
                    viewMode === 'mushaf'
                      ? 'bg-white dark:bg-stone-800 text-emerald-800 dark:text-emerald-300 shadow-xs'
                      : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-100'
                  }`}
                >
                  <AlignJustify className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectViewMode('lines')}
                  title="عرض الآيات منفصلة"
                  className={`p-1.5 rounded-md transition-colors ${
                    viewMode === 'lines'
                      ? 'bg-white dark:bg-stone-800 text-emerald-800 dark:text-emerald-300 shadow-xs'
                      : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-100'
                  }`}
                >
                  <ListFilter className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={handleToggleFullPage}
                  title={viewMode === 'page' ? 'إلغاء وضع ملء الصفحة' : 'وضع ملء الصفحة (المصحف التقليدي)'}
                  className={`p-1.5 rounded-md transition-colors ${
                    viewMode === 'page'
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 shadow-xs ring-1 ring-emerald-500/20'
                      : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-100'
                  }`}
                >
                  <svg
                    className="w-4 h-4 stroke-[2]"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M3 8V5a2 2 0 0 1 2-2h3" />
                    <path d="M16 3h3a2 2 0 0 1 2 2v3" />
                    <path d="M21 16v3a2 2 0 0 1-2 2h-3" />
                    <path d="M8 21H5a2 2 0 0 1-2-2v-3" />
                  </svg>
                </button>
              </div>

              {/* Font Size Zoom Controls */}
              <div className="flex items-center bg-stone-200/60 dark:bg-stone-900 p-0.5 rounded-lg border border-stone-200 dark:border-stone-800">
                <button
                  type="button"
                  onClick={() => {
                    const next = Math.max(0, fontSizeLevel - 1);
                    setFontSizeLevel(next);
                    saveFontSizeLevel(next);
                  }}
                  disabled={fontSizeLevel === 0}
                  title="تصغير الخط"
                  className="p-1.5 rounded-md text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 disabled:opacity-30 transition-colors"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <span className="text-[11px] px-1 font-mono font-medium text-stone-500 dark:text-stone-400" title={`حجم الخط: ${FONT_SIZE_LEVELS[fontSizeLevel]?.label || ''}`}>
                  {fontSizeLevel + 1}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const next = Math.min(FONT_SIZE_LEVELS.length - 1, fontSizeLevel + 1);
                    setFontSizeLevel(next);
                    saveFontSizeLevel(next);
                  }}
                  disabled={fontSizeLevel === FONT_SIZE_LEVELS.length - 1}
                  title="تكبير الخط"
                  className="p-1.5 rounded-md text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 disabled:opacity-30 transition-colors"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
              </div>

              {/* Advanced Typography & Font Customizer Trigger Button */}
              <button
                onClick={() => setShowTypographyModal(true)}
                type="button"
                title="تخصيص نوع الخط (عثماني، أميري، كايرو) وحجمه وتباعد الأسطر"
                className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold border transition-all bg-white dark:bg-stone-850 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-700 shadow-xs"
              >
                <Type className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span className="hidden sm:inline">الخط: {activeFontFamilyOption.name.split(' ')[0]}</span>
                <span className="sm:hidden">الخط</span>
              </button>

              {/* Recitation Audio & Reciter Selection Icon Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowRecitersMenu((prev) => !prev)}
                  type="button"
                  title={`التلاوة الصوتية - القارئ: ${selectedReciter.name} (انقر للاختيار بين الشيخ الحصري والشيخ العفاسي)`}
                  className={`inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold border transition-all shadow-xs cursor-pointer ${
                    isPlayingAudio
                      ? 'bg-emerald-600 text-white border-emerald-700 shadow-md ring-2 ring-emerald-500/30'
                      : currentPlayingVerse !== null
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-400'
                      : 'bg-white dark:bg-stone-850 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-700'
                  }`}
                >
                  <Volume2 className={`w-3.5 h-3.5 ${isPlayingAudio ? 'text-white animate-pulse' : 'text-emerald-600 dark:text-emerald-400'}`} />
                  <span className="hidden sm:inline">
                    {selectedReciter.id === 'husary'
                      ? 'الشيخ الحصري'
                      : selectedReciter.id === 'alafasy'
                      ? 'الشيخ العفاسي'
                      : selectedReciter.name}
                  </span>
                  <span className="sm:hidden">
                    {selectedReciter.id === 'husary'
                      ? 'الحصري'
                      : selectedReciter.id === 'alafasy'
                      ? 'العفاسي'
                      : 'القارئ'}
                  </span>
                  <ChevronDown className={`w-3 h-3 transition-transform ${showRecitersMenu ? 'rotate-180' : ''}`} />
                </button>

                {/* Reciters Dropdown Menu (Sheikh Al-Husary & Sheikh Al-Afasy) */}
                {showRecitersMenu && (
                  <>
                    {/* Backdrop */}
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setShowRecitersMenu(false)}
                    />

                    <div
                      className="absolute left-0 mt-2 z-50 w-72 sm:w-80 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-2xl p-3 space-y-2.5 animate-in fade-in zoom-in-95"
                      dir="rtl"
                    >
                      <div className="flex items-center justify-between border-b border-stone-100 dark:border-stone-800 pb-2">
                        <div className="flex items-center gap-1.5">
                          <Volume2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                          <span className="text-xs font-bold text-stone-800 dark:text-stone-200">
                            تلاوة سورة {surah.name}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setShowRecitersMenu(false)}
                          className="p-1 rounded-lg text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 transition-colors"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <p className="text-[11px] text-stone-500 dark:text-stone-400">
                        اختر القارئ للاستماع للتلاوة مباشرة:
                      </p>

                      <div className="space-y-1.5">
                        {RECITERS.slice(0, 2).map((reciter) => {
                          const isSelected = selectedReciter.id === reciter.id;
                          const isCurrentlyPlayingThis = isSelected && isPlayingAudio;
                          return (
                            <button
                              key={reciter.id}
                              type="button"
                              onClick={() => {
                                if (isSelected && isPlayingAudio) {
                                  handlePauseAudio();
                                } else {
                                  handleChangeReciter(reciter);
                                  if (!isPlayingAudio) {
                                    playVerseAudio(savedVerseNumber || 1);
                                  }
                                }
                                setShowRecitersMenu(false);
                              }}
                              className={`w-full p-2.5 rounded-xl border text-right flex items-center justify-between transition-all cursor-pointer ${
                                isSelected
                                  ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500/70 text-emerald-950 dark:text-emerald-200 shadow-xs'
                                  : 'bg-stone-50 dark:bg-stone-850 hover:bg-stone-100 dark:hover:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-800 dark:text-stone-200'
                              }`}
                            >
                              <div className="flex items-center gap-2.5">
                                <div
                                  className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                                    isSelected
                                      ? 'bg-emerald-600 text-white'
                                      : 'bg-stone-200 dark:bg-stone-700 text-stone-600 dark:text-stone-300'
                                  }`}
                                >
                                  {isCurrentlyPlayingThis ? (
                                    <Pause className="w-4 h-4 fill-current" />
                                  ) : (
                                    <Volume2 className="w-4 h-4" />
                                  )}
                                </div>
                                <div>
                                  <div className="text-xs font-bold">{reciter.name}</div>
                                  {reciter.subName && (
                                    <div className="text-[10px] text-stone-500 dark:text-stone-400 font-medium">
                                      {reciter.subName}
                                    </div>
                                  )}
                                </div>
                              </div>

                              <div className="flex items-center gap-1.5">
                                {isCurrentlyPlayingThis ? (
                                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-600 text-white font-bold animate-pulse">
                                    تلاوة نشطة
                                  </span>
                                ) : isSelected ? (
                                  <span className="inline-flex items-center gap-1 text-[10px] text-emerald-700 dark:text-emerald-300 font-bold">
                                    <Check className="w-3.5 h-3.5" />
                                    مختار
                                  </span>
                                ) : (
                                  <span className="text-[10px] text-stone-400">
                                    استماع
                                  </span>
                                )}
                              </div>
                            </button>
                          );
                        })}
                      </div>

                      {/* Quick Play/Pause Control Button */}
                      <div className="pt-1 border-t border-stone-100 dark:border-stone-800">
                        <button
                          type="button"
                          onClick={() => {
                            handleToggleAudioPlayback();
                            setShowRecitersMenu(false);
                          }}
                          className={`w-full py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                            isPlayingAudio
                              ? 'bg-amber-600 hover:bg-amber-700 text-white shadow-xs'
                              : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs'
                          }`}
                        >
                          {isPlayingAudio ? (
                            <>
                              <Pause className="w-3.5 h-3.5 fill-current" />
                              <span>إيقاف التلاوة مؤقتاً</span>
                            </>
                          ) : (
                            <>
                              <Play className="w-3.5 h-3.5 fill-current" />
                              <span>بدء الاستماع لسورة {surah.name}</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Tafsir Trigger Button */}
              <button
                onClick={() => {
                  const targetV = savedVerseNumber || 1;
                  const v = verses.find((item) => item.number === targetV) || verses[0];
                  if (v) {
                    setSelectedAyahForTafsir(v);
                  }
                }}
                type="button"
                title="تفسير الآيات (الميسر، السعدي، ابن كثير)"
                className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold border transition-all bg-white dark:bg-stone-850 hover:bg-amber-50 dark:hover:bg-amber-950/40 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-700 shadow-xs"
              >
                <BookOpen className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span className="hidden sm:inline">التفسير</span>
              </button>

              {/* Favorite Verses Drawer Trigger */}
              <button
                onClick={() => setShowFavoriteSidebar(true)}
                type="button"
                title="عرض قائمة الآيات المفضلة"
                className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold border transition-all bg-white dark:bg-stone-850 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-700 shadow-xs"
              >
                <Heart className={`w-3.5 h-3.5 ${totalFavoriteVersesCount > 0 ? 'fill-rose-500 text-rose-500' : 'text-stone-400'}`} />
                <span className="hidden sm:inline">المفضلة</span>
                {totalFavoriteVersesCount > 0 && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-bold">
                    {totalFavoriteVersesCount}
                  </span>
                )}
              </button>

              {/* Bookmark button for surah */}
              <button
                onClick={() => handleSaveVerse(savedVerseNumber || 1)}
                type="button"
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                  isBookmarked
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700'
                    : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs'
                }`}
              >
                {isBookmarked ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">حفظ الموضع</span>
                  </>
                ) : (
                  <>
                    <Bookmark className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">حفظ السورة</span>
                  </>
                )}
              </button>

            </div>

          </div>

        </div>
      </div>

      {/* Surah Main Reading Card - Special Layout for Surat Al-Fatihah (surah.number === 1) ONLY */}
      {surah.number === 1 ? (
        <FatihaSpecialLayout
          surah={surah}
          verses={verses}
          savedVerseNumber={savedVerseNumber}
          activeHighlightVerse={activeHighlightVerse}
          verseRefs={verseRefs}
          fontSizeClass={viewMode === 'page' ? (pageFontSizes[fontSizeLevel] || pageFontSizes[2]) : (fontSizes[fontSizeLevel] || fontSizes[2])}
          onSaveVerse={handleSaveVerse}
          onSelectDivisionModal={(div) => setSelectedDivisionModal(div)}
          getVerseDivision={getVerseDivision}
          viewMode={viewMode}
          tajweedActive={tajweedActive}
          onOpenTajweedLegend={() => setShowTajweedModal(true)}
          isVerseFavorite={(vNum) => favoriteVerseNumbers.has(vNum)}
          onOpenAyahModal={(v) => setSelectedAyahForModal(v)}
          currentPlayingVerse={currentPlayingVerse}
          fontFamilyClass={fontFamilyClass}
          isPlayingAudio={isPlayingAudio}
          onToggleAudio={handleToggleAudioPlayback}
        />
      ) : (
        <article className={`bg-white dark:bg-stone-900 border border-stone-200/90 dark:border-stone-800 shadow-sm overflow-hidden transition-all ${
          viewMode === 'page'
            ? 'rounded-2xl p-1 sm:p-3'
            : 'rounded-3xl p-4 sm:p-10'
        }`}>
        
        {viewMode === 'page' ? (
          /* Mode 3: Traditional Mushaf Page Fill (ملء الصفحة بتصميم صفحة المصحف التقليدية) */
          <div className="border border-amber-600/35 dark:border-amber-500/25 rounded-xl p-2 sm:p-5 md:p-6 bg-stone-50/40 dark:bg-stone-950/30 relative">
            {/* Corner Ornaments */}
            <span className="absolute top-1 right-1 text-amber-600/40 dark:text-amber-400/30 text-[10px] select-none font-serif">✤</span>
            <span className="absolute top-1 left-1 text-amber-600/40 dark:text-amber-400/30 text-[10px] select-none font-serif">✤</span>
            <span className="absolute bottom-1 right-1 text-amber-600/40 dark:text-amber-400/30 text-[10px] select-none font-serif">✤</span>
            <span className="absolute bottom-1 left-1 text-amber-600/40 dark:text-amber-400/30 text-[10px] select-none font-serif">✤</span>

            {/* Compact Traditional Surah Title Plaque (لافتة السورة المدمجة كالمصحف الشريف) */}
            <div className="relative text-center py-2 px-3 mb-3.5 rounded-lg border border-amber-600/40 dark:border-amber-500/30 bg-gradient-to-r from-amber-500/10 via-emerald-600/10 to-amber-500/10 shadow-xs">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-[11px] sm:text-xs text-stone-600 dark:text-stone-400 font-medium">
                  <span className="px-2 py-0.5 rounded-md bg-emerald-100/80 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 font-bold border border-emerald-300/40 dark:border-emerald-800/60">
                    {surah.type}
                  </span>
                  <span>•</span>
                  <span>{surah.versesCount.toLocaleString('ar-EG')} آية</span>
                </div>

                <h2 className="font-amiri text-2xl sm:text-3xl font-bold text-emerald-950 dark:text-emerald-100 tracking-wide">
                  سُورَةُ {surah.name}
                </h2>

                <div className="flex items-center gap-1.5 text-[11px] sm:text-xs text-stone-600 dark:text-stone-400 font-medium">
                  <span>الجزء {surah.juz.toLocaleString('ar-EG')}</span>
                  {activeDivision && (
                    <>
                      <span>•</span>
                      <span className="text-amber-700 dark:text-amber-400 font-semibold">
                        الحزب {activeDivision.hizbNumber.toLocaleString('ar-EG')}
                      </span>
                    </>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-center gap-2 flex-wrap mt-1">
                {savedVerseNumber && (
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-300/40 dark:border-amber-700/40 text-[10px] sm:text-[11px] font-medium">
                    <Bookmark className="w-2.5 h-2.5 fill-current" />
                    <span>موضع التوقف: الآية {savedVerseNumber.toLocaleString('ar-EG')}</span>
                  </div>
                )}

                {surahSajdas.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      const s = surahSajdas[0];
                      handleScrollToVerse(s.verseNumber);
                      setSelectedSajdaModal(s);
                    }}
                    className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 hover:bg-amber-500/30 text-amber-900 dark:text-amber-200 border border-amber-400/50 text-[10px] sm:text-[11px] font-semibold transition-all cursor-pointer shadow-2xs"
                    title="الانتقال إلى موضع سجدة التلاوة وعرض الدعاء والأحكام"
                  >
                    <span className="font-serif font-bold text-xs">۩</span>
                    <span>
                      {surahSajdas.length === 1
                        ? `سجدة تلاوة (الآية ${surahSajdas[0].verseNumber.toLocaleString('ar-EG')})`
                        : `سجدتا تلاوة (الآيات ${surahSajdas.map((s) => s.verseNumber.toLocaleString('ar-EG')).join('، ')})`}
                    </span>
                    <span className="text-[9px] text-amber-700 dark:text-amber-300 underline font-normal">عرض الدعاء</span>
                  </button>
                )}
              </div>
            </div>

            {/* Continuous Full Page Quran Text */}
            <div 
              className={`${fontFamilyClass} text-right tracking-normal text-stone-900 dark:text-stone-100 text-justify [text-justify:inter-word] px-0.5 sm:px-1 ${pageFontSizes[fontSizeLevel] || pageFontSizes[2]}`}
              dir="rtl"
            >
              {verses.map((verse) => {
                const isSaved = savedVerseNumber === verse.number;
                const isPulsing = activeHighlightVerse === verse.number;
                const isPlayingThis = currentPlayingVerse === verse.number;
                const isFav = favoriteVerseNumbers.has(verse.number);
                const division = getVerseDivision(surah.number, verse.number);
                const sajda = getVerseSajda(surah.number, verse.number);

                return (
                  <React.Fragment key={verse.number}>
                    {division && (
                      <QuranDivisionBadge 
                        marker={division} 
                        mode="inline" 
                        onClick={() => setSelectedDivisionModal(division)} 
                      />
                    )}

                    <span
                      ref={(el) => {
                        if (el) verseRefs.current.set(verse.number, el);
                        else verseRefs.current.delete(verse.number);
                      }}
                      id={`ayah-${surah.number}-${verse.number}`}
                      className={`inline transition-all duration-200 rounded px-1 select-text ${
                        isPlayingThis
                          ? 'bg-emerald-200/90 dark:bg-emerald-950/90 text-emerald-950 dark:text-emerald-100 ring-2 ring-emerald-500 rounded-lg shadow-sm font-semibold'
                          : isPulsing
                          ? 'verse-highlight-active'
                          : isSaved
                          ? 'bg-amber-100/70 dark:bg-amber-950/40 text-emerald-950 dark:text-emerald-200 border-b-2 border-amber-500'
                          : 'hover:bg-emerald-500/10 dark:hover:bg-emerald-500/15'
                      }`}
                    >
                      <span className="inline">
                        <TajweedVerseText 
                          text={verse.text} 
                          enabled={tajweedActive} 
                          onRuleClick={() => setShowTajweedModal(true)} 
                        />
                      </span>
                      <span
                        onPointerDown={(e) => e.stopPropagation()}
                        onPointerUp={(e) => e.stopPropagation()}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedAyahForModal(verse);
                        }}
                        className="inline-flex items-center gap-0.5 cursor-pointer hover:scale-115 active:scale-95 transition-transform align-middle mx-0.5"
                        title={`خيارات الآية ${verse.number.toLocaleString('ar-EG')} (المفضلة، موضع التوقف، نسخ)`}
                      >
                        <AyahEndBadge number={verse.number} />
                        {isFav && (
                          <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500 inline align-middle animate-in zoom-in-50" />
                        )}
                      </span>
                      {sajda && (
                        <SajdaBadge 
                          marker={sajda} 
                          onClick={() => setSelectedSajdaModal(sajda)} 
                        />
                      )}
                      {' '}
                    </span>
                  </React.Fragment>
                );
              })}
            </div>

          </div>
        ) : (
          <>
            {/* Ornate Header Banner */}
            <div className="relative text-center py-6 px-4 mb-8 rounded-2xl bg-gradient-to-b from-emerald-50/70 to-stone-50/50 dark:from-emerald-950/40 dark:to-stone-900 border border-emerald-200/60 dark:border-emerald-900/60">
              
              {/* Subtle Decorative Corner stars */}
              <div className="flex items-center justify-center gap-3 mb-2">
                <span className="h-px w-10 sm:w-16 bg-gradient-to-l from-emerald-600/40 to-transparent" />
                <IslamicStarBadge number={surah.number} size="sm" />
                <span className="h-px w-10 sm:w-16 bg-gradient-to-r from-emerald-600/40 to-transparent" />
              </div>

              <h2 className="font-amiri text-3xl sm:text-5xl font-bold text-emerald-950 dark:text-emerald-100 tracking-wide mb-2">
                سُورَةُ {surah.name}
              </h2>

              <div className="flex items-center justify-center flex-wrap gap-2 sm:gap-3 text-xs sm:text-sm text-stone-600 dark:text-stone-400 font-medium">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-100/70 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60">
                  {surah.type}
                </span>
                <span>•</span>
                <span>{surah.versesCount.toLocaleString('ar-EG')} آية</span>
                <span>•</span>
                <span>الصفحة {surah.page.toLocaleString('ar-EG')}</span>
                <span>•</span>
                <span>الجزء {surah.juz.toLocaleString('ar-EG')}</span>
                {activeDivision && (
                  <>
                    <span>•</span>
                    <span className="text-amber-700 dark:text-amber-400 font-semibold">
                      ۞ الحزب {activeDivision.hizbNumber.toLocaleString('ar-EG')}
                    </span>
                  </>
                )}
              </div>

              <div className="flex items-center justify-center gap-2 flex-wrap mt-3">
                {savedVerseNumber && (
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 text-amber-800 dark:text-amber-300 border border-amber-300/40 dark:border-amber-700/40 text-xs font-medium">
                    <Bookmark className="w-3 h-3 fill-current" />
                    <span>موضع التوقف الحالي: الآية {savedVerseNumber.toLocaleString('ar-EG')}</span>
                  </div>
                )}

                {surahSajdas.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      const s = surahSajdas[0];
                      handleScrollToVerse(s.verseNumber);
                      setSelectedSajdaModal(s);
                    }}
                    className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-amber-500/20 via-amber-400/20 to-amber-500/20 hover:from-amber-500/30 hover:to-amber-500/30 text-amber-900 dark:text-amber-200 border border-amber-400/60 dark:border-amber-600/60 text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
                    title="الانتقال إلى موضع سجدة التلاوة وعرض الدعاء والأحكام"
                  >
                    <span className="font-serif text-base">۩</span>
                    <span>
                      {surahSajdas.length === 1
                        ? `سجدة تلاوة في هذه السورة (الآية ${surahSajdas[0].verseNumber.toLocaleString('ar-EG')})`
                        : `سجدتا تلاوة في هذه السورة (الآيات ${surahSajdas.map((s) => s.verseNumber.toLocaleString('ar-EG')).join('، ')})`}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-600 text-white font-medium">
                      دعاء السجدة ۩
                    </span>
                  </button>
                )}
              </div>

            </div>

            {/* Verses Rendering Section */}
            {viewMode === 'mushaf' ? (
              /* Mode 1: Continuous Mushaf Flow with Natural Inline Division Markers */
              <div 
                className={`${fontFamilyClass} text-right tracking-wide text-stone-900 dark:text-stone-100 text-justify [text-justify:inter-word] px-1 sm:px-4 ${fontSizes[fontSizeLevel] || fontSizes[2]}`}
                dir="rtl"
              >
                {verses.map((verse) => {
                  const isSaved = savedVerseNumber === verse.number;
                  const isPulsing = activeHighlightVerse === verse.number;
                  const isPlayingThis = currentPlayingVerse === verse.number;
                  const isFav = favoriteVerseNumbers.has(verse.number);
                  const division = getVerseDivision(surah.number, verse.number);
                  const sajda = getVerseSajda(surah.number, verse.number);

                  return (
                    <React.Fragment key={verse.number}>
                      {/* Division Marker (displayed right before the verse that starts the division) */}
                      {division && (
                        <QuranDivisionBadge 
                          marker={division} 
                          mode="inline" 
                          onClick={() => setSelectedDivisionModal(division)} 
                        />
                      )}

                      <span
                        ref={(el) => {
                          if (el) verseRefs.current.set(verse.number, el);
                          else verseRefs.current.delete(verse.number);
                        }}
                        id={`ayah-${surah.number}-${verse.number}`}
                        className={`inline transition-all duration-300 rounded-md px-1 select-text ${
                          isPlayingThis
                            ? 'bg-emerald-200/90 dark:bg-emerald-950/90 text-emerald-950 dark:text-emerald-100 ring-2 ring-emerald-500 rounded-lg shadow-sm font-semibold'
                            : isPulsing
                            ? 'verse-highlight-active'
                            : isSaved
                            ? 'bg-amber-100/70 dark:bg-amber-950/40 text-emerald-950 dark:text-emerald-200 border-b-2 border-amber-500'
                            : 'hover:bg-emerald-500/10 dark:hover:bg-emerald-500/15'
                        }`}
                      >
                        <span className="inline">
                          <TajweedVerseText 
                            text={verse.text} 
                            enabled={tajweedActive} 
                            onRuleClick={() => setShowTajweedModal(true)} 
                          />
                        </span>
                        <span
                          onPointerDown={(e) => e.stopPropagation()}
                          onPointerUp={(e) => e.stopPropagation()}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedAyahForModal(verse);
                          }}
                          className="inline-flex items-center gap-0.5 cursor-pointer hover:scale-115 active:scale-95 transition-transform align-middle mx-0.5"
                          title={`خيارات الآية ${verse.number.toLocaleString('ar-EG')} (المفضلة، موضع التوقف، نسخ)`}
                        >
                          <AyahEndBadge number={verse.number} />
                          {isFav && (
                            <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500 inline align-middle animate-in zoom-in-50" />
                          )}
                        </span>
                        {sajda && (
                          <SajdaBadge 
                            marker={sajda} 
                            onClick={() => setSelectedSajdaModal(sajda)} 
                          />
                        )}
                        {' '}
                      </span>
                    </React.Fragment>
                  );
                })}
              </div>
            ) : (
              /* Mode 2: Verse by Verse List with Distinct Section Banners for Divisions */
              <div className="space-y-4" dir="rtl">
                {verses.map((verse) => {
                  const isSaved = savedVerseNumber === verse.number;
                  const isPulsing = activeHighlightVerse === verse.number;
                  const isFav = favoriteVerseNumbers.has(verse.number);
                  const division = getVerseDivision(surah.number, verse.number);
                  const sajda = getVerseSajda(surah.number, verse.number);

                  return (
                    <React.Fragment key={verse.number}>
                      {/* Division Banner before the starting verse */}
                      {division && (
                        <QuranDivisionBadge 
                          marker={division} 
                          mode="banner" 
                          onClick={() => setSelectedDivisionModal(division)} 
                        />
                      )}

                      <div
                        ref={(el) => {
                          if (el) verseRefs.current.set(verse.number, el);
                          else verseRefs.current.delete(verse.number);
                        }}
                        id={`ayah-${surah.number}-${verse.number}`}
                        className={`p-4 sm:p-5 rounded-2xl border transition-all duration-300 flex flex-col gap-3 ${
                          currentPlayingVerse === verse.number
                            ? 'bg-emerald-50/90 dark:bg-emerald-950/40 border-emerald-500 dark:border-emerald-600 shadow-md ring-2 ring-emerald-500/20'
                            : sajda
                            ? 'bg-amber-500/5 dark:bg-amber-950/25 border-amber-400/80 dark:border-amber-600/70 shadow-xs'
                            : isPulsing
                            ? 'verse-highlight-active border-amber-500 shadow-md'
                            : isSaved
                            ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-400/80 dark:border-amber-600/70 shadow-xs'
                            : 'bg-stone-50/70 dark:bg-stone-950/40 border-stone-200/80 dark:border-stone-800/80 hover:border-emerald-600/40'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-4 w-full">
                          <div className="flex items-start gap-4 flex-1">
                            <span
                              onPointerDown={(e) => e.stopPropagation()}
                              onPointerUp={(e) => e.stopPropagation()}
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedAyahForModal(verse);
                              }}
                              className="inline-block cursor-pointer shrink-0 mt-1"
                              title={`خيارات الآية ${verse.number.toLocaleString('ar-EG')} (المفضلة، موضع التوقف، نسخ)`}
                            >
                              <AyahEndBadge number={verse.number} />
                            </span>
                            <div className={`${fontFamilyClass} flex-1 text-right text-stone-900 dark:text-stone-100 select-text ${fontSizes[fontSizeLevel] || fontSizes[2]}`}>
                              <TajweedVerseText 
                                text={verse.text} 
                                enabled={tajweedActive} 
                                onRuleClick={() => setShowTajweedModal(true)} 
                              />
                              {sajda && (
                                <SajdaBadge 
                                  marker={sajda} 
                                  onClick={() => setSelectedSajdaModal(sajda)} 
                                />
                              )}
                            </div>
                          </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          {/* Audio Listen to Verse Button */}
                          <button
                            onPointerDown={(e) => e.stopPropagation()}
                            onPointerUp={(e) => e.stopPropagation()}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (currentPlayingVerse === verse.number && isPlayingAudio) {
                                handlePauseAudio();
                              } else {
                                playVerseAudio(verse.number);
                              }
                            }}
                            type="button"
                            title={currentPlayingVerse === verse.number && isPlayingAudio ? 'إيقاف التلاوة مؤقتاً' : 'الاستماع إلى تلاوة هذه الآية'}
                            aria-label={currentPlayingVerse === verse.number && isPlayingAudio ? 'إيقاف التلاوة مؤقتاً' : 'الاستماع إلى تلاوة هذه الآية'}
                            className={`p-2 rounded-xl transition-all active:scale-90 ${
                              currentPlayingVerse === verse.number && isPlayingAudio
                                ? 'bg-emerald-600 text-white shadow-xs scale-105'
                                : currentPlayingVerse === verse.number
                                ? 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 border border-emerald-400'
                                : 'text-stone-400 hover:text-emerald-700 dark:hover:text-emerald-400 hover:bg-stone-200/60 dark:hover:bg-stone-800'
                            }`}
                          >
                            {currentPlayingVerse === verse.number && isPlayingAudio ? (
                              <Pause className="w-4 h-4 fill-current" />
                            ) : (
                              <Volume2 className="w-4 h-4" />
                            )}
                          </button>

                          {/* Tafsir Ayah Button */}
                          <button
                            onPointerDown={(e) => e.stopPropagation()}
                            onPointerUp={(e) => e.stopPropagation()}
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedAyahForTafsir(verse);
                            }}
                            type="button"
                            title={`تفسير الآية ${verse.number.toLocaleString('ar-EG')} (الميسر، السعدي، ابن كثير)`}
                            aria-label={`تفسير الآية ${verse.number}`}
                            className="p-2 rounded-xl text-stone-400 hover:text-amber-600 dark:hover:text-amber-400 hover:bg-amber-500/10 dark:hover:bg-amber-400/10 transition-all active:scale-90"
                          >
                            <BookOpen className="w-4 h-4" />
                          </button>

                          {/* Favorite Verse Button */}
                          <button
                            onPointerDown={(e) => e.stopPropagation()}
                            onPointerUp={(e) => e.stopPropagation()}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleFavoriteVerse(verse);
                            }}
                            type="button"
                            title={isFav ? 'إزالة الآية من المفضلة' : 'حفظ الآية في المفضلة'}
                            aria-label={isFav ? 'إزالة الآية من المفضلة' : 'حفظ الآية في المفضلة'}
                            className={`p-2 rounded-xl transition-all active:scale-90 ${
                              isFav
                                ? 'bg-rose-50 dark:bg-rose-950/70 text-rose-600 dark:text-rose-400 border border-rose-300 dark:border-rose-800 scale-105 shadow-xs'
                                : 'text-stone-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-stone-200/60 dark:hover:bg-stone-800'
                            }`}
                          >
                            <Heart className={`w-4 h-4 transition-transform ${isFav ? 'fill-rose-500 text-rose-500' : ''}`} />
                          </button>

                          {/* Reading Bookmark Button */}
                          <button
                            onPointerDown={(e) => e.stopPropagation()}
                            onPointerUp={(e) => e.stopPropagation()}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSaveVerse(verse.number);
                            }}
                            type="button"
                            title={isSaved ? 'الموضع المحفوظ حالياً' : 'تحديد الآية كموضع توقف'}
                            className={`p-2 rounded-xl transition-all ${
                              isSaved
                                ? 'bg-amber-500 text-stone-950 shadow-xs scale-105'
                                : 'text-stone-400 hover:text-amber-600 dark:hover:text-amber-400 hover:bg-stone-200/60 dark:hover:bg-stone-800'
                            }`}
                          >
                            <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                          </button>
                        </div>
                      </div>

                      {/* Distinct Sajda Banner for Verse in Mode 2 */}
                      {sajda && (
                        <div className="w-full pt-1 border-t border-amber-400/30 dark:border-amber-600/30">
                          <SajdaBadge 
                            marker={sajda} 
                            mode="banner" 
                            onClick={() => setSelectedSajdaModal(sajda)} 
                          />
                        </div>
                      )}
                    </div>
                  </React.Fragment>
                  );
                })}
              </div>
            )}
          </>
        )}

        {/* Surah End Ornate Flourish */}
        <div className={`border-t border-stone-200 dark:border-stone-800 flex flex-col items-center justify-center text-center space-y-2.5 ${
          viewMode === 'page' ? 'mt-6 pt-4' : 'mt-12 pt-6'
        }`}>
          <div className="flex items-center gap-3 text-emerald-800 dark:text-emerald-400">
            <span className="w-8 h-px bg-current opacity-40" />
            <span className="font-amiri text-lg font-bold">نهاية سورة {surah.name}</span>
            <span className="w-8 h-px bg-current opacity-40" />
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowTajweedModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/80 text-emerald-800 dark:text-emerald-300 border border-emerald-300/60 dark:border-emerald-800 text-xs font-medium transition-colors"
            >
              <Palette className="w-3.5 h-3.5" />
              <span>دليل ألوان أحكام التجويد</span>
            </button>
          </div>

          <p className="text-[11px] text-stone-400 dark:text-stone-500 font-sans">
            نص القرآن الكريم وعلامات تقسيم الأحزاب والأثمان برواية ورش عن نافع
          </p>
        </div>

      </article>
      )}

      {/* Bottom Navigation between Surahs */}
      <div 
        onPointerDown={(e) => e.stopPropagation()}
        onPointerUp={(e) => e.stopPropagation()}
        className="flex items-center justify-between gap-3 pt-2"
      >
        <button
          onClick={handlePrevSurah}
          disabled={surah.number <= 1}
          type="button"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 disabled:opacity-30 disabled:pointer-events-none text-xs sm:text-sm font-semibold transition-colors"
        >
          <ChevronRight className="w-4 h-4" />
          <span>السورة السابقة</span>
        </button>

        <button
          onClick={onBack}
          type="button"
          className="px-4 py-2.5 rounded-xl bg-stone-200/70 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-300/70 dark:hover:bg-stone-700 text-xs sm:text-sm font-semibold transition-colors"
        >
          الفهرس
        </button>

        <button
          onClick={handleNextSurah}
          disabled={surah.number >= 114}
          type="button"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 disabled:opacity-30 disabled:pointer-events-none text-xs sm:text-sm font-semibold transition-colors"
        >
          <span>السورة التالية</span>
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      {/* Detailed Modal for Division Marker */}
      <DivisionDetailsModal
        marker={selectedDivisionModal}
        onClose={() => setSelectedDivisionModal(null)}
        onJumpToVerse={handleScrollToVerse}
      />

      {/* Tajweed Rules Color Legend Modal */}
      <TajweedLegendModal
        isOpen={showTajweedModal}
        onClose={() => setShowTajweedModal(false)}
        isTajweedActive={tajweedActive}
        onToggleTajweed={handleToggleTajweed}
      />

      {/* Ayah Actions Modal (Favorite, Bookmark, Copy, Share, Audio) */}
      <AyahActionsModal
        isOpen={!!selectedAyahForModal}
        onClose={() => setSelectedAyahForModal(null)}
        verse={selectedAyahForModal}
        surah={surah}
        isFavorite={selectedAyahForModal ? favoriteVerseNumbers.has(selectedAyahForModal.number) : false}
        onToggleFavorite={() => {
          if (selectedAyahForModal) {
            handleToggleFavoriteVerse(selectedAyahForModal);
          }
        }}
        isSavedAsBookmark={selectedAyahForModal ? savedVerseNumber === selectedAyahForModal.number : false}
        onSaveAsBookmark={() => {
          if (selectedAyahForModal) {
            handleSaveVerse(selectedAyahForModal.number);
          }
        }}
        onOpenTajweedLegend={() => setShowTajweedModal(true)}
        tajweedActive={tajweedActive}
        onPlayVerse={playVerseAudio}
        isPlayingCurrentVerse={currentPlayingVerse === selectedAyahForModal?.number && isPlayingAudio}
        onOpenTafsir={() => {
          if (selectedAyahForModal) {
            setSelectedAyahForTafsir(selectedAyahForModal);
          }
        }}
        onOpenSajda={() => {
          if (selectedAyahForModal) {
            const s = getVerseSajda(surah.number, selectedAyahForModal.number);
            if (s) {
              setSelectedSajdaModal(s);
            }
          }
        }}
      />

      {/* Favorite Verses Side Drawer */}
      <FavoriteVersesSidebar
        isOpen={showFavoriteSidebar}
        onClose={() => setShowFavoriteSidebar(false)}
        onSelectVerse={(surahNum, verseNum) => {
          if (surahNum === surah.number) {
            handleScrollToVerse(verseNum);
          } else {
            const targetSurah = SURAHS.find((s) => s.number === surahNum);
            if (targetSurah) {
              onSelectSurah(targetSurah, verseNum);
            }
          }
        }}
      />

      {/* Advanced Typography Settings Modal */}
      <TypographySettingsModal
        isOpen={showTypographyModal}
        onClose={() => setShowTypographyModal(false)}
        fontFamily={fontFamily}
        onChangeFontFamily={(f) => setFontFamily(f)}
        fontSizeLevel={fontSizeLevel}
        onChangeFontSizeLevel={(l) => setFontSizeLevel(l)}
        lineSpacing={lineSpacing}
        onChangeLineSpacing={(s) => setLineSpacing(s)}
      />

      {/* Interactive Quran Audio Player Floating Bar */}
      <QuranAudioPlayerBar
        surah={surah}
        verses={verses}
        currentPlayingVerseNumber={currentPlayingVerse}
        isPlaying={isPlayingAudio}
        onPlayVerse={playVerseAudio}
        onPause={handlePauseAudio}
        onResume={handleResumeAudio}
        onClose={handleCloseAudio}
        selectedReciter={selectedReciter}
        onChangeReciter={handleChangeReciter}
        repeatMode={repeatMode}
        onChangeRepeatMode={handleChangeRepeatMode}
        repeatCount={currentVerseRepeatCount}
      />

      {/* Ayah Tafsir Modal (التفسير الميسر، السعدي، ابن كثير) */}
      <TafsirModal
        isOpen={!!selectedAyahForTafsir}
        onClose={() => setSelectedAyahForTafsir(null)}
        verse={selectedAyahForTafsir}
        surah={surah}
        onSelectVerse={(verseNum) => {
          const nextV = verses.find((v) => v.number === verseNum);
          if (nextV) {
            setSelectedAyahForTafsir(nextV);
            handleScrollToVerse(verseNum);
          }
        }}
        totalVersesCount={verses.length}
      />

      {/* Sajda Dua Modal (دعاء وأحكام سجود التلاوة) */}
      <SajdaDuaModal
        isOpen={!!selectedSajdaModal}
        onClose={() => setSelectedSajdaModal(null)}
        marker={selectedSajdaModal}
        surah={surah}
        verse={selectedSajdaModal ? verses.find((v) => v.number === selectedSajdaModal.verseNumber) || null : null}
        onPlayVerse={playVerseAudio}
        onOpenTafsir={(v) => {
          setSelectedSajdaModal(null);
          setSelectedAyahForTafsir(v);
        }}
      />

    </div>
  );
};
