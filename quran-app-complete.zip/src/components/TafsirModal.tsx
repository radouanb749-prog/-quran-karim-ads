import React, { useState, useEffect } from 'react';
import { 
  X, 
  BookOpen, 
  Copy, 
  Check, 
  Share2, 
  Loader2, 
  ChevronRight, 
  ChevronLeft, 
  RefreshCw,
  ZoomIn,
  ZoomOut,
  Sparkles
} from 'lucide-react';
import { Verse } from '../services/quranService';
import { Surah } from '../data/surahs';
import { 
  TAFSIR_SOURCES, 
  TafsirSource, 
  getAyahTafsir, 
  getSavedTafsirSourceId, 
  saveTafsirSourceId 
} from '../services/tafsirService';

interface TafsirModalProps {
  isOpen: boolean;
  onClose: () => void;
  verse: Verse | null;
  surah: Surah;
  onSelectVerse?: (verseNumber: number) => void;
  totalVersesCount: number;
}

export const TafsirModal: React.FC<TafsirModalProps> = ({
  isOpen,
  onClose,
  verse,
  surah,
  onSelectVerse,
  totalVersesCount,
}) => {
  const [selectedSourceId, setSelectedSourceId] = useState<number>(() => getSavedTafsirSourceId());
  const [tafsirText, setTafsirText] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [tafsirFontSize, setTafsirFontSize] = useState<number>(1); // 0: small, 1: medium, 2: large, 3: x-large

  const fontClasses = [
    'text-sm sm:text-base leading-relaxed',
    'text-base sm:text-lg leading-loose',
    'text-lg sm:text-xl leading-loose',
    'text-xl sm:text-2xl leading-loose',
  ];

  // Fetch tafsir when verse or selected source changes
  useEffect(() => {
    if (!isOpen || !verse) return;

    let isMounted = true;
    setLoading(true);
    setError(null);

    getAyahTafsir(surah.number, verse.number, selectedSourceId)
      .then((res) => {
        if (isMounted) {
          setTafsirText(res.text);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          setError(err.message || 'تعذر تحميل التفسير');
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, verse?.number, surah.number, selectedSourceId]);

  if (!isOpen || !verse) return null;

  const currentSource = TAFSIR_SOURCES.find((s) => s.id === selectedSourceId) || TAFSIR_SOURCES[0];

  const handleCopy = async () => {
    try {
      const fullText = `﴿ ${verse.text} ﴾\n[سورة ${surah.name} - الآية ${verse.number}]\n\n*${currentSource.name}:*\n${tafsirText}`;
      await navigator.clipboard.writeText(fullText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const handleShare = async () => {
    const fullText = `﴿ ${verse.text} ﴾\n[سورة ${surah.name} - الآية ${verse.number}]\n\n*${currentSource.name}:*\n${tafsirText}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `تفسير الآية ${verse.number} من سورة ${surah.name}`,
          text: fullText,
        });
      } catch {
        handleCopy();
      }
    } else {
      handleCopy();
    }
  };

  const handlePrevVerse = () => {
    if (verse.number > 1 && onSelectVerse) {
      onSelectVerse(verse.number - 1);
    }
  };

  const handleNextVerse = () => {
    if (verse.number < totalVersesCount && onSelectVerse) {
      onSelectVerse(verse.number + 1);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs"
      dir="rtl"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-2xl bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between bg-stone-50/80 dark:bg-stone-950/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950/80 flex items-center justify-center text-emerald-800 dark:text-emerald-300 shadow-xs">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <span>تفسير الآية {verse.number.toLocaleString('ar-EG')}</span>
                <span className="text-xs text-stone-500 font-normal">
                  سورة {surah.name}
                </span>
              </h2>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">
                الصفحة {surah.page.toLocaleString('ar-EG')} • الجزء {surah.juz.toLocaleString('ar-EG')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Font size zoom controls */}
            <div className="hidden sm:flex items-center bg-stone-200/60 dark:bg-stone-800 p-0.5 rounded-lg border border-stone-200 dark:border-stone-700">
              <button
                type="button"
                onClick={() => setTafsirFontSize((prev) => Math.max(0, prev - 1))}
                disabled={tafsirFontSize === 0}
                className="p-1 rounded text-stone-600 dark:text-stone-300 hover:text-stone-900 disabled:opacity-30"
                title="تصغير خط التفسير"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setTafsirFontSize((prev) => Math.min(fontClasses.length - 1, prev + 1))}
                disabled={tafsirFontSize === fontClasses.length - 1}
                className="p-1 rounded text-stone-600 dark:text-stone-300 hover:text-stone-900 disabled:opacity-30"
                title="تكبير خط التفسير"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tafsir Book Tabs */}
        <div className="px-4 sm:px-6 pt-3 pb-2 border-b border-stone-100 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50 flex items-center gap-2 overflow-x-auto no-scrollbar">
          {TAFSIR_SOURCES.map((source) => {
            const isSelected = selectedSourceId === source.id;
            return (
              <button
                key={source.id}
                type="button"
                onClick={() => {
                  setSelectedSourceId(source.id);
                  saveTafsirSourceId(source.id);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-100 border border-stone-200 dark:border-stone-700'
                }`}
              >
                <span>{source.name}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          
          {/* Ayah Card Display */}
          <div className="p-4 sm:p-5 rounded-2xl bg-amber-500/5 dark:bg-amber-400/5 border border-amber-500/20 dark:border-amber-400/20 text-center">
            <p className="font-amiri text-xl sm:text-2xl text-emerald-950 dark:text-emerald-100 leading-loose select-text">
              ﴿ {verse.text} ﴾
            </p>
          </div>

          {/* Tafsir Content Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200/80 dark:border-stone-800 space-y-2 min-h-[160px] flex flex-col justify-center">
            {loading ? (
              <div className="py-8 flex flex-col items-center justify-center gap-3 text-stone-500 dark:text-stone-400">
                <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
                <span className="text-xs sm:text-sm font-medium">جاري جلب نص التفسير المعتمد...</span>
              </div>
            ) : error ? (
              <div className="py-6 text-center space-y-3">
                <p className="text-xs sm:text-sm text-rose-600 dark:text-rose-400">
                  {error}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setLoading(true);
                    setError(null);
                    getAyahTafsir(surah.number, verse.number, selectedSourceId)
                      .then((res) => {
                        setTafsirText(res.text);
                        setLoading(false);
                      })
                      .catch((err) => {
                        setError(err.message || 'تعذر تحميل التفسير');
                        setLoading(false);
                      });
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-100 text-emerald-800 text-xs font-semibold hover:bg-emerald-200"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>إعادة المحاولة</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs text-stone-500 border-b border-stone-200/50 dark:border-stone-800 pb-2">
                  <span className="font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{currentSource.name}</span>
                  </span>
                  <span className="text-[11px] text-stone-400">
                    {currentSource.author}
                  </span>
                </div>

                <div 
                  className={`text-stone-800 dark:text-stone-100 text-justify select-text ${fontClasses[tafsirFontSize]}`}
                  dangerouslySetInnerHTML={{ __html: tafsirText }}
                />
              </div>
            )}
          </div>

        </div>

        {/* Footer Navigation & Actions */}
        <div className="p-3 sm:p-4 border-t border-stone-200 dark:border-stone-800 bg-stone-50/80 dark:bg-stone-950/80 flex items-center justify-between gap-2">
          
          {/* Previous / Next Ayah Stepper */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={handlePrevVerse}
              disabled={verse.number <= 1 || !onSelectVerse}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 disabled:opacity-30 transition-colors"
              title="الآية السابقة"
            >
              <ChevronRight className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">الآية السابقة</span>
            </button>

            <button
              type="button"
              onClick={handleNextVerse}
              disabled={verse.number >= totalVersesCount || !onSelectVerse}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 disabled:opacity-30 transition-colors"
              title="الآية التالية"
            >
              <span className="hidden sm:inline">الآية التالية</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Copy & Share Buttons */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleCopy}
              disabled={loading || !!error}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 transition-colors disabled:opacity-40"
              title="نسخ نص التفسير"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700 dark:text-emerald-400">تم النسخ</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>نسخ التفسير</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleShare}
              disabled={loading || !!error}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs transition-colors disabled:opacity-40"
              title="مشاركة التفسير"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>مشاركة</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
