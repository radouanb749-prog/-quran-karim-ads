import React, { useState } from 'react';
import { X, Sparkles, Check, BookOpen, HelpCircle } from 'lucide-react';
import { TAJWEED_RULES_LIST, TajweedRuleInfo } from '../services/tajweedService';

interface TajweedLegendModalProps {
  isOpen: boolean;
  onClose: () => void;
  isTajweedActive: boolean;
  onToggleTajweed: () => void;
}

export const TajweedLegendModal: React.FC<TajweedLegendModalProps> = ({
  isOpen,
  onClose,
  isTajweedActive,
  onToggleTajweed,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'madd' | 'noon_meem' | 'qalqalah' | 'other'>('all');

  if (!isOpen) return null;

  const categories = [
    { id: 'all', label: 'كافة الأحكام' },
    { id: 'madd', label: 'أحكام المدود' },
    { id: 'noon_meem', label: 'النون والميم' },
    { id: 'qalqalah', label: 'القلقلة' },
    { id: 'other', label: 'صفات أخرى' },
  ];

  const filteredRules = TAJWEED_RULES_LIST.filter((rule) => {
    if (selectedCategory === 'all') return true;
    if (selectedCategory === 'madd') return rule.category === 'madd';
    if (selectedCategory === 'noon_meem') return rule.category === 'noon_meem';
    if (selectedCategory === 'qalqalah') return rule.category === 'qalqalah';
    if (selectedCategory === 'other') return rule.category === 'sifat' || rule.category === 'other';
    return true;
  });

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
      dir="rtl"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-stone-100 dark:border-stone-800 bg-gradient-to-r from-emerald-50/70 via-stone-50 to-amber-50/50 dark:from-stone-900 dark:via-stone-900 dark:to-stone-950 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-700/10 dark:bg-emerald-500/15 border border-emerald-600/30 flex items-center justify-center text-emerald-800 dark:text-emerald-400 shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-amiri text-lg sm:text-xl font-bold text-stone-900 dark:text-stone-100">
                دليل ألوان أحكام التجويد
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                المصحف المجود الملون لتيسير وإتقان التلاوة القرآنية
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            type="button"
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tajweed Switch Quick Bar */}
        <div className="px-4 py-3 bg-stone-50/90 dark:bg-stone-950/60 border-b border-stone-200/60 dark:border-stone-800/60 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-stone-700 dark:text-stone-300">
            <BookOpen className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
            <span>حالة التجويد الملون في المصحف:</span>
            <span className={`font-bold px-2 py-0.5 rounded-full text-xs ${
              isTajweedActive 
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' 
                : 'bg-stone-200 text-stone-600 dark:bg-stone-800 dark:text-stone-400'
            }`}>
              {isTajweedActive ? 'مُفعَّل' : 'معطَّل'}
            </span>
          </div>

          <button
            type="button"
            onClick={onToggleTajweed}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              isTajweedActive
                ? 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs'
                : 'bg-stone-200 hover:bg-stone-300 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300'
            }`}
          >
            {isTajweedActive ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>تعطيل التلوين</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>تفعيل التلوين</span>
              </>
            )}
          </button>
        </div>

        {/* Category Filter Pills */}
        <div className="px-4 py-2.5 border-b border-stone-100 dark:border-stone-800/60 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedCategory(cat.id as any)}
              className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat.id
                  ? 'bg-emerald-800 text-white dark:bg-emerald-700 shadow-xs'
                  : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:bg-stone-200/80 dark:hover:bg-stone-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Rules List (Scrollable) */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-3.5 max-h-[58vh]">
          {filteredRules.map((rule: TajweedRuleInfo) => (
            <div
              key={rule.id}
              className="p-3.5 sm:p-4 rounded-2xl border border-stone-200/80 dark:border-stone-800/80 bg-stone-50/40 dark:bg-stone-950/40 hover:border-stone-300 dark:hover:border-stone-700 transition-all space-y-2"
            >
              {/* Rule Title Row */}
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2.5">
                  <span
                    className="w-4 h-4 rounded-full shrink-0 shadow-xs ring-2 ring-white dark:ring-stone-900"
                    style={{ backgroundColor: rule.colorHex }}
                  />
                  <h4 className="font-amiri text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100">
                    {rule.name}
                  </h4>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`text-[11px] px-2.5 py-0.5 rounded-full font-medium border ${rule.bgBadgeLight} ${rule.bgBadgeDark}`}>
                    {rule.harakat}
                  </span>
                </div>
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-300 leading-relaxed font-sans">
                {rule.description}
              </p>

              {/* Quranic Example */}
              <div className="pt-2 border-t border-stone-200/50 dark:border-stone-800/50 flex items-center justify-between text-xs">
                <span className="text-stone-400 dark:text-stone-500 font-medium">أمثلة قرآنية:</span>
                <span 
                  className={`font-quran text-base sm:text-lg tracking-wide ${rule.textColorLight} ${rule.textColorDark}`}
                  dir="rtl"
                >
                  {rule.example}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 border-t border-stone-100 dark:border-stone-800 bg-stone-50/60 dark:bg-stone-950/40 flex items-center justify-between text-xs text-stone-500 dark:text-stone-400">
          <div className="flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4 text-stone-400 shrink-0" />
            <span>يمكنك النقر على أي حرف ملون في نص المصحف لعرض اسمه وحركاته</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-stone-200 hover:bg-stone-300 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-200 font-medium transition-colors"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
