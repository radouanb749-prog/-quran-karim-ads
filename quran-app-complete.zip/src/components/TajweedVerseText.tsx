import React, { useMemo } from 'react';
import { parseTajweed, TajweedRuleInfo } from '../services/tajweedService';

interface TajweedVerseTextProps {
  text: string;
  enabled: boolean;
  onRuleClick?: (rule: TajweedRuleInfo) => void;
}

export const TajweedVerseText: React.FC<TajweedVerseTextProps> = ({
  text,
  enabled,
  onRuleClick,
}) => {
  const segments = useMemo(() => {
    if (!enabled) return null;
    return parseTajweed(text);
  }, [text, enabled]);

  if (!enabled || !segments) {
    return <>{text}</>;
  }

  return (
    <>
      {segments.map((segment, idx) => {
        if (!segment.rule) {
          return <React.Fragment key={idx}>{segment.text}</React.Fragment>;
        }

        const { rule, tooltip } = segment;

        return (
          <span
            key={idx}
            className={`${rule.textColorLight} ${rule.textColorDark} inline cursor-help transition-opacity duration-150 hover:opacity-80 active:opacity-95`}
            title={tooltip || `${rule.name} (${rule.harakat})`}
            onClick={
              onRuleClick
                ? (e) => {
                    e.stopPropagation();
                    onRuleClick(rule);
                  }
                : undefined
            }
          >
            {segment.text}
          </span>
        );
      })}
    </>
  );
};
