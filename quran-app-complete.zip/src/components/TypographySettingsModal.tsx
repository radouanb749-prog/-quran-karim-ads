import React from 'react';
import { 
  X, 
  Type, 
  ZoomIn, 
  ZoomOut, 
  Check, 
  RotateCcw, 
  Sparkles, 
  AlignJustify,
  Eye
} from 'lucide-react';
import { 
  QuranFontFamily, 
  QuranLineSpacing, 
  FONT_FAMILY_OPTIONS, 
  FONT_SIZE_LEVELS, 
  LINE_SPACING_OPTIONS,
  saveFontFamily,
  saveFontSizeLevel,
  saveLineSpacing
} from '../services/typographyService';

interface TypographySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  fontFamily: QuranFontFamily;
  onChangeFontFamily: (font: QuranFontFamily) => void;
  fontSizeLevel: number;
  onChangeFontSizeLevel: (level: number) => void;
  lineSpacing: QuranLineSpacing;
  onChangeLineSpacing: (spacing: QuranLineSpacing) => void;
}

export const TypographySettingsModal: React.FC<TypographySettingsModalProps> = ({
  isOpen,
  onClose,
  fontFamily,
  onChangeFontFamily,
  fontSizeLevel,
  onChangeFontSizeLevel,
  lineSpacing,
  onChangeLineSpacing,
}) => {
  if (!isOpen) return null;

  const currentFontOption = FONT_FAMILY_OPTIONS.find((f) => f.id === fontFamily) || FONT_FAMILY_OPTIONS[0];
  const currentSizeOption = FONT_SIZE_LEVELS[fontSizeLevel] || FONT_SIZE_LEVELS[2];
  const currentSpacingOption = LINE_SPACING_OPTIONS.find((s) => s.id === lineSpacing) || LINE_SPACING_OPTIONS[1];

  const handleSelectFont = (fontId: QuranFontFamily) => {
    onChangeFontFamily(fontId);
    saveFontFamily(fontId);
  };

  const handleSelectSize = (level: number) => {
    const clamped = Math.max(0, Math.min(FONT_SIZE_LEVELS.length - 1, level));
    onChangeFontSizeLevel(clamped);
    saveFontSizeLevel(clamped);
  };

  const handleSelectSpacing = (spacingId: QuranLineSpacing) => {
    onChangeLineSpacing(spacingId);
    saveLineSpacing(spacingId);
  };

  const handleResetDefaults = () => {
    handleSelectFont('uthmani');
    handleSelectSize(2);
    handleSelectSpacing('comfortable');
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs"
      dir="rtl"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-lg bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between bg-stone-50/80 dark:bg-stone-950/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950/80 flex items-center justify-center text-emerald-800 dark:text-emerald-300 shadow-xs">
              <Type className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <span>تخصيص خط وقراءة الآيات</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-medium">
                  متقدم
                </span>
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                اختر نوع الخط المفضل وحجمه وتباعد الأسطر لراحة العين والتدبر
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6">
          
          {/* Section 1: Font Family Selection (نوع الخط) */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-stone-800 dark:text-stone-200 flex items-center gap-1.5">
                <Type className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>نوع الخط القرآني</span>
              </label>
              <span className="text-[11px] text-stone-500 font-medium">
                {currentFontOption.name}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {FONT_FAMILY_OPTIONS.map((font) => {
                const isSelected = fontFamily === font.id;
                return (
                  <button
                    key={font.id}
                    type="button"
                    onClick={() => handleSelectFont(font.id)}
                    className={`p-3.5 rounded-2xl border text-right transition-all flex flex-col justify-between gap-2 relative ${
                      isSelected
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 dark:border-emerald-600 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'bg-white dark:bg-stone-850 border-stone-200 dark:border-stone-700 hover:border-emerald-300 hover:bg-stone-50'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-bold text-xs sm:text-sm text-stone-900 dark:text-stone-100">
                        {font.name}
                      </span>
                      {isSelected ? (
                        <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </span>
                      ) : (
                        <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-500">
                          {font.badge}
                        </span>
                      )}
                    </div>

                    {/* Font Preview Sample */}
                    <div className={`text-base sm:text-lg text-emerald-950 dark:text-emerald-100 pt-1 border-t border-stone-100 dark:border-stone-800 text-center ${font.fontClass}`}>
                      {font.id === 'uthmani' ? 'بِسْمِ ٱللَّهِ' : 'بِسْمِ اللَّهِ'}
                    </div>

                    <p className="text-[10px] text-stone-500 dark:text-stone-400 line-clamp-1">
                      {font.subname}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 2: Font Size Slider & Stepper (حجم الخط) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-stone-800 dark:text-stone-200 flex items-center gap-1.5">
                <ZoomIn className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>حجم خط الآيات</span>
              </label>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 bg-emerald-100/70 dark:bg-emerald-950 px-2.5 py-0.5 rounded-full">
                  {currentSizeOption.label}
                </span>
                <span className="text-[11px] text-stone-400 font-mono">
                  (مستوى {fontSizeLevel + 1} من {FONT_SIZE_LEVELS.length})
                </span>
              </div>
            </div>

            {/* Stepper + Slider Row */}
            <div className="p-3.5 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-700 space-y-3">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => handleSelectSize(fontSizeLevel - 1)}
                  disabled={fontSizeLevel === 0}
                  className="p-2 rounded-xl bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-600 text-stone-700 dark:text-stone-300 hover:bg-stone-100 disabled:opacity-30 disabled:hover:bg-white transition-all shadow-2xs"
                  title="تصغير الخط"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>

                <div className="flex-1 relative flex items-center">
                  <input
                    type="range"
                    min={0}
                    max={FONT_SIZE_LEVELS.length - 1}
                    step={1}
                    value={fontSizeLevel}
                    onChange={(e) => handleSelectSize(parseInt(e.target.value, 10))}
                    className="w-full accent-emerald-600 cursor-pointer h-2 bg-stone-200 dark:bg-stone-700 rounded-lg"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => handleSelectSize(fontSizeLevel + 1)}
                  disabled={fontSizeLevel === FONT_SIZE_LEVELS.length - 1}
                  className="p-2 rounded-xl bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-600 text-stone-700 dark:text-stone-300 hover:bg-stone-100 disabled:opacity-30 disabled:hover:bg-white transition-all shadow-2xs"
                  title="تكبير الخط"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
              </div>

              {/* Level Dots Buttons */}
              <div className="grid grid-cols-6 gap-1 pt-1 text-center">
                {FONT_SIZE_LEVELS.map((size) => {
                  const isCur = fontSizeLevel === size.level;
                  return (
                    <button
                      key={size.level}
                      type="button"
                      onClick={() => handleSelectSize(size.level)}
                      className={`py-1 rounded-lg text-[10px] font-medium transition-colors ${
                        isCur
                          ? 'bg-emerald-600 text-white font-bold shadow-2xs'
                          : 'bg-white/60 dark:bg-stone-800/60 text-stone-600 dark:text-stone-400 hover:bg-stone-200'
                      }`}
                    >
                      {size.label.split(' ')[0]}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Section 3: Line Spacing (تباعد الأسطر) */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-stone-800 dark:text-stone-200 flex items-center gap-1.5">
                <AlignJustify className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>تباعد وارتفاع الأسطر</span>
              </label>
              <span className="text-[11px] text-stone-500 font-medium">
                {currentSpacingOption.name}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {LINE_SPACING_OPTIONS.map((spacing) => {
                const isSelected = lineSpacing === spacing.id;
                return (
                  <button
                    key={spacing.id}
                    type="button"
                    onClick={() => handleSelectSpacing(spacing.id)}
                    className={`py-2 px-3 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-700 font-bold shadow-xs'
                        : 'bg-white dark:bg-stone-850 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50'
                    }`}
                  >
                    <div className="text-xs font-bold">{spacing.name}</div>
                    <div className={`text-[10px] ${isSelected ? 'text-emerald-100' : 'text-stone-400'}`}>
                      {spacing.description}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 4: Live Real-Time Ayah Preview (معاينة حية فورية) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400">
              <span className="flex items-center gap-1 font-semibold text-stone-700 dark:text-stone-300">
                <Eye className="w-3.5 h-3.5 text-amber-500" />
                <span>معاينة حية لخط الآيات:</span>
              </span>
              <span>سورة الإخلاص</span>
            </div>

            <div className="p-4 sm:p-5 rounded-2xl bg-amber-500/5 dark:bg-amber-400/5 border border-amber-500/25 dark:border-amber-400/20 text-center relative overflow-hidden">
              <p 
                className={`text-emerald-950 dark:text-emerald-100 select-text transition-all ${currentFontOption.fontClass} ${currentSizeOption.sizeClass} ${currentSpacingOption.lineHeightClass}`}
              >
                ﴿ قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ ﴾
              </p>
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-stone-200 dark:border-stone-800 bg-stone-50/80 dark:bg-stone-950/80 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-stone-600 dark:text-stone-400 hover:bg-stone-200/60 dark:hover:bg-stone-800 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>استعادة الافتراضي</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95"
          >
            <Check className="w-4 h-4" />
            <span>تطبيق وإغلاق</span>
          </button>
        </div>

      </div>
    </div>
  );
};
