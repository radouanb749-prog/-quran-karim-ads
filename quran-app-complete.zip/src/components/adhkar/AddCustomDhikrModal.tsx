import React, { useState } from 'react';
import { X, Plus, Sparkles, Heart } from 'lucide-react';
import { DhikrCategory } from '../../data/adhkar';

interface AddCustomDhikrModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddDhikr: (dhikr: {
    title: string;
    text: string;
    count: number;
    fadl?: string;
    category?: DhikrCategory;
  }) => void;
}

export const AddCustomDhikrModal: React.FC<AddCustomDhikrModalProps> = ({
  isOpen,
  onClose,
  onAddDhikr,
}) => {
  const [title, setTitle] = useState('');
  const [text, setText] = useState('');
  const [count, setCount] = useState<number>(3);
  const [fadl, setFadl] = useState('');
  const [category, setCategory] = useState<DhikrCategory>('morning');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) {
      setError('يرجى كتابة نص الذكر أو الدعاء');
      return;
    }

    onAddDhikr({
      title: title.trim() || 'ذكر مخصص',
      text: text.trim(),
      count: Math.max(1, count),
      fadl: fadl.trim() || undefined,
      category,
    });

    // Reset and close
    setTitle('');
    setText('');
    setCount(3);
    setFadl('');
    setError('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div 
        className="w-full max-w-lg bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        dir="rtl"
      >
        {/* Modal Header */}
        <div className="p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between bg-stone-50/70 dark:bg-stone-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-800 dark:text-emerald-300">
              <Heart className="w-5 h-5 fill-emerald-800 dark:fill-emerald-300" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-stone-900 dark:text-stone-100">
                إضافة ذكر إلى المفضلة
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                أضف ذكرك أو دعاءك الخاص وسيُحفظ تلقائياً في قائمة مفضلتك
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Form */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs font-semibold">
              {error}
            </div>
          )}

          {/* Title */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300">
              عنوان الذكر أو المناسبة (اختياري)
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: دعاء راحة البال، الصلاة الإبراهيمية، استغفار خاص..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-700"
            />
          </div>

          {/* Category */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300">
              القسم التابع له
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'morning', label: 'أذكار الصباح' },
                { id: 'evening', label: 'أذكار المساء' },
                { id: 'after_prayer', label: 'بعد الصلاة' },
                { id: 'custom', label: 'أذكار عامة' },
              ].map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategory(cat.id as DhikrCategory)}
                  className={`py-2 px-3 rounded-xl text-xs font-medium border text-center transition-all ${
                    category === cat.id
                      ? 'bg-emerald-800 text-white border-emerald-800 dark:bg-emerald-700 dark:border-emerald-600 shadow-xs'
                      : 'bg-white dark:bg-stone-800/80 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-700 hover:bg-stone-50'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Text */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300">
              نص الذكر أو الدعاء المبارك <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={4}
              value={text}
              onChange={(e) => {
                setText(e.target.value);
                if (error) setError('');
              }}
              placeholder="اكتب نص الذكر هنا بالتشكيل أو بدونه..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-base font-amiri leading-relaxed text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-700"
              required
            />
          </div>

          {/* Repetitions Count */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300">
              عدد مرات التكرار (الهدف)
            </label>
            <div className="flex items-center gap-2">
              {[1, 3, 7, 33, 100].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setCount(num)}
                  className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                    count === num
                      ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border-emerald-400'
                      : 'bg-stone-50 dark:bg-stone-800 text-stone-600 dark:text-stone-300 border-stone-200 dark:border-stone-700'
                  }`}
                >
                  {num}
                </button>
              ))}
              <input
                type="number"
                min={1}
                max={1000}
                value={count}
                onChange={(e) => setCount(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-20 px-2 py-1.5 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-center text-xs font-bold text-stone-900 dark:text-stone-100"
              />
            </div>
          </div>

          {/* Virtue/Fadl */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300">
              الفضل أو الملاحظة (اختياري)
            </label>
            <input
              type="text"
              value={fadl}
              onChange={(e) => setFadl(e.target.value)}
              placeholder="مثال: يقال عند القلق، يجلب الطمأنينة وسعة الرزق..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-700"
            />
          </div>

          {/* Footer Submit Buttons */}
          <div className="pt-3 border-t border-stone-100 dark:border-stone-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-md transition-colors"
            >
              <Plus className="w-4 h-4" />
              حفظ في المفضلة
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
