import React, { useState, useMemo, useEffect } from 'react';
import { 
  Sun, 
  Moon, 
  Compass, 
  Heart, 
  Search, 
  X, 
  RotateCcw, 
  Plus, 
  Sparkles, 
  CheckCircle2, 
  Filter, 
  BookMarked,
  ArrowRight
} from 'lucide-react';
import { DhikrItem, DEFAULT_ADHKAR } from '../../data/adhkar';
import { DhikrCard } from './DhikrCard';
import { AddCustomDhikrModal } from './AddCustomDhikrModal';
import {
  getAllAdhkar,
  getFavoriteDhikrIds,
  toggleFavoriteDhikr,
  getDhikrCounters,
  incrementDhikrCount,
  resetDhikrCount,
  resetAllCounters,
  addCustomDhikr,
  deleteCustomDhikr,
} from '../../services/adhkarService';

type ActiveTab = 'morning' | 'evening' | 'after_prayer' | 'favorites';

interface AdhkarSectionProps {
  onBackToQuran?: () => void;
  initialTab?: ActiveTab;
}

export const AdhkarSection: React.FC<AdhkarSectionProps> = ({
  onBackToQuran,
  initialTab = 'morning',
}) => {
  const [activeTab, setActiveTab] = useState<ActiveTab>(initialTab);
  const [searchQuery, setSearchQuery] = useState('');
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => getFavoriteDhikrIds());
  const [counters, setCounters] = useState<Record<string, number>>(() => getDhikrCounters());
  const [allAdhkarList, setAllAdhkarList] = useState<DhikrItem[]>(() => getAllAdhkar());
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [fontSizeLevel, setFontSizeLevel] = useState<number>(1); // 0 = normal, 1 = large, 2 = extra-large
  const [filterMode, setFilterMode] = useState<'all' | 'remaining' | 'completed'>('all');

  // Sync state whenever favorites or custom adhkar change
  const refreshAdhkarData = () => {
    setFavoriteIds(getFavoriteDhikrIds());
    setCounters(getDhikrCounters());
    setAllAdhkarList(getAllAdhkar());
  };

  const handleToggleFavorite = (id: string) => {
    toggleFavoriteDhikr(id);
    setFavoriteIds(getFavoriteDhikrIds());
  };

  const handleIncrement = (id: string, maxCount: number) => {
    incrementDhikrCount(id, maxCount);
    setCounters(getDhikrCounters());
  };

  const handleResetCount = (id: string) => {
    resetDhikrCount(id);
    setCounters(getDhikrCounters());
  };

  const handleResetAll = () => {
    if (window.confirm('هل تريد إعادة تصفير جميع عدادات الأذكار لهذا اليوم؟')) {
      resetAllCounters();
      setCounters({});
    }
  };

  const handleAddCustom = (dhikrData: {
    title: string;
    text: string;
    count: number;
    fadl?: string;
    category?: 'morning' | 'evening' | 'after_prayer' | 'custom';
  }) => {
    addCustomDhikr(dhikrData);
    refreshAdhkarData();
    // Switch to favorites tab to immediately show the newly added dhikr
    setActiveTab('favorites');
  };

  const handleDeleteCustom = (id: string) => {
    deleteCustomDhikr(id);
    refreshAdhkarData();
  };

  // Filter Adhkar list according to tab, search query, and completion status
  const currentTabAdhkar = useMemo(() => {
    let list: DhikrItem[] = [];

    if (activeTab === 'favorites') {
      list = allAdhkarList.filter((item) => favoriteIds.includes(item.id));
    } else {
      list = allAdhkarList.filter((item) => item.category === activeTab);
    }

    // Apply search query
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      list = list.filter((item) => 
        item.text.toLowerCase().includes(q) || 
        item.title.toLowerCase().includes(q) ||
        (item.fadl && item.fadl.toLowerCase().includes(q))
      );
    }

    // Apply completion filter
    if (filterMode === 'remaining') {
      list = list.filter((item) => (counters[item.id] || 0) < item.count);
    } else if (filterMode === 'completed') {
      list = list.filter((item) => (counters[item.id] || 0) >= item.count);
    }

    return list;
  }, [activeTab, allAdhkarList, favoriteIds, searchQuery, counters, filterMode]);

  // Tab stats for progress calculation
  const tabAdhkarAll = useMemo(() => {
    if (activeTab === 'favorites') {
      return allAdhkarList.filter((item) => favoriteIds.includes(item.id));
    }
    return allAdhkarList.filter((item) => item.category === activeTab);
  }, [activeTab, allAdhkarList, favoriteIds]);

  const completedInCurrentTab = useMemo(() => {
    return tabAdhkarAll.filter((item) => (counters[item.id] || 0) >= item.count).length;
  }, [tabAdhkarAll, counters]);

  const completionPercentage = tabAdhkarAll.length > 0 
    ? Math.round((completedInCurrentTab / tabAdhkarAll.length) * 100) 
    : 0;

  // Font size class mapping
  const fontSizeClasses = [
    'text-lg sm:text-xl',       // 0: normal
    'text-xl sm:text-2xl',       // 1: large (default)
    'text-2xl sm:text-3xl',      // 2: extra-large
  ];

  return (
    <section className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
      
      {/* Top Navigation & Title Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-gradient-to-r from-emerald-900 via-emerald-850 to-teal-950 text-white rounded-3xl p-6 shadow-lg border border-emerald-700/40 relative overflow-hidden">
        
        {/* Subtle geometric watermark */}
        <div className="absolute left-[-20px] top-[-30px] opacity-10 pointer-events-none">
          <Sparkles className="w-56 h-56 text-white" />
        </div>

        <div className="space-y-1.5 z-10">
          <div className="flex items-center gap-2">
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-700/70 text-emerald-200 border border-emerald-600/50 font-medium">
              حصن المسلم والذكر الحكيم
            </span>
            {onBackToQuran && (
              <button
                type="button"
                onClick={onBackToQuran}
                className="text-xs text-emerald-200 hover:text-white flex items-center gap-1 underline underline-offset-4"
              >
                <span>العودة لصفحة المصحف</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <h1 className="font-amiri text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
            الأذكار اليومية المأثورة
          </h1>
          <p className="text-xs sm:text-sm text-emerald-105 font-amiri text-emerald-100/90 leading-relaxed max-w-xl">
            «مَثَلُ الَّذِي يَذْكُرُ رَبَّهُ وَالَّذِي لا يَذْكُرُ رَبَّهُ مَثَلُ الحَيِّ وَالمَيِّتِ» — صحيح البخاري
          </p>
        </div>

        {/* Action Button: Add Custom Dhikr */}
        <div className="flex items-center gap-2 z-10 shrink-0">
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة ذكر للمفضلة</span>
          </button>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
        {/* Morning */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('morning');
            setFilterMode('all');
          }}
          className={`flex items-center justify-center gap-2 p-3 sm:p-3.5 rounded-2xl font-bold text-xs sm:text-sm border transition-all duration-200 ${
            activeTab === 'morning'
              ? 'bg-amber-500 text-stone-950 border-amber-600 shadow-md ring-2 ring-amber-400/40'
              : 'bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-800 hover:bg-stone-50 dark:hover:bg-stone-850'
          }`}
        >
          <Sun className={`w-4 h-4 ${activeTab === 'morning' ? 'text-stone-950' : 'text-amber-500'}`} />
          <span>أذكار الصباح</span>
        </button>

        {/* Evening */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('evening');
            setFilterMode('all');
          }}
          className={`flex items-center justify-center gap-2 p-3 sm:p-3.5 rounded-2xl font-bold text-xs sm:text-sm border transition-all duration-200 ${
            activeTab === 'evening'
              ? 'bg-indigo-700 text-white border-indigo-800 shadow-md ring-2 ring-indigo-400/40'
              : 'bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-800 hover:bg-stone-50 dark:hover:bg-stone-850'
          }`}
        >
          <Moon className={`w-4 h-4 ${activeTab === 'evening' ? 'text-white' : 'text-indigo-500'}`} />
          <span>أذكار المساء</span>
        </button>

        {/* After Prayer */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('after_prayer');
            setFilterMode('all');
          }}
          className={`flex items-center justify-center gap-2 p-3 sm:p-3.5 rounded-2xl font-bold text-xs sm:text-sm border transition-all duration-200 ${
            activeTab === 'after_prayer'
              ? 'bg-emerald-700 text-white border-emerald-800 shadow-md ring-2 ring-emerald-400/40'
              : 'bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-800 hover:bg-stone-50 dark:hover:bg-stone-850'
          }`}
        >
          <Compass className={`w-4 h-4 ${activeTab === 'after_prayer' ? 'text-white' : 'text-emerald-600'}`} />
          <span>بعد الصلاة</span>
        </button>

        {/* Favorites */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('favorites');
            setFilterMode('all');
          }}
          className={`flex items-center justify-center gap-2 p-3 sm:p-3.5 rounded-2xl font-bold text-xs sm:text-sm border transition-all duration-200 relative ${
            activeTab === 'favorites'
              ? 'bg-rose-700 text-white border-rose-800 shadow-md ring-2 ring-rose-400/40'
              : 'bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-800 hover:bg-stone-50 dark:hover:bg-stone-850'
          }`}
        >
          <Heart className={`w-4 h-4 ${activeTab === 'favorites' ? 'fill-white text-white' : 'text-rose-500'}`} />
          <span>الأذكار المفضلة</span>
          {favoriteIds.length > 0 && (
            <span className={`text-[11px] font-extrabold px-2 py-0.2 rounded-full ${
              activeTab === 'favorites' 
                ? 'bg-white text-rose-800' 
                : 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
            }`}>
              {favoriteIds.length}
            </span>
          )}
        </button>
      </div>

      {/* Progress & Quick Controls Bar */}
      <div className="bg-white dark:bg-stone-900 rounded-2xl p-4 sm:p-5 border border-stone-200 dark:border-stone-800 shadow-xs space-y-4">
        
        {/* Progress in current tab */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs sm:text-sm">
            <span className="font-bold text-stone-800 dark:text-stone-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>إنجاز الأذكار المكتملة:</span>
              <span className="text-emerald-700 dark:text-emerald-400 font-extrabold font-mono">
                {completedInCurrentTab} / {tabAdhkarAll.length}
              </span>
            </span>
            <span className="font-semibold text-stone-500 dark:text-stone-400">
              {completionPercentage}%
            </span>
          </div>

          <div className="w-full bg-stone-100 dark:bg-stone-800 h-2.5 rounded-full overflow-hidden">
            <div 
              className="bg-emerald-600 dark:bg-emerald-500 h-full rounded-full transition-all duration-500 ease-out"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
        </div>

        {/* Search, Font Controls, and Filters */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2 border-t border-stone-100 dark:border-stone-800/80">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-stone-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث في نصوص الأذكار وفضائلها..."
              className="w-full pl-9 pr-10 py-2 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-xs sm:text-sm placeholder-stone-400 text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-700"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 left-0 pl-3 flex items-center text-stone-400 hover:text-stone-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Controls: Filter (All/Remaining/Done) + Font Size + Reset Session */}
          <div className="flex items-center gap-2 flex-wrap justify-between sm:justify-end">
            
            {/* Filter Mode */}
            <div className="flex items-center gap-1 bg-stone-100 dark:bg-stone-800 p-1 rounded-xl border border-stone-200 dark:border-stone-700">
              <button
                type="button"
                onClick={() => setFilterMode('all')}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                  filterMode === 'all'
                    ? 'bg-white dark:bg-stone-700 text-emerald-800 dark:text-emerald-300 shadow-xs'
                    : 'text-stone-600 dark:text-stone-400'
                }`}
              >
                الكل
              </button>
              <button
                type="button"
                onClick={() => setFilterMode('remaining')}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                  filterMode === 'remaining'
                    ? 'bg-white dark:bg-stone-700 text-emerald-800 dark:text-emerald-300 shadow-xs'
                    : 'text-stone-600 dark:text-stone-400'
                }`}
              >
                المتبقي
              </button>
              <button
                type="button"
                onClick={() => setFilterMode('completed')}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                  filterMode === 'completed'
                    ? 'bg-white dark:bg-stone-700 text-emerald-800 dark:text-emerald-300 shadow-xs'
                    : 'text-stone-600 dark:text-stone-400'
                }`}
              >
                المكتمل
              </button>
            </div>

            {/* Font Size Scaling */}
            <div className="flex items-center gap-1 bg-stone-100 dark:bg-stone-800 px-2 py-1 rounded-xl border border-stone-200 dark:border-stone-700">
              <span className="text-[11px] text-stone-500 ml-1">الخط:</span>
              <button
                type="button"
                onClick={() => setFontSizeLevel((prev) => Math.max(0, prev - 1))}
                disabled={fontSizeLevel === 0}
                className="w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold text-stone-700 dark:text-stone-300 disabled:opacity-40 hover:bg-stone-200 dark:hover:bg-stone-700"
                title="تصغير حجم الخط"
              >
                -A
              </button>
              <button
                type="button"
                onClick={() => setFontSizeLevel((prev) => Math.min(2, prev + 1))}
                disabled={fontSizeLevel === 2}
                className="w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold text-stone-700 dark:text-stone-300 disabled:opacity-40 hover:bg-stone-200 dark:hover:bg-stone-700"
                title="تكبير حجم الخط"
              >
                +A
              </button>
            </div>

            {/* Reset All Counters */}
            <button
              type="button"
              onClick={handleResetAll}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-rose-600 hover:bg-stone-100 dark:hover:bg-stone-800 text-xs font-medium transition-colors"
              title="تصفير جميع عدادات اليوم"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>تصفير العداد</span>
            </button>

          </div>

        </div>

      </div>

      {/* Adhkar Cards List */}
      <div className="space-y-4">
        {currentTabAdhkar.length === 0 ? (
          <div className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 p-12 text-center space-y-4">
            {activeTab === 'favorites' ? (
              <>
                <div className="w-16 h-16 rounded-full bg-rose-50 dark:bg-rose-950/50 text-rose-500 flex items-center justify-center mx-auto">
                  <Heart className="w-8 h-8 fill-rose-500" />
                </div>
                <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100">
                  لا توجد أذكار في قائمة المفضلة حالياً
                </h3>
                <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 max-w-md mx-auto">
                  يمكنك إضافة أي ذكر إلى المفضلة بسهولة بالضغط على رمز القلب ❤️ في بطاقة أي ذكر، أو إضافة ذكر مخصص جديد بكلماتك ودعائك.
                </p>
                <div className="pt-2 flex items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => setActiveTab('morning')}
                    className="px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold transition-colors"
                  >
                    تصفح أذكار الصباح
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(true)}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-bold transition-colors"
                  >
                    + إضافة ذكر مخصص
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="w-16 h-16 rounded-full bg-stone-100 dark:bg-stone-800 text-stone-400 flex items-center justify-center mx-auto">
                  <Search className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100">
                  لم يتم العثور على أذكار مطابقة
                </h3>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  جرّب تغيير كلمات البحث أو إعادة ضبط خيارات التصفية.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery('');
                    setFilterMode('all');
                  }}
                  className="px-4 py-2 rounded-xl bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300 text-xs font-semibold"
                >
                  إعادة ضبط التصفية
                </button>
              </>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {currentTabAdhkar.map((dhikr) => (
              <DhikrCard
                key={dhikr.id}
                dhikr={dhikr}
                isFavorite={favoriteIds.includes(dhikr.id)}
                onToggleFavorite={handleToggleFavorite}
                currentCount={counters[dhikr.id] || 0}
                onIncrement={handleIncrement}
                onReset={handleResetCount}
                onDeleteCustom={handleDeleteCustom}
                fontSizeClass={fontSizeClasses[fontSizeLevel]}
              />
            ))}
          </div>
        )}
      </div>

      {/* Add Custom Dhikr Modal */}
      <AddCustomDhikrModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddDhikr={handleAddCustom}
      />
    </section>
  );
};
