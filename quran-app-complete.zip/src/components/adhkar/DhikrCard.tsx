import React, { useState } from 'react';
import { 
  Heart, 
  Copy, 
  Check, 
  RotateCcw, 
  Share2, 
  Sparkles, 
  Trash2, 
  CheckCircle2,
  BookOpen
} from 'lucide-react';
import { DhikrItem } from '../../data/adhkar';

interface DhikrCardProps {
  dhikr: DhikrItem;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  currentCount: number;
  onIncrement: (id: string, maxCount: number) => void;
  onReset: (id: string) => void;
  onDeleteCustom?: (id: string) => void;
  fontSizeClass?: string;
}

export const DhikrCard: React.FC<DhikrCardProps> = ({
  dhikr,
  isFavorite,
  onToggleFavorite,
  currentCount,
  onIncrement,
  onReset,
  onDeleteCustom,
  fontSizeClass = 'text-xl sm:text-2xl',
}) => {
  const [copied, setCopied] = useState(false);
  const [justCompleted, setJustCompleted] = useState(false);

  const isCompleted = currentCount >= dhikr.count;
  const progressPercent = Math.min(100, Math.round((currentCount / dhikr.count) * 100));

  const handleCopy = async () => {
    try {
      const fullText = `${dhikr.title ? `【 ${dhikr.title} 】\n` : ''}${dhikr.text}\n\n(التكرار: ${dhikr.count} مرات)${dhikr.fadl ? `\nالفضل: ${dhikr.fadl}` : ''}${dhikr.reference ? `\nالمصدر: ${dhikr.reference}` : ''}`;
      await navigator.clipboard.writeText(fullText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const handleShare = async () => {
    const textToShare = `${dhikr.title ? `【 ${dhikr.title} 】\n` : ''}${dhikr.text}\n\n(التكرار: ${dhikr.count} مرات)${dhikr.fadl ? `\nالفضل: ${dhikr.fadl}` : ''}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: dhikr.title || 'ذكر مبارك',
          text: textToShare,
        });
      } catch {
        handleCopy();
      }
    } else {
      handleCopy();
    }
  };

  const handleClickCounter = () => {
    if (navigator.vibrate) {
      navigator.vibrate(35);
    }
    const nextCount = currentCount + 1;
    onIncrement(dhikr.id, dhikr.count);
    if (nextCount === dhikr.count) {
      setJustCompleted(true);
      if (navigator.vibrate) {
        navigator.vibrate([50, 50, 80]);
      }
      setTimeout(() => setJustCompleted(false), 2500);
    }
  };

  return (
    <article 
      className={`relative rounded-2xl border transition-all duration-200 overflow-hidden shadow-xs ${
        isCompleted 
          ? 'bg-emerald-50/70 dark:bg-emerald-950/20 border-emerald-300/80 dark:border-emerald-800/80' 
          : 'bg-white dark:bg-stone-900 border-stone-200/90 dark:border-stone-800 hover:border-emerald-300 dark:hover:border-emerald-700/50'
      }`}
    >
      {/* Top Completion Progress Ribbon */}
      <div className="w-full bg-stone-100 dark:bg-stone-800/80 h-1.5">
        <div 
          className={`h-full transition-all duration-300 ${
            isCompleted 
              ? 'bg-emerald-600 dark:bg-emerald-400' 
              : 'bg-emerald-700/70 dark:bg-emerald-500'
          }`}
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      <div className="p-4 sm:p-6 space-y-4">
        {/* Card Header */}
        <div className="flex items-center justify-between gap-3 border-b border-stone-100 dark:border-stone-800/70 pb-3">
          
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs px-2.5 py-1 rounded-full font-medium bg-emerald-100/80 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60">
              {dhikr.categoryName}
            </span>
            {dhikr.title && (
              <h3 className="font-semibold text-sm sm:text-base text-stone-900 dark:text-stone-100">
                {dhikr.title}
              </h3>
            )}
            {dhikr.isCustom && (
              <span className="text-[11px] px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 font-medium">
                مخصص
              </span>
            )}
          </div>

          {/* Action Icons */}
          <div className="flex items-center gap-1 shrink-0">
            {/* Favorite Button */}
            <button
              type="button"
              onClick={() => onToggleFavorite(dhikr.id)}
              className={`p-2 rounded-xl transition-all duration-150 active:scale-90 ${
                isFavorite 
                  ? 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100' 
                  : 'text-stone-400 hover:text-rose-600 hover:bg-stone-100 dark:hover:bg-stone-800'
              }`}
              title={isFavorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
              aria-label={isFavorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
            >
              <Heart 
                className={`w-5 h-5 transition-transform duration-200 ${
                  isFavorite ? 'fill-rose-500 text-rose-500 scale-110' : 'text-stone-400'
                }`} 
              />
            </button>

            {/* Copy Button */}
            <button
              type="button"
              onClick={handleCopy}
              className="p-2 rounded-xl text-stone-400 hover:text-emerald-700 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
              title="نسخ نص الذكر"
              aria-label="نسخ نص الذكر"
            >
              {copied ? (
                <Check className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              ) : (
                <Copy className="w-5 h-5" />
              )}
            </button>

            {/* Share Button */}
            <button
              type="button"
              onClick={handleShare}
              className="p-2 rounded-xl text-stone-400 hover:text-emerald-700 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
              title="مشاركة الذكر"
              aria-label="مشاركة الذكر"
            >
              <Share2 className="w-5 h-5" />
            </button>

            {/* Delete button if custom */}
            {dhikr.isCustom && onDeleteCustom && (
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('هل تريد حذف هذا الذكر المخصص؟')) {
                    onDeleteCustom(dhikr.id);
                  }
                }}
                className="p-2 rounded-xl text-stone-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                title="حذف الذكر المخصص"
                aria-label="حذف الذكر المخصص"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Dhikr Arabic Text */}
        <div className="py-2 select-text">
          <p 
            className={`font-amiri text-stone-900 dark:text-stone-100 leading-loose text-justify ${fontSizeClass}`}
            style={{ textUnderlineOffset: '6px' }}
          >
            {dhikr.text}
          </p>
        </div>

        {/* Virtue & Hadith Reference */}
        {(dhikr.fadl || dhikr.reference) && (
          <div className="rounded-xl bg-stone-50 dark:bg-stone-800/50 p-3 sm:p-3.5 border border-stone-200/70 dark:border-stone-800 space-y-1.5 text-xs text-stone-600 dark:text-stone-300">
            {dhikr.fadl && (
              <div className="flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  <strong className="text-amber-800 dark:text-amber-300 font-semibold">فضل الذكر: </strong>
                  {dhikr.fadl}
                </p>
              </div>
            )}
            {dhikr.reference && (
              <div className="flex items-center gap-2 text-stone-500 dark:text-stone-400 text-[11px] pt-1">
                <BookOpen className="w-3.5 h-3.5 shrink-0" />
                <span>{dhikr.reference}</span>
              </div>
            )}
          </div>
        )}

        {/* Counter / Interactive Tasbeeh Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
          
          {/* Target repetitions badge */}
          <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400">
            <span className="font-medium">التكرار المطلوب:</span>
            <span className="px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-800 font-bold text-stone-800 dark:text-stone-200">
              {dhikr.count === 1 ? 'مرة واحدة' : 
               dhikr.count === 2 ? 'مرتان' : 
               dhikr.count <= 10 ? `${dhikr.count} مرات` : 
               `${dhikr.count} مرة`}
            </span>
          </div>

          {/* Controls: Reset + Big Counter Button */}
          <div className="flex items-center gap-2 justify-end">
            {/* Reset Button */}
            {currentCount > 0 && (
              <button
                type="button"
                onClick={() => onReset(dhikr.id)}
                className="p-2.5 rounded-xl border border-stone-200 dark:border-stone-700/80 text-stone-500 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
                title="إعادة ضبط العداد"
                aria-label="إعادة ضبط العداد"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}

            {/* Tap Counter Button */}
            <button
              type="button"
              onClick={handleClickCounter}
              className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-3 px-6 py-2.5 rounded-xl font-bold text-sm transition-all duration-200 active:scale-95 shadow-xs select-none ${
                isCompleted
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white ring-2 ring-emerald-400/30'
                  : 'bg-emerald-800 hover:bg-emerald-900 text-white dark:bg-emerald-700 dark:hover:bg-emerald-600 shadow-md'
              }`}
            >
              {isCompleted ? (
                <>
                  <CheckCircle2 className="w-5 h-5 text-emerald-200 animate-bounce" />
                  <span>تم بحمد الله ({currentCount}/{dhikr.count})</span>
                </>
              ) : (
                <>
                  <span className="text-base font-extrabold font-mono tracking-wider">
                    {currentCount} / {dhikr.count}
                  </span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-white/20">
                    اضغط للتسبيح
                  </span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Completion Toast notification banner */}
        {justCompleted && (
          <div className="rounded-xl p-2.5 bg-emerald-100 dark:bg-emerald-900/60 border border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200 text-center text-xs font-bold animate-fadeIn">
            تقبّل الله منك! اكتمل عدد التكرار لهذا الذكر المبارك 🌿
          </div>
        )}

      </div>
    </article>
  );
};
