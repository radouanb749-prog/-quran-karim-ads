import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  Clock, 
  Sparkles, 
  Check, 
  Bookmark, 
  RotateCcw,
  BookOpen,
  ArrowRight
} from 'lucide-react';
import { 
  KhatmahPlan, 
  TOTAL_QURAN_PAGES, 
  createDefaultPlan, 
  resetKhatmahPlan, 
  formatDateISO, 
  addDaysToDate 
} from '../../services/khatmahService';

interface CreateKhatmahModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: KhatmahPlan;
  onPlanCreated: (plan: KhatmahPlan) => void;
}

const PRESET_DURATIONS = [
  { days: 30, title: 'ختمة الشهر (٣٠ يوماً)', badge: 'الأكثر شيوعاً', pagesPerDay: 20, desc: 'جزء واحد يومياً (حوالي ٢٠ صفحة)' },
  { days: 15, title: 'ختمة النصف شهر (١٥ يوماً)', badge: 'سريعة ومكثفة', pagesPerDay: 40, desc: 'جزآن يومياً (حوالي ٤٠ صفحة)' },
  { days: 60, title: 'ختمة الشهرين (٦٠ يوماً)', badge: 'ميسرة وهادئة', pagesPerDay: 10, desc: 'نصف جزء يومياً (حوالي ١٠ صفحات)' },
  { days: 10, title: 'ختمة العشر الأواخر (١٠ أيام)', badge: 'موسم الطاعات', pagesPerDay: 60, desc: '٣ أجزاء يومياً (حوالي ٦٠ صفحة)' },
  { days: 7, title: 'ختمة أسبوعية (٧ أيام)', badge: 'أجر عظيم', pagesPerDay: 86, desc: 'أكثر من ٤ أجزاء يومياً' },
  { days: 90, title: 'ختمة الثلاثة أشهر (٩٠ يوماً)', badge: 'تدبر متأنٍ', pagesPerDay: 7, desc: 'حوالي ٧ صفحات يومياً' },
];

export const CreateKhatmahModal: React.FC<CreateKhatmahModalProps> = ({
  isOpen,
  onClose,
  currentPlan,
  onPlanCreated,
}) => {
  const [selectedDuration, setSelectedDuration] = useState<number>(currentPlan.durationDays || 30);
  const [customDays, setCustomDays] = useState<string>('');
  const [isCustomMode, setIsCustomMode] = useState<boolean>(
    !PRESET_DURATIONS.some((p) => p.days === currentPlan.durationDays)
  );
  const [title, setTitle] = useState<string>(currentPlan.title || 'ختمتي الحالية');
  const [startPage, setStartPage] = useState<number>(currentPlan.startPage || 1);

  if (!isOpen) return null;

  const effectiveDuration = isCustomMode 
    ? Math.max(1, parseInt(customDays) || 30) 
    : selectedDuration;

  const pagesToRead = TOTAL_QURAN_PAGES - startPage + 1;
  const calculatedDailyPages = Math.ceil(pagesToRead / effectiveDuration);
  const targetEndDate = addDaysToDate(formatDateISO(new Date()), effectiveDuration);

  const handleSelectPreset = (days: number, presetTitle: string) => {
    setSelectedDuration(days);
    setIsCustomMode(false);
    setTitle(presetTitle);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newPlan = resetKhatmahPlan(
      effectiveDuration, 
      title.trim() || `ختمة (${effectiveDuration} يوماً)`, 
      startPage
    );
    onPlanCreated(newPlan);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs" dir="rtl">
      <div 
        className="w-full max-w-xl bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
      >
        {/* Modal Header */}
        <div className="p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between bg-stone-50/80 dark:bg-stone-950/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950/80 flex items-center justify-center text-amber-700 dark:text-amber-400 shadow-xs">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100">
                إعداد خطة الختمة القرآنية
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                حدد المدة المناسبة لحساب وردك اليومي ومتابعة تقدمك بسهولة
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form Content */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto space-y-5">
          
          {/* Plan Title */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300">
              عنوان الختمة أو المناسبة
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: ختمة شهر رمضان، ختمة التوبة، ختمتي اليومية..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-sm text-stone-900 dark:text-stone-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-700"
            />
          </div>

          {/* Preset Durations */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-stone-700 dark:text-stone-300">
              اختر مدة الختمة
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {PRESET_DURATIONS.map((preset) => {
                const isSelected = !isCustomMode && selectedDuration === preset.days;
                return (
                  <button
                    key={preset.days}
                    type="button"
                    onClick={() => handleSelectPreset(preset.days, preset.title)}
                    className={`p-3 rounded-2xl border text-right transition-all flex flex-col justify-between gap-1 relative ${
                      isSelected
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 dark:border-emerald-600 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'bg-white dark:bg-stone-850 border-stone-200 dark:border-stone-700 hover:border-emerald-300'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-xs sm:text-sm text-stone-900 dark:text-stone-100">
                        {preset.title}
                      </span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                        isSelected 
                          ? 'bg-emerald-600 text-white' 
                          : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300'
                      }`}>
                        {preset.badge}
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-500 dark:text-stone-400">
                      {preset.desc}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Duration Input Option */}
          <div className="p-3.5 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-700 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-stone-800 dark:text-stone-200 flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isCustomMode}
                  onChange={(e) => {
                    setIsCustomMode(e.target.checked);
                    if (e.target.checked && !customDays) {
                      setCustomDays(selectedDuration.toString());
                    }
                  }}
                  className="rounded text-emerald-700 focus:ring-emerald-700"
                />
                <span>تحديد عدد أيام مخصص (مدة حرة)</span>
              </label>
              {isCustomMode && (
                <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold">
                  مفعل
                </span>
              )}
            </div>

            {isCustomMode && (
              <div className="flex items-center gap-3 pt-1">
                <input
                  type="number"
                  min={1}
                  max={365}
                  value={customDays}
                  onChange={(e) => setCustomDays(e.target.value)}
                  placeholder="مثال: 45 يوماً"
                  className="w-32 px-3 py-2 rounded-xl bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-600 text-center text-sm font-bold text-stone-900 dark:text-stone-100"
                />
                <span className="text-xs text-stone-600 dark:text-stone-400">
                  يوماً لإنهاء تلاوة المصحف الشريف
                </span>
              </div>
            )}
          </div>

          {/* Start Page Option */}
          <div className="flex items-center justify-between gap-3 p-3.5 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-700">
            <div>
              <label className="block text-xs font-bold text-stone-800 dark:text-stone-200">
                صفحة البداية
              </label>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">
                إذا كنت بدأت القراءة مسبقاً وتريد استئناف الخطة من صفحتك الحالية
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-stone-500">ص</span>
              <input
                type="number"
                min={1}
                max={603}
                value={startPage}
                onChange={(e) => setStartPage(Math.max(1, Math.min(604, parseInt(e.target.value) || 1)))}
                className="w-20 px-2.5 py-1.5 rounded-xl bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-600 text-center text-xs font-bold text-stone-900 dark:text-stone-100"
              />
            </div>
          </div>

          {/* Dynamic Summary Card */}
          <div className="rounded-2xl p-4 bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-950 text-white space-y-3 shadow-md">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>ملخص وحساب الخطة المقترحة</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1 text-center">
              <div className="bg-white/10 rounded-xl p-2.5">
                <span className="text-[10px] text-emerald-200 block">الورد اليومي المطلوب</span>
                <span className="text-lg font-bold text-amber-300 font-mono">
                  {calculatedDailyPages}
                </span>
                <span className="text-[10px] text-emerald-100 mr-1">صفحة / يوم</span>
              </div>

              <div className="bg-white/10 rounded-xl p-2.5">
                <span className="text-[10px] text-emerald-200 block">مدة الخطة</span>
                <span className="text-lg font-bold text-white font-mono">
                  {effectiveDuration}
                </span>
                <span className="text-[10px] text-emerald-100 mr-1">يوماً</span>
              </div>

              <div className="bg-white/10 rounded-xl p-2.5 col-span-2 sm:col-span-1">
                <span className="text-[10px] text-emerald-200 block">موعد الختم المستهدف</span>
                <span className="text-xs font-bold text-white mt-1 block font-mono">
                  {targetEndDate}
                </span>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-2 flex items-center justify-end gap-2.5 border-t border-stone-100 dark:border-stone-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>اعتماد وبدء الخطة</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
