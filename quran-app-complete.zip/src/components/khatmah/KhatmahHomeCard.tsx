import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  BookOpen, 
  ArrowLeft, 
  Check, 
  Sparkles, 
  ChevronLeft,
  Flame,
  Award,
  Headphones
} from 'lucide-react';
import { 
  getActiveKhatmahPlan, 
  getKhatmahStats, 
  getPrimarySurahForPage, 
  subscribeToKhatmahChange,
  KhatmahPlan,
  KhatmahStats,
  DayWardInfo
} from '../../services/khatmahService';
import { Surah, SURAHS } from '../../data/surahs';

interface KhatmahHomeCardProps {
  onOpenKhatmahSection: () => void;
  onReadWard: (surah: Surah, verseNumber?: number) => void;
  onListenWard?: (ward: DayWardInfo) => void;
}

export const KhatmahHomeCard: React.FC<KhatmahHomeCardProps> = ({
  onOpenKhatmahSection,
  onReadWard,
  onListenWard,
}) => {
  const [plan, setPlan] = useState<KhatmahPlan>(() => getActiveKhatmahPlan());
  const [stats, setStats] = useState<KhatmahStats>(() => getKhatmahStats(getActiveKhatmahPlan()));

  useEffect(() => {
    const sync = () => {
      const current = getActiveKhatmahPlan();
      setPlan(current);
      setStats(getKhatmahStats(current));
    };
    sync();
    const unsubscribe = subscribeToKhatmahChange(sync);
    return () => unsubscribe();
  }, []);

  const handleStartTodayWard = () => {
    const primarySurah = getPrimarySurahForPage(stats.todayWard.startPage);
    onReadWard(primarySurah, 1);
  };

  return (
    <article className="bg-white dark:bg-stone-900 rounded-3xl p-5 sm:p-6 border border-stone-200 dark:border-stone-800 shadow-xs relative overflow-hidden transition-all hover:border-emerald-300 dark:hover:border-emerald-800/80">
      
      {/* Background soft gradient flourish */}
      <div className="absolute left-0 top-0 w-32 h-32 bg-amber-400/5 rounded-full blur-2xl pointer-events-none" />

      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        
        {/* Left Side: Plan Info & Ward Details */}
        <div className="space-y-2.5 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/70 text-amber-900 dark:text-amber-300 font-bold border border-amber-200 dark:border-amber-800 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              <span>خطة الختمة القرآنية</span>
            </span>

            <span className="text-xs px-2 py-0.5 rounded-full bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 font-medium">
              اليوم {stats.currentDay.toLocaleString('ar-EG')} من {stats.totalDays.toLocaleString('ar-EG')} يوماً
            </span>

            {stats.todayWard.isCompleted && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold">
                ورد اليوم منجز ✓
              </span>
            )}
          </div>

          <div>
            <h3 className="font-bold text-base sm:text-lg text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <span>ورد اليوم:</span>
              <span className="text-emerald-800 dark:text-emerald-300 font-mono">
                ص {stats.todayWard.startPage.toLocaleString('ar-EG')} — ص {stats.todayWard.endPage.toLocaleString('ar-EG')}
              </span>
              <span className="text-xs text-stone-400 font-normal">
                ({stats.todayWard.pagesCount.toLocaleString('ar-EG')} صفحة • جزء {stats.todayWard.approxJuz.toLocaleString('ar-EG')})
              </span>
            </h3>

            <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
              {stats.todayWard.surahs.map((s) => `سورة ${s.name}`).join('، ')}
            </p>
          </div>

          {/* Progress Bar */}
          <div className="space-y-1 pt-0.5 max-w-md">
            <div className="flex items-center justify-between text-[11px] text-stone-500 dark:text-stone-400">
              <span>إنجاز الختمة الكلي</span>
              <span className="font-bold font-mono text-emerald-700 dark:text-emerald-400">
                {stats.completionPercentage}% ({stats.readPages.toLocaleString('ar-EG')} / ٦٠٤ ص)
              </span>
            </div>
            <div className="w-full bg-stone-100 dark:bg-stone-800 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-emerald-600 dark:bg-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${stats.completionPercentage}%` }}
              />
            </div>
          </div>
        </div>

        {/* Right Side: Action Buttons */}
        <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-stone-100 dark:border-stone-800">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={handleStartTodayWard}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white dark:bg-emerald-700 dark:hover:bg-emerald-600 text-xs sm:text-sm font-bold shadow-md transition-all active:scale-95"
            >
              <BookOpen className="w-4 h-4" />
              <span>تلاوة ورد اليوم</span>
            </button>

            {onListenWard && (
              <button
                type="button"
                onClick={() => onListenWard(stats.todayWard)}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/35 text-amber-900 dark:text-amber-200 text-xs sm:text-sm font-bold shadow-xs transition-all active:scale-95"
                title="الاستماع لسور ورد اليوم تلقائياً واحداً تلو الآخر"
              >
                <Headphones className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <span>استماع للورد</span>
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={onOpenKhatmahSection}
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs text-emerald-800 dark:text-emerald-300 font-bold hover:underline"
          >
            <span>خطة الختمة والإحصائيات</span>
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

      </div>

    </article>
  );
};
