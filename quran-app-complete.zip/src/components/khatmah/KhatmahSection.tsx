import React, { useState, useEffect, useMemo } from 'react';
import { 
  Calendar, 
  Clock, 
  CheckCircle2, 
  Sparkles, 
  BookOpen, 
  ArrowRight, 
  Settings, 
  RotateCcw, 
  TrendingUp, 
  Award, 
  Check, 
  Heart, 
  Flame, 
  Layers, 
  ChevronRight,
  ExternalLink,
  BookMarked,
  Headphones
} from 'lucide-react';
import { 
  KhatmahPlan, 
  KhatmahStats, 
  DayWardInfo, 
  TOTAL_QURAN_PAGES, 
  TOTAL_QURAN_JUZ, 
  TOTAL_QURAN_SURAHS,
  getActiveKhatmahPlan, 
  getKhatmahStats, 
  calculateDayWard, 
  toggleDayCompleted, 
  getPrimarySurahForPage, 
  subscribeToKhatmahChange 
} from '../../services/khatmahService';
import { CreateKhatmahModal } from './CreateKhatmahModal';
import { SURAHS, Surah } from '../../data/surahs';
import { getFavoriteVerses } from '../../services/favoriteVersesService';
import { getDhikrCounters } from '../../services/adhkarService';

interface KhatmahSectionProps {
  onBackToQuran?: () => void;
  onNavigateToSurahPage?: (surah: Surah, verseNumber?: number) => void;
  onOpenFavoriteVerses?: () => void;
  onListenWard?: (ward: DayWardInfo, initialSurahNumber?: number) => void;
}

export const KhatmahSection: React.FC<KhatmahSectionProps> = ({
  onBackToQuran,
  onNavigateToSurahPage,
  onOpenFavoriteVerses,
  onListenWard,
}) => {
  const [plan, setPlan] = useState<KhatmahPlan>(() => getActiveKhatmahPlan());
  const [stats, setStats] = useState<KhatmahStats>(() => getKhatmahStats(getActiveKhatmahPlan()));
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'schedule' | 'stats'>('schedule');
  const [scheduleFilter, setScheduleFilter] = useState<'all' | 'remaining' | 'completed'>('all');
  const [celebrationToast, setCelebrationToast] = useState<string | null>(null);

  // Sync state when Khatmah changes
  useEffect(() => {
    const sync = () => {
      const current = getActiveKhatmahPlan();
      setPlan(current);
      setStats(getKhatmahStats(current));
    };
    sync();
    const unsubscribe = subscribeToKhatmahChange(sync);
    return () => unsubscribe();
  }, []);

  // Additional app-wide stats
  const favoriteVersesCount = useMemo(() => getFavoriteVerses().length, []);
  const completedAdhkarCount = useMemo(() => {
    const counters = getDhikrCounters();
    return Object.values(counters).filter((v) => v > 0).length;
  }, []);

  const handleToggleDay = (dayNum: number) => {
    if (navigator.vibrate) {
      navigator.vibrate(30);
    }
    const updatedPlan = toggleDayCompleted(dayNum);
    setPlan({ ...updatedPlan });
    setStats(getKhatmahStats(updatedPlan));

    if (updatedPlan.completedDays[dayNum]) {
      setCelebrationToast(`تقبل الله منك! تم إنجاز ورد اليوم (${dayNum.toLocaleString('ar-EG')}) بنجاح 🌿`);
      setTimeout(() => setCelebrationToast(null), 3000);
    }
  };

  const handleReadDayWard = (ward: DayWardInfo) => {
    const primarySurah = getPrimarySurahForPage(ward.startPage);
    if (onNavigateToSurahPage) {
      // Navigate to reader at primary surah
      onNavigateToSurahPage(primarySurah, 1);
    }
  };

  // Generate full list of days for schedule
  const allDaysSchedule = useMemo(() => {
    const list: DayWardInfo[] = [];
    for (let d = 1; d <= plan.durationDays; d++) {
      list.push(
        calculateDayWard(
          d,
          plan.durationDays,
          plan.startPage,
          plan.endPage,
          plan.completedDays,
          stats.currentDay
        )
      );
    }
    return list;
  }, [plan, stats.currentDay]);

  const filteredDaysSchedule = useMemo(() => {
    if (scheduleFilter === 'completed') {
      return allDaysSchedule.filter((d) => d.isCompleted);
    }
    if (scheduleFilter === 'remaining') {
      return allDaysSchedule.filter((d) => !d.isCompleted);
    }
    return allDaysSchedule;
  }, [allDaysSchedule, scheduleFilter]);

  return (
    <section className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-7" dir="rtl">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-950 text-white rounded-3xl p-6 sm:p-7 shadow-xl border border-emerald-700/40 relative overflow-hidden">
        {/* Ambient watermark */}
        <div className="absolute left-[-20px] top-[-30px] opacity-10 pointer-events-none">
          <BookOpen className="w-64 h-64 text-white" />
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-5 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-400 text-stone-950 font-bold border border-amber-300">
                {plan.title || 'خطة الختمة القرآنية'}
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-800/80 text-emerald-200 border border-emerald-600/50">
                المدة: {plan.durationDays.toLocaleString('ar-EG')} يوماً
              </span>
              {onBackToQuran && (
                <button
                  type="button"
                  onClick={onBackToQuran}
                  className="text-xs text-emerald-200 hover:text-white flex items-center gap-1 underline underline-offset-4 mr-2"
                >
                  <span>العودة للمصحف</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <h1 className="font-amiri text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
              خطة الختمة القرآنية وإحصائيات القراءة
            </h1>

            <p className="text-xs sm:text-sm font-amiri text-emerald-100/90 leading-relaxed max-w-xl">
              «اقْرَءُوا الْقُرْآنَ فَإِنَّهُ يَأْتِي يَوْمَ الْقِيَامَةِ شَفِيعًا لِأَصْحَابِهِ» — صحيح مسلم
            </p>
          </div>

          {/* Plan Settings Button */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm border border-white/20 backdrop-blur-xs transition-all active:scale-95 shadow-xs"
            >
              <Settings className="w-4 h-4 text-amber-300" />
              <span>تعديل الخطة أو البدء من جديد</span>
            </button>
          </div>
        </div>
      </div>

      {/* Toast Notification */}
      {celebrationToast && (
        <div className="p-3 rounded-2xl bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200 text-xs sm:text-sm font-bold text-center animate-in fade-in duration-200 shadow-md">
          {celebrationToast}
        </div>
      )}

      {/* Top 4 Key Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        
        {/* Metric 1: Overall Completion */}
        <div className="bg-white dark:bg-stone-900 rounded-2xl p-4 border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 text-xs">
            <span>نسبة إنجاز الختمة</span>
            <Award className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-bold font-mono text-emerald-950 dark:text-emerald-200">
              {stats.completionPercentage}%
            </span>
            <span className="text-[11px] text-stone-400">
              ({stats.readPages.toLocaleString('ar-EG')} / ٦٠٤ ص)
            </span>
          </div>
          <div className="w-full bg-stone-100 dark:bg-stone-800 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-emerald-600 dark:bg-emerald-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${stats.completionPercentage}%` }}
            />
          </div>
        </div>

        {/* Metric 2: Days Progression */}
        <div className="bg-white dark:bg-stone-900 rounded-2xl p-4 border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 text-xs">
            <span>الأيام والمدة</span>
            <Calendar className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-xl sm:text-2xl font-bold font-mono text-stone-900 dark:text-stone-100">
              اليوم {stats.currentDay.toLocaleString('ar-EG')}
            </span>
            <span className="text-xs text-stone-500">
              من {stats.totalDays.toLocaleString('ar-EG')} يوماً
            </span>
          </div>
          <div className="text-[11px] text-stone-500 dark:text-stone-400 flex items-center justify-between">
            <span>المتبقي: {stats.daysRemaining.toLocaleString('ar-EG')} يوماً</span>
            <span className="font-semibold text-emerald-700 dark:text-emerald-400">
              {stats.completedDaysCount.toLocaleString('ar-EG')} ورد مكتمل
            </span>
          </div>
        </div>

        {/* Metric 3: Pace Status */}
        <div className="bg-white dark:bg-stone-900 rounded-2xl p-4 border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 text-xs">
            <span>الالتزام بالجدول</span>
            <TrendingUp className="w-4 h-4 text-indigo-500" />
          </div>
          <div>
            {stats.paceStatus === 'ahead' ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold text-xs">
                <span>متقدم عن الخطة 🌟</span>
              </span>
            ) : stats.paceStatus === 'behind' ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-bold text-xs">
                <span>متأخر {stats.pagesAheadBehind.toLocaleString('ar-EG')} ص</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 font-bold text-xs">
                <span>ملتزم بالموعد تماماً ✓</span>
              </span>
            )}
          </div>
          <p className="text-[11px] text-stone-400">
            {stats.paceStatus === 'behind' 
              ? 'يمكنك تعويض الصفحات المتبقية في ورد اليوم' 
              : 'ما شاء الله، واصل بهذا الالتزام المبارك'}
          </p>
        </div>

        {/* Metric 4: Estimated Completion */}
        <div className="bg-white dark:bg-stone-900 rounded-2xl p-4 border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col justify-between space-y-2">
          <div className="flex items-center justify-between text-stone-500 dark:text-stone-400 text-xs">
            <span>تاريخ الختم المتوقع</span>
            <Clock className="w-4 h-4 text-rose-500" />
          </div>
          <div>
            <span className="text-sm sm:text-base font-bold font-mono text-stone-900 dark:text-stone-100 block">
              {plan.targetEndDate}
            </span>
            <span className="text-[11px] text-stone-500 dark:text-stone-400">
              المعدل: {Math.ceil(TOTAL_QURAN_PAGES / plan.durationDays).toLocaleString('ar-EG')} صفحة/يوم
            </span>
          </div>
          <div className="text-[11px] text-stone-400">
            المتبقي للقراءة: {stats.pagesRemaining.toLocaleString('ar-EG')} صفحة
          </div>
        </div>

      </div>

      {/* Hero Card: Today's Ward (وردك القرآني لليوم) */}
      <div className="bg-gradient-to-br from-amber-500/10 via-emerald-500/5 to-teal-500/10 rounded-3xl p-5 sm:p-6 border-2 border-amber-300/80 dark:border-amber-600/40 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-200/80 dark:border-amber-800/40 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-stone-950 flex items-center justify-center font-bold font-mono text-lg shadow-md shrink-0">
              {stats.todayWard.dayNumber.toLocaleString('ar-EG')}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-base sm:text-lg text-stone-900 dark:text-stone-100">
                  ورد اليوم ({stats.todayWard.dayNumber.toLocaleString('ar-EG')} من {stats.totalDays.toLocaleString('ar-EG')})
                </h2>
                {stats.todayWard.isCompleted && (
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold border border-emerald-300 dark:border-emerald-800">
                    تمت القراءة بنجاح ✓
                  </span>
                )}
              </div>
              <p className="text-xs text-stone-600 dark:text-stone-400">
                من صفحة <strong className="text-emerald-800 dark:text-emerald-300">{stats.todayWard.startPage.toLocaleString('ar-EG')}</strong> إلى صفحة <strong className="text-emerald-800 dark:text-emerald-300">{stats.todayWard.endPage.toLocaleString('ar-EG')}</strong> • ({stats.todayWard.pagesCount.toLocaleString('ar-EG')} صفحة • حوالي الجزء {stats.todayWard.approxJuz.toLocaleString('ar-EG')})
              </p>
            </div>
          </div>

          {/* Action Buttons: Read Now & Mark Done */}
          <div className="flex items-center gap-2 self-end sm:self-auto flex-wrap">
            <button
              type="button"
              onClick={() => handleToggleDay(stats.todayWard.dayNumber)}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm border transition-all active:scale-95 ${
                stats.todayWard.isCompleted
                  ? 'bg-emerald-100 dark:bg-emerald-950 border-emerald-400 text-emerald-800 dark:text-emerald-200'
                  : 'bg-white dark:bg-stone-850 hover:bg-stone-50 border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-200'
              }`}
            >
              <Check className={`w-4 h-4 ${stats.todayWard.isCompleted ? 'text-emerald-600' : 'text-stone-400'}`} />
              <span>{stats.todayWard.isCompleted ? 'تم إنجاز الورد' : 'تحديد كمكتمل'}</span>
            </button>

            {onListenWard && (
              <button
                type="button"
                onClick={() => onListenWard(stats.todayWard)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-900 dark:text-amber-200 font-bold text-xs sm:text-sm shadow-xs transition-all active:scale-95"
                title="تشغيل سور ورد اليوم تلقائياً واحداً تلو الآخر"
              >
                <Headphones className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <span>الاستماع لورد اليوم (متتابع)</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => handleReadDayWard(stats.todayWard)}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white dark:bg-emerald-700 dark:hover:bg-emerald-600 font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95"
            >
              <BookOpen className="w-4 h-4" />
              <span>ابدأ تلاوة ورد اليوم في المصحف</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Surahs covered in today's ward */}
        <div className="space-y-1.5">
          <span className="text-xs font-semibold text-stone-500 dark:text-stone-400 block">
            السور الكريمة المتضمنة في هذا الورد:
          </span>
          <div className="flex items-center gap-2 flex-wrap">
            {stats.todayWard.surahs.map((surah) => {
              const fullSurah = SURAHS.find((s) => s.number === surah.number);
              return (
                <button
                  key={surah.number}
                  type="button"
                  onClick={() => {
                    if (fullSurah && onNavigateToSurahPage) {
                      onNavigateToSurahPage(fullSurah, 1);
                    }
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-stone-850 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-stone-800 dark:text-stone-200 text-xs font-medium border border-stone-200 dark:border-stone-700 shadow-2xs transition-colors"
                >
                  <span className="w-5 h-5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 flex items-center justify-center text-[10px] font-mono font-bold">
                    {surah.number.toLocaleString('ar-EG')}
                  </span>
                  <span>سورة {surah.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Tabs Switcher: جدول الأيام / لوحة الإحصائيات الشاملة */}
      <div className="flex items-center justify-between border-b border-stone-200 dark:border-stone-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('schedule')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'schedule'
                ? 'bg-emerald-800 text-white shadow-xs dark:bg-emerald-700'
                : 'bg-stone-100 dark:bg-stone-850 text-stone-600 dark:text-stone-400 hover:text-stone-900'
            }`}
          >
            جدول الخطة اليومي ({plan.durationDays.toLocaleString('ar-EG')} يوماً)
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('stats')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'stats'
                ? 'bg-emerald-800 text-white shadow-xs dark:bg-emerald-700'
                : 'bg-stone-100 dark:bg-stone-850 text-stone-600 dark:text-stone-400 hover:text-stone-900'
            }`}
          >
            لوحة الإحصائيات الشاملة 📊
          </button>
        </div>

        {activeTab === 'schedule' && (
          <div className="flex items-center gap-1 text-xs">
            <button
              type="button"
              onClick={() => setScheduleFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-medium ${
                scheduleFilter === 'all'
                  ? 'bg-stone-200 dark:bg-stone-700 text-stone-900 dark:text-stone-100 font-bold'
                  : 'text-stone-500'
              }`}
            >
              الكل
            </button>
            <button
              type="button"
              onClick={() => setScheduleFilter('remaining')}
              className={`px-2.5 py-1 rounded-lg font-medium ${
                scheduleFilter === 'remaining'
                  ? 'bg-stone-200 dark:bg-stone-700 text-stone-900 dark:text-stone-100 font-bold'
                  : 'text-stone-500'
              }`}
            >
              المتبقي
            </button>
            <button
              type="button"
              onClick={() => setScheduleFilter('completed')}
              className={`px-2.5 py-1 rounded-lg font-medium ${
                scheduleFilter === 'completed'
                  ? 'bg-stone-200 dark:bg-stone-700 text-stone-900 dark:text-stone-100 font-bold'
                  : 'text-stone-500'
              }`}
            >
              المكتمل
            </button>
          </div>
        )}
      </div>

      {/* Tab 1: Schedule View (Day-by-Day) */}
      {activeTab === 'schedule' && (
        <div className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredDaysSchedule.map((ward) => {
              const isToday = ward.dayNumber === stats.currentDay;
              return (
                <div
                  key={ward.dayNumber}
                  className={`rounded-2xl p-4 border transition-all flex flex-col justify-between gap-3 ${
                    ward.isCompleted
                      ? 'bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800'
                      : isToday
                      ? 'bg-white dark:bg-stone-900 border-amber-400 dark:border-amber-600 ring-2 ring-amber-400/20 shadow-xs'
                      : 'bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-800 hover:border-emerald-400'
                  }`}
                >
                  {/* Card Header */}
                  <div className="flex items-center justify-between gap-2 border-b border-stone-100 dark:border-stone-800 pb-2">
                    <div className="flex items-center gap-2">
                      <span className={`w-7 h-7 rounded-xl font-bold font-mono text-xs flex items-center justify-center ${
                        ward.isCompleted 
                          ? 'bg-emerald-600 text-white' 
                          : isToday 
                          ? 'bg-amber-500 text-stone-950' 
                          : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300'
                      }`}>
                        {ward.dayNumber}
                      </span>
                      <span className="font-bold text-xs sm:text-sm text-stone-900 dark:text-stone-100">
                        اليوم {ward.dayNumber.toLocaleString('ar-EG')}
                      </span>
                      {isToday && (
                        <span className="text-[10px] px-2 py-0.2 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-bold">
                          اليوم
                        </span>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => handleToggleDay(ward.dayNumber)}
                      className={`p-1.5 rounded-xl transition-all active:scale-90 ${
                        ward.isCompleted
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : 'bg-stone-100 dark:bg-stone-800 text-stone-400 hover:text-emerald-700'
                      }`}
                      title={ward.isCompleted ? 'إلغاء التحديد' : 'تحديد كمكتمل'}
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Ward Details */}
                  <div className="space-y-1.5 text-xs text-stone-600 dark:text-stone-300">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-stone-500">نطاق الصفحات:</span>
                      <span className="font-bold font-mono text-emerald-800 dark:text-emerald-300">
                        ص {ward.startPage.toLocaleString('ar-EG')} — ص {ward.endPage.toLocaleString('ar-EG')}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-stone-500">
                      <span>عدد الصفحات:</span>
                      <span>{ward.pagesCount.toLocaleString('ar-EG')} صفحة • جزء {ward.approxJuz.toLocaleString('ar-EG')}</span>
                    </div>

                    {/* Surahs preview */}
                    <div className="pt-1 text-[11px] text-stone-500 dark:text-stone-400 truncate">
                      {ward.surahs.map((s) => `سورة ${s.name}`).join('، ')}
                    </div>
                  </div>

                  {/* Read & Listen Buttons */}
                  <div className="pt-2 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between">
                    {onListenWard ? (
                      <button
                        type="button"
                        onClick={() => onListenWard(ward)}
                        className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-700 dark:text-amber-400 hover:underline"
                        title="الاستماع لسور هذا اليوم متتابعة"
                      >
                        <Headphones className="w-3.5 h-3.5" />
                        <span>استماع متتابع</span>
                      </button>
                    ) : <div />}

                    <button
                      type="button"
                      onClick={() => handleReadDayWard(ward)}
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:underline"
                    >
                      <span>تلاوة في المصحف</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Comprehensive Statistics & Analytics View */}
      {activeTab === 'stats' && (
        <div className="space-y-5">
          
          {/* Main Quranic Milestones */}
          <div className="bg-white dark:bg-stone-900 rounded-3xl p-6 border border-stone-200 dark:border-stone-800 shadow-xs space-y-5">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
              <h3 className="font-bold text-base sm:text-lg text-stone-900 dark:text-stone-100">
                إحصائيات الإنجاز القرآني الشامل
              </h3>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="rounded-2xl p-4 bg-stone-50 dark:bg-stone-850 border border-stone-200/80 dark:border-stone-700/80 text-center space-y-1">
                <span className="text-xs text-stone-500 block">الصفحات المقروءة</span>
                <span className="text-2xl font-bold font-mono text-emerald-800 dark:text-emerald-300">
                  {stats.readPages.toLocaleString('ar-EG')}
                </span>
                <span className="text-[11px] text-stone-400 block">من ٦٠٤ صفحة</span>
              </div>

              <div className="rounded-2xl p-4 bg-stone-50 dark:bg-stone-850 border border-stone-200/80 dark:border-stone-700/80 text-center space-y-1">
                <span className="text-xs text-stone-500 block">الأجزاء المكتملة</span>
                <span className="text-2xl font-bold font-mono text-amber-700 dark:text-amber-400">
                  {stats.juzCompletedCount.toLocaleString('ar-EG')}
                </span>
                <span className="text-[11px] text-stone-400 block">من ٣٠ جزءاً</span>
              </div>

              <div className="rounded-2xl p-4 bg-stone-50 dark:bg-stone-850 border border-stone-200/80 dark:border-stone-700/80 text-center space-y-1">
                <span className="text-xs text-stone-500 block">السور المنتهية</span>
                <span className="text-2xl font-bold font-mono text-indigo-700 dark:text-indigo-400">
                  {stats.surahsCompletedCount.toLocaleString('ar-EG')}
                </span>
                <span className="text-[11px] text-stone-400 block">من ١١٤ سورة</span>
              </div>

              <div className="rounded-2xl p-4 bg-stone-50 dark:bg-stone-850 border border-stone-200/80 dark:border-stone-700/80 text-center space-y-1">
                <span className="text-xs text-stone-500 block">الآيات المفضلة</span>
                <span className="text-2xl font-bold font-mono text-rose-600 dark:text-rose-400">
                  {favoriteVersesCount.toLocaleString('ar-EG')}
                </span>
                {onOpenFavoriteVerses ? (
                  <button
                    type="button"
                    onClick={onOpenFavoriteVerses}
                    className="text-[11px] text-rose-600 dark:text-rose-400 hover:underline block mx-auto"
                  >
                    عرض القائمة الجانبية
                  </button>
                ) : (
                  <span className="text-[11px] text-stone-400 block">آية محفوظة</span>
                )}
              </div>
            </div>

            {/* Reading Streak & Pacing Details */}
            <div className="rounded-2xl p-4 bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 space-y-2">
              <h4 className="font-bold text-xs sm:text-sm text-emerald-950 dark:text-emerald-200 flex items-center gap-2">
                <Flame className="w-4 h-4 text-amber-500" />
                <span>الوتيرة الحالية والتقدير الزمني للختم</span>
              </h4>
              <p className="text-xs text-emerald-900/80 dark:text-emerald-300/80 leading-relaxed">
                بناءً على وتيرة القراءة الحالية بمعدل وردك اليومي، يتوقع أن تكمل ختم المصحف الشريف بحول الله في تاريخ: <strong className="font-mono text-emerald-950 dark:text-emerald-100">{stats.estimatedCompletionDate}</strong>.
              </p>
            </div>
          </div>

          {/* Quick Adhkar Connection */}
          <div className="bg-white dark:bg-stone-900 rounded-3xl p-6 border border-stone-200 dark:border-stone-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400 flex items-center justify-center shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-stone-900 dark:text-stone-100">
                  الأذكار والتسابيح اليومية
                </h4>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  أنجزت اليوم {completedAdhkarCount.toLocaleString('ar-EG')} أذكار مأثورة من حصن المسلم
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                if (onBackToQuran) {
                  onBackToQuran();
                }
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 text-stone-700 dark:text-stone-300 text-xs font-semibold transition-colors"
            >
              <span>فتح قسم الأذكار</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      )}

      {/* Plan Settings Modal */}
      <CreateKhatmahModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        currentPlan={plan}
        onPlanCreated={(newPlan) => {
          setPlan(newPlan);
          setStats(getKhatmahStats(newPlan));
          setCelebrationToast(`تم اعتماد خطة الختمة بنجاح (${newPlan.durationDays.toLocaleString('ar-EG')} يوماً)! نسأل الله لك التوفيق والقبول 🌿`);
          setTimeout(() => setCelebrationToast(null), 4000);
        }}
      />

    </section>
  );
};
