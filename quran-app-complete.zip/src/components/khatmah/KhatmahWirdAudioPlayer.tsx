import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Play, 
  Pause, 
  SkipForward, 
  SkipBack, 
  Volume2, 
  RotateCcw, 
  RotateCw, 
  Minimize2, 
  Maximize2, 
  Headphones, 
  Check, 
  CheckCircle2, 
  Sparkles, 
  BookOpen, 
  Calendar, 
  ListMusic, 
  Gauge, 
  ExternalLink,
  ChevronDown
} from 'lucide-react';
import { DayWardInfo, KhatmahPlan } from '../../services/khatmahService';
import { SURAHS, Surah } from '../../data/surahs';
import { 
  RECITERS, 
  Reciter, 
  getSavedReciter, 
  saveSelectedReciter, 
  getSurahAudioUrl 
} from '../../services/quranAudioService';

interface KhatmahWirdAudioPlayerProps {
  isOpen: boolean;
  onClose: () => void;
  ward: DayWardInfo | null;
  plan: KhatmahPlan | null;
  onSelectSurahForReading?: (surah: Surah, verseNumber?: number) => void;
  onMarkDayCompleted?: (dayNumber: number) => void;
  onPlayNextDayWard?: (nextDayNumber: number) => void;
  initialSurahNumber?: number;
}

export const KhatmahWirdAudioPlayer: React.FC<KhatmahWirdAudioPlayerProps> = ({
  isOpen,
  onClose,
  ward,
  plan,
  onSelectSurahForReading,
  onMarkDayCompleted,
  onPlayNextDayWard,
  initialSurahNumber,
}) => {
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [selectedReciter, setSelectedReciter] = useState<Reciter>(() => getSavedReciter());
  const [showReciterMenu, setShowReciterMenu] = useState<boolean>(false);
  const [currentSurahIndex, setCurrentSurahIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [autoAdvance, setAutoAdvance] = useState<boolean>(true);
  const [showQueue, setShowQueue] = useState<boolean>(false);
  const [transitionNotice, setTransitionNotice] = useState<string | null>(null);
  const [isFinishedWird, setIsFinishedWird] = useState<boolean>(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Map ward surahs to full Surah objects
  const wardSurahs: Surah[] = React.useMemo(() => {
    if (!ward || !ward.surahs || ward.surahs.length === 0) return [];
    return ward.surahs
      .map((s) => SURAHS.find((item) => item.number === s.number))
      .filter((item): item is Surah => !!item);
  }, [ward]);

  const currentSurah = wardSurahs[currentSurahIndex] || wardSurahs[0] || null;

  // Initialize or reset queue when ward or initialSurahNumber changes
  useEffect(() => {
    if (!isOpen || wardSurahs.length === 0) return;

    if (initialSurahNumber) {
      const idx = wardSurahs.findIndex((s) => s.number === initialSurahNumber);
      setCurrentSurahIndex(idx >= 0 ? idx : 0);
    } else {
      setCurrentSurahIndex(0);
    }

    setIsFinishedWird(false);
    setIsPlaying(true);
    setCurrentTime(0);
  }, [isOpen, ward?.dayNumber, initialSurahNumber]);

  // Handle audio source loading and auto-play
  useEffect(() => {
    if (!isOpen || !currentSurah) return;

    const audioUrl = getSurahAudioUrl(currentSurah.number, selectedReciter.id);

    if (!audioRef.current) {
      audioRef.current = new Audio();
    }

    const audio = audioRef.current;
    audio.src = audioUrl;
    audio.playbackRate = playbackSpeed;

    const onLoadedMetadata = () => {
      setDuration(audio.duration || 0);
      if (isPlaying) {
        audio.play().catch((e) => {
          console.warn('Playback error:', e);
          setIsPlaying(false);
        });
      }
    };

    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime || 0);
    };

    const onEnded = () => {
      // Current Surah finished: check if there is a next Surah in the Wird
      if (currentSurahIndex < wardSurahs.length - 1 && autoAdvance) {
        const nextIdx = currentSurahIndex + 1;
        const nextSurah = wardSurahs[nextIdx];
        setTransitionNotice(`تمت تلاوة سورة ${currentSurah.name}. جاري الانتقال لسورة ${nextSurah.name}...`);
        setTimeout(() => setTransitionNotice(null), 3500);
        setCurrentSurahIndex(nextIdx);
        setIsPlaying(true);
      } else {
        // Last Surah in the Wird finished!
        setIsPlaying(false);
        setIsFinishedWird(true);
        if (ward && onMarkDayCompleted && !ward.isCompleted) {
          onMarkDayCompleted(ward.dayNumber);
        }
      }
    };

    const onError = () => {
      console.warn('Audio loading error on URL:', audioUrl);
      setIsPlaying(false);
    };

    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('error', onError);

    if (isPlaying) {
      audio.play().catch(() => setIsPlaying(false));
    }

    return () => {
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('ended', onEnded);
      audio.removeEventListener('error', onError);
    };
  }, [currentSurah?.number, selectedReciter.id, currentSurahIndex, autoAdvance]);

  // Sync playback speed
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed]);

  // Clean up audio when modal completely closed
  useEffect(() => {
    if (!isOpen && audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  }, [isOpen]);

  const handleTogglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    }
  };

  const handleSeek = (newTime: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const handleSkipTime = (deltaSeconds: number) => {
    if (audioRef.current) {
      const nextTime = Math.max(0, Math.min(duration, audioRef.current.currentTime + deltaSeconds));
      audioRef.current.currentTime = nextTime;
      setCurrentTime(nextTime);
    }
  };

  const handleNextSurah = () => {
    if (currentSurahIndex < wardSurahs.length - 1) {
      setCurrentSurahIndex((prev) => prev + 1);
      setIsPlaying(true);
    }
  };

  const handlePrevSurah = () => {
    if (currentTime > 5 && audioRef.current) {
      audioRef.current.currentTime = 0;
      setCurrentTime(0);
    } else if (currentSurahIndex > 0) {
      setCurrentSurahIndex((prev) => prev - 1);
      setIsPlaying(true);
    }
  };

  const handleChangeReciter = (reciter: Reciter) => {
    setSelectedReciter(reciter);
    saveSelectedReciter(reciter.id);
    setShowReciterMenu(false);
    setIsPlaying(true);
  };

  const formatTime = (seconds: number): string => {
    if (isNaN(seconds) || seconds < 0) return '00:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (!isOpen || !ward || wardSurahs.length === 0 || !currentSurah) {
    return null;
  }

  // Mini Floating Player Mode
  if (isMinimized) {
    return (
      <div 
        className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:w-96 z-50 bg-stone-900/95 dark:bg-stone-900/95 backdrop-blur-md text-white rounded-2xl p-3 shadow-2xl border border-emerald-500/30 flex items-center justify-between gap-3 animate-in slide-in-from-bottom-5 duration-200"
        dir="rtl"
      >
        <div className="flex items-center gap-2.5 overflow-hidden flex-1">
          <div className="w-10 h-10 rounded-xl bg-emerald-600/30 border border-emerald-500/50 flex items-center justify-center shrink-0 text-emerald-400">
            <Headphones className="w-5 h-5 animate-pulse" />
          </div>
          <div className="truncate">
            <div className="text-xs font-bold text-emerald-300 flex items-center gap-1.5 truncate">
              <span>سورة {currentSurah.name}</span>
              <span className="text-[10px] text-stone-400 font-normal">
                ({(currentSurahIndex + 1).toLocaleString('ar-EG')}/{wardSurahs.length.toLocaleString('ar-EG')})
              </span>
            </div>
            <div className="text-[11px] text-stone-300 truncate">
              الورد اليومي {ward.dayNumber.toLocaleString('ar-EG')} • {selectedReciter.name}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={handleTogglePlay}
            className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs active:scale-95 transition-transform"
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
          </button>

          <button
            type="button"
            onClick={handleNextSurah}
            disabled={currentSurahIndex >= wardSurahs.length - 1}
            className="p-1.5 rounded-lg text-stone-300 hover:text-white disabled:opacity-30"
            title="السورة التالية في الورد"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => setIsMinimized(false)}
            className="p-1.5 rounded-lg text-stone-300 hover:text-white"
            title="تكبير المشغل"
          >
            <Maximize2 className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-rose-400"
            title="إغلاق المشغل"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // Full Khatmah Audio Player Modal
  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs"
      dir="rtl"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-xl bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/15 border border-white/20 flex items-center justify-center text-white shadow-xs">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold flex items-center gap-2">
                <span>تلاوة الورد اليومي للختمة</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-white/20 font-medium">
                  اليوم {ward.dayNumber.toLocaleString('ar-EG')}
                </span>
              </h2>
              <p className="text-xs text-emerald-100/90">
                ص {ward.startPage.toLocaleString('ar-EG')} إلى ص {ward.endPage.toLocaleString('ar-EG')} • {ward.pagesCount.toLocaleString('ar-EG')} صفحة • جزء {ward.approxJuz.toLocaleString('ar-EG')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setIsMinimized(true)}
              className="p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-colors"
              title="تصغير المشغل إلى شريط عائم"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-colors"
              title="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Transition Notice Toast */}
        {transitionNotice && (
          <div className="px-4 py-2 bg-emerald-50 dark:bg-emerald-950/80 border-b border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-semibold flex items-center justify-center gap-2 animate-in fade-in">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600 animate-spin" />
            <span>{transitionNotice}</span>
          </div>
        )}

        {/* Finished Day Wird Celebration Card */}
        {isFinishedWird && (
          <div className="p-4 m-4 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-amber-500/10 to-emerald-500/15 border border-emerald-500/40 text-center space-y-2.5">
            <div className="inline-flex p-2 rounded-full bg-emerald-600 text-white shadow-xs">
              <Check className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm sm:text-base text-emerald-950 dark:text-emerald-100">
              تقبل الله! أتممت الاستماع إلى كافة سور الورد اليومي لهذا اليوم بنجاح 🌟
            </h3>
            <div className="flex items-center justify-center gap-2 pt-1 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  if (onMarkDayCompleted) onMarkDayCompleted(ward.dayNumber);
                  setIsFinishedWird(false);
                }}
                className="px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs active:scale-95"
              >
                تثبيت إنجاز الورد ✓
              </button>

              {onPlayNextDayWard && plan && ward.dayNumber < plan.durationDays && (
                <button
                  type="button"
                  onClick={() => onPlayNextDayWard(ward.dayNumber + 1)}
                  className="px-4 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-900 dark:text-amber-200 border border-amber-400/50 text-xs font-bold active:scale-95"
                >
                  الانتقال لورد اليوم التالي ({ward.dayNumber + 1}) →
                </button>
              )}
            </div>
          </div>
        )}

        {/* Main Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          
          {/* Active Surah Hero Card */}
          <div className="p-6 rounded-3xl bg-gradient-to-b from-stone-50 to-stone-100 dark:from-stone-850 dark:to-stone-900 border border-stone-200 dark:border-stone-800 text-center space-y-3 relative overflow-hidden shadow-inner">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-800 flex items-center justify-center text-emerald-800 dark:text-emerald-200 shadow-md">
              <span className="font-serif text-2xl font-bold">
                {currentSurah.number.toLocaleString('ar-EG')}
              </span>
            </div>

            <div>
              <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-widest block">
                السورة الحالية ({currentSurahIndex + 1} من {wardSurahs.length})
              </span>
              <h3 className="font-amiri text-2xl sm:text-3xl font-bold text-stone-900 dark:text-stone-100 mt-1">
                سورة {currentSurah.name}
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
                {currentSurah.type} • {currentSurah.versesCount.toLocaleString('ar-EG')} آية • الصفحة {currentSurah.page.toLocaleString('ar-EG')} • الجزء {currentSurah.juz.toLocaleString('ar-EG')}
              </p>
            </div>

            {/* Read Surah in Mushaf Button */}
            {onSelectSurahForReading && (
              <div className="pt-1">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onSelectSurahForReading(currentSurah, 1);
                  }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-200 border border-stone-200 dark:border-stone-700 hover:bg-stone-50 text-xs font-semibold shadow-2xs transition-colors"
                >
                  <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                  <span>متابعة قراءة السورة في المصحف</span>
                  <ExternalLink className="w-3 h-3 text-stone-400" />
                </button>
              </div>
            )}
          </div>

          {/* Timeline Scrub Bar */}
          <div className="space-y-1.5">
            <input
              type="range"
              min="0"
              max={duration || 100}
              value={currentTime}
              onChange={(e) => handleSeek(Number(e.target.value))}
              className="w-full accent-emerald-600 h-2 bg-stone-200 dark:bg-stone-700 rounded-lg cursor-pointer"
            />
            <div className="flex items-center justify-between text-xs font-mono text-stone-500 dark:text-stone-400">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Main Controls: Previous, 15s back, Play/Pause, 15s forward, Next */}
          <div className="flex items-center justify-center gap-3 sm:gap-5">
            <button
              type="button"
              onClick={handlePrevSurah}
              disabled={currentSurahIndex === 0 && currentTime < 5}
              className="p-3 rounded-2xl text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 disabled:opacity-30 transition-all active:scale-90"
              title="السورة السابقة"
            >
              <SkipForward className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={() => handleSkipTime(-15)}
              className="p-2.5 rounded-2xl text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition-all active:scale-90"
              title="تقديم ١٥ ثانية"
            >
              <RotateCw className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleTogglePlay}
              className="w-14 h-14 rounded-3xl bg-emerald-700 hover:bg-emerald-800 text-white flex items-center justify-center shadow-lg transition-all active:scale-95"
              title={isPlaying ? 'إيقاف مؤقت' : 'تشغيل'}
            >
              {isPlaying ? (
                <Pause className="w-6 h-6 fill-current" />
              ) : (
                <Play className="w-6 h-6 fill-current translate-x-0.5" />
              )}
            </button>

            <button
              type="button"
              onClick={() => handleSkipTime(15)}
              className="p-2.5 rounded-2xl text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 transition-all active:scale-90"
              title="تأخير ١٥ ثانية"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleNextSurah}
              disabled={currentSurahIndex >= wardSurahs.length - 1}
              className="p-3 rounded-2xl text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 disabled:opacity-30 transition-all active:scale-90"
              title="السورة التالية"
            >
              <SkipBack className="w-5 h-5" />
            </button>
          </div>

          {/* Secondary Controls Bar: Reciter, Speed, Auto-advance, Queue */}
          <div className="flex items-center justify-between gap-2 p-3 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-800 flex-wrap">
            
            {/* Reciter Selector */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowReciterMenu((prev) => !prev)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-xs font-semibold text-stone-700 dark:text-stone-200 shadow-2xs hover:bg-stone-100"
              >
                <Volume2 className="w-3.5 h-3.5 text-emerald-600" />
                <span className="truncate max-w-[120px]">{selectedReciter.name}</span>
                <ChevronDown className="w-3 h-3 text-stone-400" />
              </button>

              {showReciterMenu && (
                <div className="absolute bottom-full mb-2 right-0 w-60 bg-white dark:bg-stone-800 rounded-2xl border border-stone-200 dark:border-stone-700 shadow-xl p-2 z-50 space-y-1">
                  <div className="text-[11px] font-bold text-stone-400 px-2 py-1">
                    اختر القارئ المفضل للختمة:
                  </div>
                  {RECITERS.map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => handleChangeReciter(r)}
                      className={`w-full text-right px-3 py-1.5 rounded-xl text-xs flex items-center justify-between transition-colors ${
                        r.id === selectedReciter.id
                          ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-900 dark:text-emerald-200 font-bold'
                          : 'hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-200'
                      }`}
                    >
                      <span>{r.name}</span>
                      {r.id === selectedReciter.id && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Playback Speed Stepper */}
            <div className="flex items-center gap-1 bg-white dark:bg-stone-800 p-0.5 rounded-xl border border-stone-200 dark:border-stone-700 text-xs">
              {[0.75, 1, 1.25, 1.5].map((speed) => (
                <button
                  key={speed}
                  type="button"
                  onClick={() => setPlaybackSpeed(speed)}
                  className={`px-2 py-1 rounded-lg font-mono font-medium transition-colors ${
                    playbackSpeed === speed
                      ? 'bg-emerald-700 text-white font-bold'
                      : 'text-stone-600 dark:text-stone-400 hover:text-stone-900'
                  }`}
                >
                  {speed}x
                </button>
              ))}
            </div>

            {/* Auto-Advance Toggle */}
            <button
              type="button"
              onClick={() => setAutoAdvance((prev) => !prev)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-colors ${
                autoAdvance
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                  : 'bg-white dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-500'
              }`}
              title="التشغيل التلقائي للسورة التالية عند انتهاء السورة الحالية"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>تشغيل تلقائي</span>
            </button>

            {/* Toggle Queue Drawer */}
            <button
              type="button"
              onClick={() => setShowQueue((prev) => !prev)}
              className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-colors ${
                showQueue
                  ? 'bg-stone-800 text-white dark:bg-stone-700 border-stone-800'
                  : 'bg-white dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300'
              }`}
            >
              <ListMusic className="w-3.5 h-3.5" />
              <span>قائمة السور ({wardSurahs.length})</span>
            </button>

          </div>

          {/* Surah Queue List */}
          {showQueue && (
            <div className="space-y-2 border-t border-stone-200 dark:border-stone-800 pt-3 animate-in fade-in">
              <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400 px-1">
                <span>سور الورد اليومي المجدولة ({wardSurahs.length} سورة):</span>
                <span>انقر للانتقال لأي سورة</span>
              </div>

              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {wardSurahs.map((surah, index) => {
                  const isCurrent = index === currentSurahIndex;
                  const isDone = index < currentSurahIndex;

                  return (
                    <button
                      key={surah.number}
                      type="button"
                      onClick={() => {
                        setCurrentSurahIndex(index);
                        setIsPlaying(true);
                      }}
                      className={`w-full text-right p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                        isCurrent
                          ? 'bg-emerald-50 dark:bg-emerald-950/70 border-emerald-400 dark:border-emerald-600 shadow-xs'
                          : isDone
                          ? 'bg-stone-50/70 dark:bg-stone-900/50 border-stone-200/60 dark:border-stone-800/60 text-stone-500'
                          : 'bg-white dark:bg-stone-850 border-stone-200 dark:border-stone-700 hover:border-emerald-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-mono font-bold ${
                          isCurrent
                            ? 'bg-emerald-600 text-white'
                            : isDone
                            ? 'bg-stone-200 dark:bg-stone-800 text-stone-500'
                            : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300'
                        }`}>
                          {isDone ? <Check className="w-3.5 h-3.5" /> : (index + 1).toLocaleString('ar-EG')}
                        </span>
                        <div>
                          <span className={`text-sm font-bold block ${isCurrent ? 'text-emerald-950 dark:text-emerald-100' : ''}`}>
                            سورة {surah.name}
                          </span>
                          <span className="text-[11px] text-stone-400">
                            {surah.versesCount.toLocaleString('ar-EG')} آية • ص {surah.page.toLocaleString('ar-EG')}
                          </span>
                        </div>
                      </div>

                      <div className="text-xs font-semibold">
                        {isCurrent ? (
                          <span className="text-emerald-700 dark:text-emerald-400 flex items-center gap-1 font-bold">
                            <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                            <span>تُتلى الآن</span>
                          </span>
                        ) : isDone ? (
                          <span className="text-stone-400">تمت التلاوة ✓</span>
                        ) : (
                          <span className="text-stone-400">قادمة</span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-950/80 flex items-center justify-between text-xs text-stone-500">
          <div className="flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-emerald-600" />
            <span>
              نظام الاستماع المتتابع يضمن إكمال سور الورد تلقائياً واحداً تلو الآخر
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-stone-200 dark:bg-stone-800 text-stone-800 dark:text-stone-200 font-bold hover:bg-stone-300 dark:hover:bg-stone-700 transition-colors"
          >
            إغلاق النافذة
          </button>
        </div>

      </div>
    </div>
  );
};
