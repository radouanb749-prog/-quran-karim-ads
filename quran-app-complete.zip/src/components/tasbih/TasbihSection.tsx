import React, { useState, useEffect, useRef } from 'react';
import { 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Smartphone, 
  Sparkles, 
  Plus, 
  Trash2, 
  Check, 
  CheckCircle2, 
  Award, 
  Flame, 
  ArrowRight, 
  HelpCircle,
  Settings2,
  Sliders,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { 
  TasbihPreset, 
  AFTER_PRAYER_SEQUENCE, 
  DEFAULT_TASBIH_PRESETS,
  TasbihStats,
  TasbihSettings,
  getAllTasbihPresets,
  getSavedPresetId,
  saveCurrentPresetId,
  saveCustomTasbihPreset,
  deleteCustomTasbihPreset,
  getTasbihStats,
  incrementTasbihStats,
  incrementTasbihRounds,
  resetTasbihTodayStats,
  getTasbihSettings,
  saveTasbihSettings,
  triggerHaptic,
  playTasbihSound,
  formatTasbihNumber,
} from '../../services/tasbihService';

interface TasbihSectionProps {
  onBackToQuran?: () => void;
}

export const TasbihSection: React.FC<TasbihSectionProps> = ({ onBackToQuran }) => {
  const [presets, setPresets] = useState<TasbihPreset[]>(() => getAllTasbihPresets());
  const [currentPresetId, setCurrentPresetId] = useState<string>(() => getSavedPresetId());
  const [count, setCount] = useState<number>(0);
  const [completedRounds, setCompletedRounds] = useState<number>(0);
  const [stats, setStats] = useState<TasbihStats>(() => getTasbihStats());
  const [settings, setSettings] = useState<TasbihSettings>(() => getTasbihSettings());
  
  // Mode: 'free' (individual dhikr) or 'prayer_sequence' (automatic 33/33/33/1)
  const [mode, setMode] = useState<'free' | 'prayer_sequence'>('free');
  const [prayerStepIndex, setPrayerStepIndex] = useState<number>(0);

  // Custom Target Modal & Add Dhikr Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [newDhikrTitle, setNewDhikrTitle] = useState('');
  const [newDhikrTarget, setNewDhikrTarget] = useState(33);
  const [newDhikrVirtue, setNewDhikrVirtue] = useState('');

  // Full Screen Tap Mode
  const [isFullScreenTap, setIsFullScreenTap] = useState(false);

  // Ripple effect on tap
  const [isButtonRippling, setIsButtonRippling] = useState(false);
  const [justCompletedTarget, setJustCompletedTarget] = useState(false);

  const currentPreset = presets.find((p) => p.id === currentPresetId) || presets[0];

  // Active target based on mode
  const activeTarget = mode === 'prayer_sequence' 
    ? AFTER_PRAYER_SEQUENCE[prayerStepIndex].target 
    : currentPreset.target;

  const activeTitle = mode === 'prayer_sequence'
    ? AFTER_PRAYER_SEQUENCE[prayerStepIndex].text
    : currentPreset.title;

  // Handle Preset Change
  const handleSelectPreset = (preset: TasbihPreset) => {
    setCurrentPresetId(preset.id);
    saveCurrentPresetId(preset.id);
    setCount(0);
    setCompletedRounds(0);
    setMode('free');
  };

  // Switch to Prayer Sequence
  const handleStartPrayerSequence = () => {
    setMode('prayer_sequence');
    setPrayerStepIndex(0);
    setCount(0);
    setCompletedRounds(0);
  };

  // Perform Count Increment (Tap)
  const handleTap = () => {
    const nextCount = count + 1;
    
    // Tactile Feedback
    if (settings.vibration) {
      triggerHaptic('tap');
    }
    if (settings.sound) {
      playTasbihSound();
    }

    // Ripple animation
    setIsButtonRippling(true);
    setTimeout(() => setIsButtonRippling(false), 150);

    // Update Global Statistics
    const newStats = incrementTasbihStats(1);
    setStats(newStats);

    // Target Check
    if (activeTarget > 0 && nextCount >= activeTarget) {
      // Completed target!
      if (settings.vibration) {
        triggerHaptic('complete');
      }

      setJustCompletedTarget(true);
      setTimeout(() => setJustCompletedTarget(false), 2000);

      const updatedRoundsStats = incrementTasbihRounds();
      setStats(updatedRoundsStats);
      setCompletedRounds((prev) => prev + 1);

      if (mode === 'prayer_sequence') {
        if (prayerStepIndex < AFTER_PRAYER_SEQUENCE.length - 1) {
          // Advance to next prayer sequence step
          setPrayerStepIndex((prev) => prev + 1);
          setCount(0);
        } else {
          // Finished entire after prayer sequence!
          setCount(nextCount);
          setTimeout(() => {
            alert('تقبل الله طاعتكم! أكملت تسبيح دبر الصلاة كاملاً 🌿');
            setPrayerStepIndex(0);
            setCount(0);
          }, 300);
        }
      } else {
        // Reset current count back to 0 for next round
        setCount(0);
      }
    } else {
      setCount(nextCount);
    }
  };

  // Reset Counter
  const handleResetCount = () => {
    if (count > 0 || completedRounds > 0) {
      if (settings.vibration) triggerHaptic('reset');
      setCount(0);
      setCompletedRounds(0);
      if (mode === 'prayer_sequence') {
        setPrayerStepIndex(0);
      }
    }
  };

  // Adjust Target of Current Preset
  const handleSetTarget = (target: number) => {
    if (mode === 'free') {
      const updated = presets.map((p) => (p.id === currentPreset.id ? { ...p, target } : p));
      setPresets(updated);
      setCount(0);
    }
  };

  // Toggle Sound & Vibration
  const handleToggleSound = () => {
    const next = !settings.sound;
    const updated = { ...settings, sound: next };
    setSettings(updated);
    saveTasbihSettings(updated);
  };

  const handleToggleVibration = () => {
    const next = !settings.vibration;
    const updated = { ...settings, vibration: next };
    setSettings(updated);
    saveTasbihSettings(updated);
    if (next) triggerHaptic('tap');
  };

  const handleToggleNumeralStyle = () => {
    const next: 'standard' | 'eastern' = settings.numeralStyle === 'standard' ? 'eastern' : 'standard';
    const updated: TasbihSettings = { ...settings, numeralStyle: next };
    setSettings(updated);
    saveTasbihSettings(updated);
  };

  const formatNum = (num: number) => {
    return formatTasbihNumber(num, settings.numeralStyle);
  };

  // Add Custom Dhikr
  const handleSaveCustomDhikr = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDhikrTitle.trim()) return;

    const created = saveCustomTasbihPreset({
      title: newDhikrTitle.trim(),
      target: newDhikrTarget || 33,
      virtue: newDhikrVirtue.trim() || undefined,
    });

    const refreshed = getAllTasbihPresets();
    setPresets(refreshed);
    handleSelectPreset(created);

    setNewDhikrTitle('');
    setNewDhikrVirtue('');
    setShowAddModal(false);
  };

  // Delete Custom Dhikr
  const handleDeleteCustomDhikr = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteCustomTasbihPreset(id);
    const refreshed = getAllTasbihPresets();
    setPresets(refreshed);
    if (currentPresetId === id) {
      handleSelectPreset(refreshed[0]);
    }
  };

  // Calculate Progress Percent for Ring
  const progressPercent = activeTarget > 0 ? Math.min(100, (count / activeTarget) * 100) : 0;
  const strokeDashoffset = 100 - progressPercent;

  return (
    <div className="w-full max-w-4xl mx-auto px-3 sm:px-6 py-4 sm:py-8 space-y-6" dir="rtl">
      
      {/* Top Navigation & Status Bar */}
      <div className="flex items-center justify-between gap-3 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-3xl p-3 sm:p-4 shadow-sm">
        <div className="flex items-center gap-2">
          {onBackToQuran && (
            <button
              onClick={onBackToQuran}
              type="button"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-750 text-xs font-semibold transition-colors active:scale-95"
              title="العودة إلى المصحف الشريف"
            >
              <ArrowRight className="w-4 h-4" />
              <span>المصحف</span>
            </button>
          )}

          <div>
            <h2 className="font-amiri text-lg sm:text-2xl font-bold text-emerald-950 dark:text-emerald-100 flex items-center gap-2">
              <span>السبحة الإلكترونية</span>
              <span className="text-[11px] font-sans px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 font-medium">
                عداد الأذكار
              </span>
            </h2>
          </div>
        </div>

        {/* Quick Toggles: Sound, Vibration, Numeral Style, Fullscreen */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Numeral Style Switcher (123 / ١٢٣) */}
          <button
            type="button"
            onClick={handleToggleNumeralStyle}
            className={`px-2.5 py-1.5 rounded-xl border text-xs font-bold font-mono transition-all flex items-center justify-center min-w-[42px] ${
              settings.numeralStyle === 'standard'
                ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800 shadow-2xs'
                : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-700'
            }`}
            title={settings.numeralStyle === 'standard' ? 'الأرقام العادية العالمية (123) مفعّلة • انقر للتبديل إلى الأرقام المشرقية (١٢٣)' : 'الأرقام المشرقية (١٢٣) مفعّلة • انقر للتبديل إلى الأرقام العادية العالمية (123)'}
          >
            <span>{settings.numeralStyle === 'standard' ? '123' : '١٢٣'}</span>
          </button>

          <button
            type="button"
            onClick={handleToggleSound}
            className={`p-2 rounded-xl border transition-all ${
              settings.sound
                ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800'
                : 'bg-stone-100 dark:bg-stone-800 text-stone-400 border-stone-200 dark:border-stone-700'
            }`}
            title={settings.sound ? 'صوت النقر مفعّل (انقر للكتم)' : 'صوت النقر مكتوم (انقر للتفعيل)'}
          >
            {settings.sound ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={handleToggleVibration}
            className={`p-2 rounded-xl border transition-all ${
              settings.vibration
                ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800'
                : 'bg-stone-100 dark:bg-stone-800 text-stone-400 border-stone-200 dark:border-stone-700'
            }`}
            title={settings.vibration ? 'الاهتزاز مفعّل (انقر للتعطيل)' : 'الاهتزاز معطل (انقر للتفعيل)'}
          >
            <Smartphone className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => setIsFullScreenTap(!isFullScreenTap)}
            className={`p-2 rounded-xl border transition-all ${
              isFullScreenTap
                ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm'
                : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-700'
            }`}
            title="وضع ملء الشاشة للتسبيح باللمس الحر"
          >
            {isFullScreenTap ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mode Switcher Tabs: فردي / تسبيح دبر الصلاة */}
      <div className="flex items-center gap-2 bg-stone-200/60 dark:bg-stone-900 p-1 rounded-2xl border border-stone-200/80 dark:border-stone-800">
        <button
          type="button"
          onClick={() => {
            setMode('free');
            setCount(0);
          }}
          className={`flex-1 py-2 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            mode === 'free'
              ? 'bg-white dark:bg-stone-800 text-emerald-900 dark:text-emerald-200 shadow-xs'
              : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100'
          }`}
        >
          <span>التسبيح والذكر الحر</span>
        </button>

        <button
          type="button"
          onClick={handleStartPrayerSequence}
          className={`flex-1 py-2 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-1.5 ${
            mode === 'prayer_sequence'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>تسبيح دبر الصلاة (٣٣-٣٣-٣٣-١)</span>
        </button>
      </div>

      {/* Main Counter Arena */}
      <div className="relative bg-gradient-to-b from-white to-stone-50/70 dark:from-stone-900 dark:to-stone-950 border border-stone-200 dark:border-stone-800 rounded-3xl p-4 sm:p-8 shadow-sm overflow-hidden text-center">
        
        {/* Subtle Decorative Islamic Pattern */}
        <div 
          className="absolute inset-0 opacity-[0.025] dark:opacity-[0.05] pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(#059669 1.5px, transparent 1.5px)`,
            backgroundSize: '20px 20px',
          }}
        />

        {/* Current Dhikr Title Banner */}
        <div className="relative max-w-xl mx-auto mb-6 sm:mb-8">
          {mode === 'prayer_sequence' && (
            <div className="inline-flex items-center gap-2 mb-2 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-300/40 text-xs font-semibold">
              <span>سلسلة دبر الصلاة</span>
              <span>•</span>
              <span>المرحلة {prayerStepIndex + 1} من {AFTER_PRAYER_SEQUENCE.length}</span>
            </div>
          )}

          <h3 className="font-amiri text-2xl sm:text-4xl font-bold text-emerald-950 dark:text-emerald-100 leading-relaxed px-2">
            {activeTitle}
          </h3>

          {/* Current Dhikr Virtue (فضل الذكر) */}
          {mode === 'free' && currentPreset.virtue && (
            <p className="mt-2 text-xs sm:text-sm text-stone-600 dark:text-stone-400 max-w-md mx-auto leading-normal">
              ✨ {currentPreset.virtue}
            </p>
          )}

          {/* Target & Rounds Summary Badges */}
          <div className="flex items-center justify-center gap-2 sm:gap-3 flex-wrap mt-3 text-xs">
            <span className="px-3 py-1 rounded-full bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 border border-stone-200 dark:border-stone-700 font-medium">
              الهدف: {activeTarget > 0 ? `${formatNum(activeTarget)} مرة` : 'حر بلا نهاية ∞'}
            </span>

            {completedRounds > 0 && (
              <span className="px-3 py-1 rounded-full bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-400/40 font-bold flex items-center gap-1 animate-in zoom-in-95">
                <Award className="w-3.5 h-3.5 text-amber-500" />
                <span>{formatNum(completedRounds)} دورات مكتملة</span>
              </span>
            )}
          </div>
        </div>

        {/* Center: Large Interactive Tactile Beaded Circle Button */}
        <div className="relative inline-flex items-center justify-center my-2">
          
          {/* Circular Progress SVG Ring */}
          <svg className="w-64 h-64 sm:w-76 sm:h-76 -rotate-90" viewBox="0 0 120 120">
            {/* Background Track */}
            <circle
              cx="60"
              cy="60"
              r="52"
              fill="none"
              stroke="currentColor"
              className="text-stone-200/80 dark:text-stone-800"
              strokeWidth="6"
            />
            {/* Active Progress Arc */}
            {activeTarget > 0 && (
              <circle
                cx="60"
                cy="60"
                r="52"
                fill="none"
                stroke="url(#emeraldGradient)"
                strokeWidth="6"
                strokeDasharray="326.72"
                strokeDashoffset={(326.72 * (100 - progressPercent)) / 100}
                strokeLinecap="round"
                className="transition-all duration-200 ease-out"
              />
            )}
            <defs>
              <linearGradient id="emeraldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#10b981" />
                <stop offset="50%" stopColor="#059669" />
                <stop offset="100%" stopColor="#d97706" />
              </linearGradient>
            </defs>
          </svg>

          {/* Central Tap Button */}
          <button
            onClick={handleTap}
            type="button"
            className={`absolute inset-4 sm:inset-5 rounded-full flex flex-col items-center justify-center cursor-pointer select-none transition-all duration-150 shadow-2xl active:scale-95 outline-hidden ${
              isButtonRippling
                ? 'scale-96 bg-emerald-700 text-white'
                : 'bg-gradient-to-b from-emerald-600 via-emerald-700 to-emerald-900 text-white hover:brightness-105'
            } border-4 sm:border-6 border-white/20 dark:border-stone-800/40`}
            style={{
              boxShadow: '0 15px 35px -5px rgba(5, 150, 105, 0.4), inset 0 2px 4px rgba(255, 255, 255, 0.25)',
            }}
          >
            {/* Bead texture highlights */}
            <span className="text-[11px] sm:text-xs text-emerald-200 font-semibold tracking-wider mb-1 uppercase">
              {activeTarget > 0 ? `الهدف ${formatNum(activeTarget)}` : 'تسبيح حر'}
            </span>

            {/* Huge Number */}
            <span className="font-mono text-5xl sm:text-7xl font-extrabold tracking-tight drop-shadow-md">
              {formatNum(count)}
            </span>

            <span className="text-xs sm:text-sm text-emerald-200 font-medium mt-1">
              انقر للتسبيح
            </span>

            {/* Target Reached Flash */}
            {justCompletedTarget && (
              <span className="absolute inset-0 rounded-full bg-amber-400/30 animate-ping pointer-events-none" />
            )}
          </button>
        </div>

        {/* Counter Action Controls (Reset, Target Options) */}
        <div className="flex items-center justify-center gap-3 sm:gap-4 mt-6 sm:mt-8">
          {/* Reset Button */}
          <button
            type="button"
            onClick={handleResetCount}
            disabled={count === 0 && completedRounds === 0}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-750 text-stone-700 dark:text-stone-300 border border-stone-200 dark:border-stone-700 text-xs sm:text-sm font-semibold transition-all disabled:opacity-30 disabled:pointer-events-none active:scale-95 shadow-xs"
            title="تصفير عداد الذكر الحالي"
          >
            <RotateCcw className="w-3.5 h-3.5 text-stone-500" />
            <span>تصفير</span>
          </button>

          {/* Quick Target Select Buttons (in Free Mode) */}
          {mode === 'free' && (
            <div className="flex items-center bg-stone-100 dark:bg-stone-800 p-1 rounded-2xl border border-stone-200 dark:border-stone-700">
              {[33, 100, 0].map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => handleSetTarget(t)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    activeTarget === t
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100'
                  }`}
                >
                  {t === 0 ? 'حر ∞' : formatNum(t)}
                </button>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* Preset Adhkar Horizontal Grid */}
      {mode === 'free' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h4 className="font-amiri text-lg font-bold text-stone-800 dark:text-stone-200 flex items-center gap-2">
              <span>اختر الذكر أو التسبيح</span>
              <span className="text-xs font-sans text-stone-500 font-normal">
                ({presets.length} أذكار متوفرة)
              </span>
            </h4>

            <button
              type="button"
              onClick={() => setShowAddModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-bold transition-all active:scale-95"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إضافة ذكر مخصص</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
            {presets.map((preset) => {
              const isSelected = preset.id === currentPreset.id;
              return (
                <div
                  key={preset.id}
                  onClick={() => handleSelectPreset(preset)}
                  className={`relative p-3.5 rounded-2xl border cursor-pointer select-none transition-all text-right group ${
                    isSelected
                      ? 'bg-emerald-50/80 dark:bg-emerald-950/60 border-emerald-500 ring-2 ring-emerald-500/30 shadow-xs'
                      : 'bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-800 hover:border-emerald-300 dark:hover:border-emerald-800'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <span className="font-amiri text-base font-bold text-emerald-950 dark:text-emerald-100 line-clamp-2">
                      {preset.title}
                    </span>
                    {isSelected && (
                      <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-2 text-[11px] text-stone-500 dark:text-stone-400 mt-2">
                    <span className="font-mono">
                      الهدف: {preset.target > 0 ? `${formatNum(preset.target)} مرة` : 'مفتوح ∞'}
                    </span>

                    {preset.isCustom && (
                      <button
                        type="button"
                        onClick={(e) => handleDeleteCustomDhikr(preset.id, e)}
                        className="text-rose-500 hover:text-rose-700 p-1 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors"
                        title="حذف الذكر المخصص"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tasbih Statistics & Daily Progress Card */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-3xl p-4 sm:p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4 border-b border-stone-100 dark:border-stone-800 pb-3">
          <h4 className="font-amiri text-base sm:text-lg font-bold text-stone-800 dark:text-stone-200 flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-500" />
            <span>إحصائيات التسبيح والذكر</span>
          </h4>

          <span className="text-xs text-stone-400 font-mono">
            {stats.todayDate}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2 sm:gap-4 text-center">
          <div className="p-3 sm:p-4 rounded-2xl bg-stone-50 dark:bg-stone-800/60 border border-stone-200/60 dark:border-stone-750">
            <span className="text-[11px] sm:text-xs text-stone-500 dark:text-stone-400 font-medium block mb-1">
              تسبيحات اليوم
            </span>
            <span className="font-mono text-xl sm:text-3xl font-extrabold text-emerald-800 dark:text-emerald-300">
              {formatNum(stats.todayTotal)}
            </span>
          </div>

          <div className="p-3 sm:p-4 rounded-2xl bg-stone-50 dark:bg-stone-800/60 border border-stone-200/60 dark:border-stone-750">
            <span className="text-[11px] sm:text-xs text-stone-500 dark:text-stone-400 font-medium block mb-1">
              الدورات المكتملة
            </span>
            <span className="font-mono text-xl sm:text-3xl font-extrabold text-amber-700 dark:text-amber-300">
              {formatNum(stats.totalRounds)}
            </span>
          </div>

          <div className="p-3 sm:p-4 rounded-2xl bg-stone-50 dark:bg-stone-800/60 border border-stone-200/60 dark:border-stone-750">
            <span className="text-[11px] sm:text-xs text-stone-500 dark:text-stone-400 font-medium block mb-1">
              الإجمالي الكلي
            </span>
            <span className="font-mono text-xl sm:text-3xl font-extrabold text-stone-800 dark:text-stone-100">
              {formatNum(stats.allTimeTotal)}
            </span>
          </div>
        </div>
      </div>

      {/* Full-Screen Tap Overlay (وضع ملء الشاشة للتسبيح الحر) */}
      {isFullScreenTap && (
        <div 
          onClick={handleTap}
          className="fixed inset-0 z-50 bg-stone-950/95 text-white flex flex-col items-center justify-between p-6 select-none cursor-pointer animate-in fade-in"
          dir="rtl"
        >
          {/* Top Bar inside Full Screen */}
          <div className="w-full flex items-center justify-between" onClick={(e) => e.stopPropagation()}>
            <span className="text-xs text-emerald-400 font-bold bg-emerald-950/80 px-3 py-1 rounded-full border border-emerald-800">
              انقر في أي مكان على الشاشة للتسبيح
            </span>

            <button
              type="button"
              onClick={() => setIsFullScreenTap(false)}
              className="p-2 rounded-xl bg-stone-900 hover:bg-stone-800 border border-stone-800 text-stone-300 text-xs font-semibold"
            >
              إغلاق ملء الشاشة ✕
            </button>
          </div>

          {/* Center Display */}
          <div className="text-center space-y-4 my-auto">
            <h2 className="font-amiri text-3xl sm:text-5xl font-bold text-emerald-200 leading-relaxed max-w-lg mx-auto">
              {activeTitle}
            </h2>

            <div className="font-mono text-7xl sm:text-9xl font-extrabold text-white tracking-tight drop-shadow-lg">
              {formatNum(count)}
            </div>

            <div className="text-sm text-stone-400 font-mono">
              الهدف: {activeTarget > 0 ? `${formatNum(activeTarget)} • دورة ${formatNum(completedRounds)}` : 'مفتوح ∞'}
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="w-full flex items-center justify-center gap-4 text-xs text-stone-500" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              onClick={handleResetCount}
              className="px-4 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-300"
            >
              تصفير العداد
            </button>
          </div>
        </div>
      )}

      {/* Add Custom Dhikr Modal */}
      {showAddModal && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs"
          dir="rtl"
        >
          <div 
            className="w-full max-w-md bg-white dark:bg-stone-900 rounded-3xl p-5 sm:p-6 shadow-2xl border border-stone-200 dark:border-stone-800 space-y-4 animate-in zoom-in-95"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-stone-100 dark:border-stone-800 pb-3">
              <h3 className="font-amiri text-xl font-bold text-emerald-950 dark:text-emerald-100">
                إضافة ذكر مخصص للسبحة
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveCustomDhikr} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  نص الذكر أو التسبيح *
                </label>
                <input
                  type="text"
                  required
                  value={newDhikrTitle}
                  onChange={(e) => setNewDhikrTitle(e.target.value)}
                  placeholder="مثال: سبحان الله وبحمده"
                  className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-900 dark:text-stone-100 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  الهدف المخصص (عدد المرات)
                </label>
                <div className="flex items-center gap-2">
                  {[33, 100, 500, 1000].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setNewDhikrTarget(num)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                        newDhikrTarget === num
                          ? 'bg-emerald-600 text-white border-emerald-700'
                          : 'bg-stone-50 dark:bg-stone-800 text-stone-700 dark:text-stone-300 border-stone-200 dark:border-stone-700'
                      }`}
                    >
                      {formatNum(num)}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  فضل الذكر أو ملاحظة (اختياري)
                </label>
                <input
                  type="text"
                  value={newDhikrVirtue}
                  onChange={(e) => setNewDhikrVirtue(e.target.value)}
                  placeholder="مثال: غراس الجنة وتكفير الخطايا"
                  className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-900 dark:text-stone-100 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-xs transition-colors"
                >
                  حفظ والبدء بالتسبيح
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 font-semibold text-sm transition-colors"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
