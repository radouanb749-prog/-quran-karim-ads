import rawDivisions from './quran-divisions.json';

export type QuranDivisionType = 'juz' | 'hizb' | 'hizbHalf' | 'hizbQuarter' | 'hizbEighth';

export interface QuranDivisionMarker {
  id: string;
  globalEighthIndex: number; // 1 to 480
  surahNumber: number;
  verseNumber: number;
  juzNumber: number; // 1 to 30
  hizbNumber: number; // 1 to 60
  eighthInHizb: number; // 1 to 8
  quarterInHizb: number | null; // 1 to 4 if quarter/half/hizb, else null
  type: QuranDivisionType;
  name: string; // e.g. "الجزء 3 • الحزب 5" or "نصف الحزب 5"
  shortName: string; // e.g. "نصف الحزب"
  badge: string; // e.g. "½ حزب" or "الجزء 3"
  mathFraction: string; // e.g. "أربعة أثمان (½ حزب)"
  startTextPreview?: string;
}

export interface SajdaMarker {
  index: number;
  surahNumber: number;
  verseNumber: number;
  type: 'obligatory' | 'recommended';
  name: string;
}

export const QURAN_DIVISIONS: QuranDivisionMarker[] = rawDivisions as QuranDivisionMarker[];

export const SAJDA_MARKERS: SajdaMarker[] = [
  { index: 1, surahNumber: 7, verseNumber: 206, type: 'recommended', name: 'سجدة تلاوة' },
  { index: 2, surahNumber: 13, verseNumber: 15, type: 'recommended', name: 'سجدة تلاوة' },
  { index: 3, surahNumber: 16, verseNumber: 50, type: 'recommended', name: 'سجدة تلاوة' },
  { index: 4, surahNumber: 17, verseNumber: 109, type: 'recommended', name: 'سجدة تلاوة' },
  { index: 5, surahNumber: 19, verseNumber: 58, type: 'recommended', name: 'سجدة تلاوة' },
  { index: 6, surahNumber: 22, verseNumber: 18, type: 'recommended', name: 'سجدة تلاوة' },
  { index: 7, surahNumber: 22, verseNumber: 77, type: 'recommended', name: 'سجدة تلاوة' },
  { index: 8, surahNumber: 25, verseNumber: 60, type: 'recommended', name: 'سجدة تلاوة' },
  { index: 9, surahNumber: 27, verseNumber: 26, type: 'recommended', name: 'سجدة تلاوة' },
  { index: 10, surahNumber: 32, verseNumber: 15, type: 'obligatory', name: 'سجدة تلاوة واجبة' },
  { index: 11, surahNumber: 38, verseNumber: 24, type: 'recommended', name: 'سجدة تلاوة' },
  { index: 12, surahNumber: 41, verseNumber: 38, type: 'obligatory', name: 'سجدة تلاوة واجبة' },
  { index: 13, surahNumber: 53, verseNumber: 62, type: 'obligatory', name: 'سجدة تلاوة واجبة' },
  { index: 14, surahNumber: 84, verseNumber: 21, type: 'recommended', name: 'سجدة تلاوة' },
  { index: 15, surahNumber: 96, verseNumber: 19, type: 'obligatory', name: 'سجدة تلاوة واجبة' }
];
