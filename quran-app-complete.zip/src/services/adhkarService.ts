import { DhikrItem, DEFAULT_ADHKAR } from '../data/adhkar';

const FAVORITES_KEY = 'mushaf_favorite_adhkar_ids';
const CUSTOM_ADHKAR_KEY = 'mushaf_custom_user_adhkar';
const COUNTERS_KEY = 'mushaf_adhkar_counters';
const COUNTER_DATE_KEY = 'mushaf_adhkar_counters_date';

// -------------------------------------------------------------
// 1. Favorites Management
// -------------------------------------------------------------

export function getFavoriteDhikrIds(): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(FAVORITES_KEY);
    if (!raw) {
      // Default initial favorites: Ayatul Kursi (m-1), Sayyid al-Istighfar (m-6), Tasbeeh (p-4)
      const defaults = ['m-1', 'm-6', 'p-4'];
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(defaults));
      return defaults;
    }
    return JSON.parse(raw);
  } catch {
    return ['m-1', 'm-6', 'p-4'];
  }
}

export function isDhikrFavorite(id: string): boolean {
  const favs = getFavoriteDhikrIds();
  return favs.includes(id);
}

export function toggleFavoriteDhikr(id: string): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const favs = getFavoriteDhikrIds();
    let updated: string[];
    let isNowFav: boolean;

    if (favs.includes(id)) {
      updated = favs.filter((item) => item !== id);
      isNowFav = false;
    } else {
      updated = [...favs, id];
      isNowFav = true;
    }

    localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
    return isNowFav;
  } catch {
    return false;
  }
}

// -------------------------------------------------------------
// 2. Custom User Adhkar
// -------------------------------------------------------------

export function getCustomAdhkar(): DhikrItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(CUSTOM_ADHKAR_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function addCustomDhikr(dhikr: {
  title: string;
  text: string;
  count: number;
  fadl?: string;
  category?: 'morning' | 'evening' | 'after_prayer' | 'custom';
}): DhikrItem {
  const customs = getCustomAdhkar();
  const newId = `custom-${Date.now()}`;
  const newItem: DhikrItem = {
    id: newId,
    category: dhikr.category || 'custom',
    categoryName: dhikr.category === 'morning' ? 'أذكار الصباح' : 
                  dhikr.category === 'evening' ? 'أذكار المساء' :
                  dhikr.category === 'after_prayer' ? 'أذكار بعد الصلاة' : 'أذكار خاصة',
    title: dhikr.title.trim() || 'ذكر مبارك',
    text: dhikr.text.trim(),
    count: Math.max(1, dhikr.count || 1),
    fadl: dhikr.fadl?.trim(),
    isCustom: true,
    order: 1000 + customs.length,
  };

  const updated = [newItem, ...customs];
  try {
    localStorage.setItem(CUSTOM_ADHKAR_KEY, JSON.stringify(updated));
    // Automatically favorite custom added dhikr so user can see it right in favorites
    const favs = getFavoriteDhikrIds();
    if (!favs.includes(newId)) {
      localStorage.setItem(FAVORITES_KEY, JSON.stringify([...favs, newId]));
    }
  } catch (e) {
    console.error('Failed to save custom dhikr', e);
  }

  return newItem;
}

export function deleteCustomDhikr(id: string): void {
  const customs = getCustomAdhkar();
  const updated = customs.filter((c) => c.id !== id);
  try {
    localStorage.setItem(CUSTOM_ADHKAR_KEY, JSON.stringify(updated));
    // Also remove from favorites if present
    const favs = getFavoriteDhikrIds();
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favs.filter((f) => f !== id)));
  } catch (e) {
    console.error('Failed to delete custom dhikr', e);
  }
}

// -------------------------------------------------------------
// 3. Combined Adhkar Retrieval
// -------------------------------------------------------------

export function getAllAdhkar(): DhikrItem[] {
  const custom = getCustomAdhkar();
  return [...DEFAULT_ADHKAR, ...custom];
}

// -------------------------------------------------------------
// 4. Repetition Progress / Masbaha Counter
// -------------------------------------------------------------

function getTodayString(): string {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export function getDhikrCounters(): Record<string, number> {
  if (typeof window === 'undefined') return {};
  try {
    const today = getTodayString();
    const storedDate = localStorage.getItem(COUNTER_DATE_KEY);

    // If day changed, optionally keep or reset counters.
    // For convenience of daily adhkar, reset if new day
    if (storedDate !== today) {
      localStorage.setItem(COUNTER_DATE_KEY, today);
      localStorage.removeItem(COUNTERS_KEY);
      return {};
    }

    const raw = localStorage.getItem(COUNTERS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function incrementDhikrCount(id: string, maxCount: number): number {
  if (typeof window === 'undefined') return 0;
  try {
    const counters = getDhikrCounters();
    const current = counters[id] || 0;
    const next = current + 1;
    counters[id] = next;
    localStorage.setItem(COUNTERS_KEY, JSON.stringify(counters));
    return next;
  } catch {
    return 0;
  }
}

export function resetDhikrCount(id: string): void {
  if (typeof window === 'undefined') return;
  try {
    const counters = getDhikrCounters();
    delete counters[id];
    localStorage.setItem(COUNTERS_KEY, JSON.stringify(counters));
  } catch {
    // Ignore error
  }
}

export function resetAllCounters(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(COUNTERS_KEY);
  } catch {
    // Ignore error
  }
}
