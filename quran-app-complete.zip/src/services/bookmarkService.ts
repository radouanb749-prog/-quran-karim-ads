/**
 * Service to manage per-surah reading bookmarks (surah number -> last verse stopped at)
 * and global last read position.
 */

export interface ReadingProgress {
  surahNumber: number;
  verseNumber: number;
  timestamp: number;
}

const STORAGE_KEY_MAP = 'mushaf_surah_verses_progress';
const STORAGE_KEY_GLOBAL = 'mushaf_last_read_progress';

/**
 * Get the saved verse progress map for all surahs { [surahNumber]: verseNumber }
 */
export function getAllSurahProgress(): Record<number, number> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY_MAP);
    if (!raw) return {};
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

/**
 * Get the last read verse for a specific surah
 */
export function getSurahSavedVerse(surahNumber: number): number | null {
  const map = getAllSurahProgress();
  return map[surahNumber] || null;
}

/**
 * Save the verse the user stopped at in a specific surah
 */
export function saveSurahProgress(surahNumber: number, verseNumber: number): void {
  if (typeof window === 'undefined') return;
  try {
    const map = getAllSurahProgress();
    map[surahNumber] = verseNumber;
    localStorage.setItem(STORAGE_KEY_MAP, JSON.stringify(map));

    // Also update global last read
    const globalProgress: ReadingProgress = {
      surahNumber,
      verseNumber,
      timestamp: Date.now(),
    };
    localStorage.setItem(STORAGE_KEY_GLOBAL, JSON.stringify(globalProgress));
    localStorage.setItem('mushaf_last_read', surahNumber.toString());
  } catch {
    // ignore localStorage errors (e.g. quota)
  }
}

/**
 * Get global last read position including verse
 */
export function getGlobalLastRead(): ReadingProgress | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_GLOBAL);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.surahNumber === 'number' && typeof parsed.verseNumber === 'number') {
        return parsed;
      }
    }
    // Fallback to old format
    const oldSurah = localStorage.getItem('mushaf_last_read');
    if (oldSurah) {
      const sNum = parseInt(oldSurah, 10);
      if (!isNaN(sNum)) {
        return {
          surahNumber: sNum,
          verseNumber: 1,
          timestamp: Date.now(),
        };
      }
    }
  } catch {
    // fallback
  }
  return null;
}
