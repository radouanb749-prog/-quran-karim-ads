import { 
  QURAN_DIVISIONS, 
  QuranDivisionMarker, 
  QuranDivisionType,
  SAJDA_MARKERS,
  SajdaMarker 
} from '../data/quranDivisions';

// Fast lookup maps
const verseDivisionMap = new Map<string, QuranDivisionMarker>();
const surahDivisionsMap = new Map<number, QuranDivisionMarker[]>();

// Populate maps
for (const div of QURAN_DIVISIONS) {
  const key = `${div.surahNumber}:${div.verseNumber}`;
  verseDivisionMap.set(key, div);

  const existing = surahDivisionsMap.get(div.surahNumber) || [];
  existing.push(div);
  surahDivisionsMap.set(div.surahNumber, existing);
}

// Ensure each surah's divisions are sorted by verseNumber
for (const [surahNum, list] of surahDivisionsMap.entries()) {
  list.sort((a, b) => a.verseNumber - b.verseNumber);
}

// Sajda lookup map
const verseSajdaMap = new Map<string, SajdaMarker>();
const surahSajdaMap = new Map<number, SajdaMarker[]>();

for (const sajda of SAJDA_MARKERS) {
  const key = `${sajda.surahNumber}:${sajda.verseNumber}`;
  verseSajdaMap.set(key, sajda);

  const existing = surahSajdaMap.get(sajda.surahNumber) || [];
  existing.push(sajda);
  surahSajdaMap.set(sajda.surahNumber, existing);
}

/**
 * Returns all division markers within a specific Surah
 */
export function getSurahDivisions(surahNumber: number): QuranDivisionMarker[] {
  return surahDivisionsMap.get(surahNumber) || [];
}

/**
 * Checks if a specific verse has a division marker starting at it
 */
export function getVerseDivision(surahNumber: number, verseNumber: number): QuranDivisionMarker | undefined {
  return verseDivisionMap.get(`${surahNumber}:${verseNumber}`);
}

/**
 * Checks if a specific verse is a Sajda verse
 */
export function getVerseSajda(surahNumber: number, verseNumber: number): SajdaMarker | undefined {
  return verseSajdaMap.get(`${surahNumber}:${verseNumber}`);
}

/**
 * Retrieves the currently active division for a given surah and verse
 * (finds the division that spans this position)
 */
export function getActiveDivisionForPosition(
  surahNumber: number, 
  verseNumber: number
): QuranDivisionMarker | undefined {
  // Find all divisions up to this surah & verse
  for (let i = QURAN_DIVISIONS.length - 1; i >= 0; i--) {
    const div = QURAN_DIVISIONS[i];
    if (
      div.surahNumber < surahNumber || 
      (div.surahNumber === surahNumber && div.verseNumber <= verseNumber)
    ) {
      return div;
    }
  }
  return QURAN_DIVISIONS[0];
}

/**
 * Formatted title for displaying in notifications and ribbons
 */
export function formatDivisionTitle(marker: QuranDivisionMarker): string {
  switch (marker.type) {
    case 'juz':
      return `الجزء ${marker.juzNumber.toLocaleString('ar-EG')} • الحزب ${marker.hizbNumber.toLocaleString('ar-EG')}`;
    case 'hizb':
      return `الحزب ${marker.hizbNumber.toLocaleString('ar-EG')}`;
    case 'hizbHalf':
      return `نصف الحزب ${marker.hizbNumber.toLocaleString('ar-EG')}`;
    case 'hizbQuarter':
      return marker.eighthInHizb === 3
        ? `ربع الحزب ${marker.hizbNumber.toLocaleString('ar-EG')}`
        : `ثلاثة أرباع الحزب ${marker.hizbNumber.toLocaleString('ar-EG')}`;
    case 'hizbEighth':
      if (marker.eighthInHizb === 2) {
        return `ثُمن الحزب ${marker.hizbNumber.toLocaleString('ar-EG')}`;
      } else if (marker.eighthInHizb === 4) {
        return `ثلاثة أثمان الحزب ${marker.hizbNumber.toLocaleString('ar-EG')}`;
      } else if (marker.eighthInHizb === 6) {
        return `خمسة أثمان الحزب ${marker.hizbNumber.toLocaleString('ar-EG')}`;
      } else {
        return `سبعة أثمان الحزب ${marker.hizbNumber.toLocaleString('ar-EG')}`;
      }
    default:
      return marker.name;
  }
}
