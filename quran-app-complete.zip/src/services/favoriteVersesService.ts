export interface FavoriteVerse {
  id: string; // `${surahNumber}:${verseNumber}`
  surahNumber: number;
  surahName: string;
  verseNumber: number;
  verseText: string;
  juz?: number;
  page?: number;
  addedAt: number;
}

const STORAGE_KEY = 'mushaf_favorite_verses';
const EVENT_NAME = 'mushaf_favorite_verses_changed';

function dispatchChangeEvent() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(EVENT_NAME));
  }
}

export function getFavoriteVerses(): FavoriteVerse[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function isVerseFavorite(surahNumber: number, verseNumber: number): boolean {
  const list = getFavoriteVerses();
  const id = `${surahNumber}:${verseNumber}`;
  return list.some((item) => item.id === id);
}

export function toggleFavoriteVerse(data: {
  surahNumber: number;
  surahName: string;
  verseNumber: number;
  verseText: string;
  juz?: number;
  page?: number;
}): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const list = getFavoriteVerses();
    const id = `${data.surahNumber}:${data.verseNumber}`;
    const exists = list.some((item) => item.id === id);

    let updated: FavoriteVerse[];
    let isNowFavorite: boolean;

    if (exists) {
      updated = list.filter((item) => item.id !== id);
      isNowFavorite = false;
    } else {
      const newItem: FavoriteVerse = {
        id,
        surahNumber: data.surahNumber,
        surahName: data.surahName,
        verseNumber: data.verseNumber,
        verseText: data.verseText,
        juz: data.juz,
        page: data.page,
        addedAt: Date.now(),
      };
      // Prepend newest favorites at top
      updated = [newItem, ...list];
      isNowFavorite = true;
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    dispatchChangeEvent();
    return isNowFavorite;
  } catch {
    return false;
  }
}

export function removeFavoriteVerse(surahNumber: number, verseNumber: number): void {
  if (typeof window === 'undefined') return;
  try {
    const list = getFavoriteVerses();
    const id = `${surahNumber}:${verseNumber}`;
    const updated = list.filter((item) => item.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    dispatchChangeEvent();
  } catch {
    // Ignore error
  }
}

export function clearAllFavoriteVerses(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(STORAGE_KEY);
    dispatchChangeEvent();
  } catch {
    // Ignore error
  }
}

export function subscribeToFavoriteVersesChange(callback: () => void): () => void {
  if (typeof window === 'undefined') return () => {};
  window.addEventListener(EVENT_NAME, callback);
  window.addEventListener('storage', callback);
  return () => {
    window.removeEventListener(EVENT_NAME, callback);
    window.removeEventListener('storage', callback);
  };
}
