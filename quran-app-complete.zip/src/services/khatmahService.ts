import { SURAHS, Surah } from '../data/surahs';

export interface KhatmahPlan {
  id: string;
  title: string;
  durationDays: number;
  startDate: string; // ISO string YYYY-MM-DD
  targetEndDate: string; // ISO string YYYY-MM-DD
  startPage: number; // default 1
  endPage: number; // default 604
  completedDays: Record<number, boolean>; // dayNumber (1-indexed) -> boolean
  lastReadPage: number; // current reading progress page (1 to 604)
  createdAt: number;
  status: 'active' | 'completed' | 'paused';
}

export interface DayWardInfo {
  dayNumber: number;
  startPage: number;
  endPage: number;
  pagesCount: number;
  surahs: { number: number; name: string }[];
  approxJuz: number;
  isCompleted: boolean;
  isToday: boolean;
}

export interface KhatmahStats {
  totalPages: number;
  readPages: number;
  pagesRemaining: number;
  completionPercentage: number;
  currentDay: number;
  totalDays: number;
  daysRemaining: number;
  completedDaysCount: number;
  todayWard: DayWardInfo;
  paceStatus: 'ahead' | 'on_track' | 'behind';
  pagesAheadBehind: number;
  estimatedCompletionDate: string;
  surahsCompletedCount: number;
  juzCompletedCount: number;
}

const STORAGE_KEY_PLAN = 'mushaf_khatmah_plan_active';
const STORAGE_KEY_HISTORY = 'mushaf_khatmah_history';
const EVENT_KHATMAH_CHANGED = 'mushaf_khatmah_changed';

export const TOTAL_QURAN_PAGES = 604;
export const TOTAL_QURAN_JUZ = 30;
export const TOTAL_QURAN_SURAHS = 114;
export const TOTAL_QURAN_AYAHS = 6236;

function dispatchChangeEvent() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(EVENT_KHATMAH_CHANGED));
  }
}

/**
 * Format a Date to YYYY-MM-DD
 */
export function formatDateISO(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Add days to a date string YYYY-MM-DD
 */
export function addDaysToDate(dateStr: string, days: number): string {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return formatDateISO(d);
}

/**
 * Calculate difference in days between two date strings (date2 - date1)
 */
export function diffInDays(dateStr1: string, dateStr2: string): number {
  const d1 = new Date(dateStr1);
  const d2 = new Date(dateStr2);
  const diffTime = d2.getTime() - d1.getTime();
  return Math.floor(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Find all Surahs that touch a range of pages [startPage, endPage]
 */
export function getSurahsForPageRange(startPage: number, endPage: number): { number: number; name: string }[] {
  const matched: { number: number; name: string }[] = [];

  for (let i = 0; i < SURAHS.length; i++) {
    const surah = SURAHS[i];
    const nextSurah = SURAHS[i + 1];
    const surahStart = surah.page;
    // Surah ends at the page before the next surah, or page 604 for An-Nas
    const surahEnd = nextSurah ? nextSurah.page : TOTAL_QURAN_PAGES;

    // Check intersection [surahStart, surahEnd] and [startPage, endPage]
    if (Math.max(surahStart, startPage) <= Math.min(surahEnd, endPage)) {
      matched.push({ number: surah.number, name: surah.name });
    }
  }

  return matched;
}

/**
 * Find the primary Surah starting at or closest to a page
 */
export function getPrimarySurahForPage(page: number): Surah {
  let closest = SURAHS[0];
  for (const surah of SURAHS) {
    if (surah.page <= page) {
      closest = surah;
    } else {
      break;
    }
  }
  return closest;
}

/**
 * Calculate the ward range for a given day in a plan
 */
export function calculateDayWard(
  dayNumber: number,
  durationDays: number,
  startPage: number = 1,
  endPage: number = TOTAL_QURAN_PAGES,
  completedDays: Record<number, boolean> = {},
  currentDayIndex: number = 1
): DayWardInfo {
  const totalSpan = endPage - startPage + 1;
  const clampedDay = Math.max(1, Math.min(dayNumber, durationDays));

  // Balanced integer partitioning of pages across days
  const dayStart = startPage + Math.floor(((clampedDay - 1) * totalSpan) / durationDays);
  const dayEnd = Math.min(endPage, startPage + Math.floor((clampedDay * totalSpan) / durationDays) - 1);
  const actualEnd = Math.max(dayStart, dayEnd);
  const pagesCount = actualEnd - dayStart + 1;

  // Approximate Juz: each Juz is ~20 pages
  const approxJuz = Math.min(30, Math.max(1, Math.ceil(dayStart / 20)));
  const surahs = getSurahsForPageRange(dayStart, actualEnd);

  return {
    dayNumber: clampedDay,
    startPage: dayStart,
    endPage: actualEnd,
    pagesCount,
    surahs,
    approxJuz,
    isCompleted: !!completedDays[clampedDay],
    isToday: clampedDay === currentDayIndex,
  };
}

/**
 * Create a default 30-day Khatmah plan
 */
export function createDefaultPlan(durationDays: number = 30, title: string = 'ختمة الشهر الفضيل'): KhatmahPlan {
  const today = formatDateISO(new Date());
  return {
    id: `khatmah-${Date.now()}`,
    title,
    durationDays,
    startDate: today,
    targetEndDate: addDaysToDate(today, durationDays),
    startPage: 1,
    endPage: TOTAL_QURAN_PAGES,
    completedDays: {},
    lastReadPage: 1,
    createdAt: Date.now(),
    status: 'active',
  };
}

/**
 * Get active Khatmah plan from storage (or initialize default)
 */
export function getActiveKhatmahPlan(): KhatmahPlan {
  if (typeof window === 'undefined') return createDefaultPlan();
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PLAN);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.durationDays === 'number') {
        return parsed;
      }
    }
    const def = createDefaultPlan();
    localStorage.setItem(STORAGE_KEY_PLAN, JSON.stringify(def));
    return def;
  } catch {
    return createDefaultPlan();
  }
}

/**
 * Save / Update Khatmah plan
 */
export function saveKhatmahPlan(plan: KhatmahPlan): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_PLAN, JSON.stringify(plan));
    dispatchChangeEvent();
  } catch (e) {
    console.error('Failed to save khatmah plan', e);
  }
}

/**
 * Toggle completion status for a specific day in the plan
 */
export function toggleDayCompleted(dayNumber: number): KhatmahPlan {
  const plan = getActiveKhatmahPlan();
  const current = !!plan.completedDays[dayNumber];
  const nextCompleted = !current;

  plan.completedDays = {
    ...plan.completedDays,
    [dayNumber]: nextCompleted,
  };

  // If marked as completed, update lastReadPage if higher
  if (nextCompleted) {
    const ward = calculateDayWard(dayNumber, plan.durationDays, plan.startPage, plan.endPage);
    if (ward.endPage > plan.lastReadPage) {
      plan.lastReadPage = ward.endPage;
    }
  }

  // Check if all days completed
  let allDone = true;
  for (let d = 1; d <= plan.durationDays; d++) {
    if (!plan.completedDays[d]) {
      allDone = false;
      break;
    }
  }

  if (allDone) {
    plan.status = 'completed';
  } else if (plan.status === 'completed') {
    plan.status = 'active';
  }

  saveKhatmahPlan(plan);
  return plan;
}

/**
 * Update current reading page and automatically sync with Khatmah days
 */
export function updateKhatmahProgressPage(pageNumber: number): void {
  const plan = getActiveKhatmahPlan();
  if (pageNumber > plan.lastReadPage) {
    plan.lastReadPage = Math.min(TOTAL_QURAN_PAGES, pageNumber);

    // Auto mark earlier days whose ward has been read
    for (let d = 1; d <= plan.durationDays; d++) {
      const ward = calculateDayWard(d, plan.durationDays, plan.startPage, plan.endPage);
      if (plan.lastReadPage >= ward.endPage) {
        plan.completedDays[d] = true;
      }
    }

    saveKhatmahPlan(plan);
  }
}

/**
 * Reset current Khatmah plan or initialize new one
 */
export function resetKhatmahPlan(durationDays: number = 30, title?: string, startPage: number = 1): KhatmahPlan {
  const newPlan = createDefaultPlan(durationDays, title || `ختمة (${durationDays} يوماً)`);
  newPlan.startPage = startPage;
  newPlan.lastReadPage = startPage;
  saveKhatmahPlan(newPlan);
  return newPlan;
}

/**
 * Calculate full analytics and stats for the active Khatmah
 */
export function getKhatmahStats(plan: KhatmahPlan): KhatmahStats {
  const todayStr = formatDateISO(new Date());
  const elapsedDays = Math.max(0, diffInDays(plan.startDate, todayStr));
  // currentDay is 1-indexed (Day 1 on the start date)
  const currentDay = Math.min(plan.durationDays, Math.max(1, elapsedDays + 1));
  const daysRemaining = Math.max(0, plan.durationDays - currentDay + 1);

  // Completed days count
  const completedDaysCount = Object.values(plan.completedDays).filter(Boolean).length;

  // Pages read calculation: based on highest of (completed days' pages) or (plan.lastReadPage)
  let maxCompletedPage = plan.lastReadPage || 1;
  for (let d = 1; d <= plan.durationDays; d++) {
    if (plan.completedDays[d]) {
      const ward = calculateDayWard(d, plan.durationDays, plan.startPage, plan.endPage);
      if (ward.endPage > maxCompletedPage) {
        maxCompletedPage = ward.endPage;
      }
    }
  }

  const readPages = Math.min(TOTAL_QURAN_PAGES, maxCompletedPage);
  const pagesRemaining = Math.max(0, TOTAL_QURAN_PAGES - readPages);
  const completionPercentage = Math.min(100, Math.round((readPages / TOTAL_QURAN_PAGES) * 100));

  // Target expected page for today
  const expectedWardForToday = calculateDayWard(currentDay, plan.durationDays, plan.startPage, plan.endPage);
  const expectedPageToday = expectedWardForToday.endPage;
  const pageDiff = readPages - expectedPageToday;

  let paceStatus: 'ahead' | 'on_track' | 'behind' = 'on_track';
  if (pageDiff > 5) {
    paceStatus = 'ahead';
  } else if (pageDiff < -5) {
    paceStatus = 'behind';
  }

  // Estimated completion date based on actual reading speed
  const averagePagesPerDay = elapsedDays > 0 ? readPages / elapsedDays : 604 / plan.durationDays;
  const estimatedDaysLeft = averagePagesPerDay > 0 ? Math.ceil(pagesRemaining / averagePagesPerDay) : daysRemaining;
  const estimatedCompletionDate = addDaysToDate(todayStr, estimatedDaysLeft);

  // Surahs completed count: how many surahs ended before readPages
  let surahsCompletedCount = 0;
  for (let i = 0; i < SURAHS.length; i++) {
    const s = SURAHS[i];
    const next = SURAHS[i + 1];
    const end = next ? next.page - 1 : TOTAL_QURAN_PAGES;
    if (readPages >= end) {
      surahsCompletedCount++;
    }
  }

  // Completed Juz count
  const juzCompletedCount = Math.min(30, Math.floor(readPages / 20.13));

  const todayWard = calculateDayWard(
    currentDay,
    plan.durationDays,
    plan.startPage,
    plan.endPage,
    plan.completedDays,
    currentDay
  );

  return {
    totalPages: TOTAL_QURAN_PAGES,
    readPages,
    pagesRemaining,
    completionPercentage,
    currentDay,
    totalDays: plan.durationDays,
    daysRemaining,
    completedDaysCount,
    todayWard,
    paceStatus,
    pagesAheadBehind: Math.abs(pageDiff),
    estimatedCompletionDate,
    surahsCompletedCount,
    juzCompletedCount,
  };
}

/**
 * Subscribe to Khatmah plan changes
 */
export function subscribeToKhatmahChange(callback: () => void): () => void {
  if (typeof window === 'undefined') return () => {};
  window.addEventListener(EVENT_KHATMAH_CHANGED, callback);
  window.addEventListener('storage', callback);
  return () => {
    window.removeEventListener(EVENT_KHATMAH_CHANGED, callback);
    window.removeEventListener('storage', callback);
  };
}
