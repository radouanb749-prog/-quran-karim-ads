export interface Reciter {
  id: string;
  name: string;
  subName?: string;
  folder: string;
  surahServerUrl: string;
}

export const RECITERS: Reciter[] = [
  { 
    id: 'husary', 
    name: 'الشيخ محمود خليل الحصري', 
    subName: 'المصحف المرتل', 
    folder: 'Husary_128kbps',
    surahServerUrl: 'https://server13.mp3quran.net/husr/' 
  },
  { 
    id: 'alafasy', 
    name: 'الشيخ مشاري راشد العفاسي', 
    subName: 'حفص عن عاصم', 
    folder: 'Alafasy_128kbps',
    surahServerUrl: 'https://server8.mp3quran.net/afs/' 
  },
  { 
    id: 'abdulbasit', 
    name: 'عبد الباسط عبد الصمد', 
    subName: 'المصحف المرتل', 
    folder: 'Abdul_Basit_Murattal_192kbps',
    surahServerUrl: 'https://server7.mp3quran.net/basit/' 
  },
  { 
    id: 'minshawi', 
    name: 'محمد صديق المنشاوي', 
    subName: 'المصحف المرتل', 
    folder: 'Minshawy_Murattal_128kbps',
    surahServerUrl: 'https://server10.mp3quran.net/minsh/' 
  },
  { 
    id: 'ghamdi', 
    name: 'سعد الغامدي', 
    subName: 'حفص عن عاصم', 
    folder: 'Ghamadi_40kbps',
    surahServerUrl: 'https://server7.mp3quran.net/s_gmd/' 
  },
  { 
    id: 'muaiqly', 
    name: 'ماهر المعيقلي', 
    subName: 'حفص عن عاصم', 
    folder: 'MaherAlMuaiqly128kbps',
    surahServerUrl: 'https://server12.mp3quran.net/maher/' 
  },
  { 
    id: 'shatri', 
    name: 'أبو بكر الشاطري', 
    subName: 'حفص عن عاصم', 
    folder: 'Abu_Bakr_Ash-Shaatree_128kbps',
    surahServerUrl: 'https://server11.mp3quran.net/shatri/' 
  },
];

export type RepeatMode = 
  | 'none'           // تشغيل متتابع حتى نهاية السورة
  | 'verse_2x'       // تكرار الآية مرتين
  | 'verse_3x'       // تكرار الآية ٣ مرات
  | 'verse_5x'       // تكرار الآية ٥ مرات
  | 'verse_infinite' // تكرار الآية مستمر بلا نهاية (للحفظ)
  | 'surah';         // إعادة السورة كاملة عند انتهائها

export interface RepeatOption {
  mode: RepeatMode;
  label: string;
  badge: string;
  maxRepeats: number; // 0 for infinite, 1 for none, 2 for 2x, etc.
}

export const REPEAT_OPTIONS: RepeatOption[] = [
  { mode: 'none', label: 'بدون تكرار (تشغيل متتابع)', badge: 'متتابع', maxRepeats: 1 },
  { mode: 'verse_2x', label: 'تكرار الآية مرتين (٢)', badge: '٢x', maxRepeats: 2 },
  { mode: 'verse_3x', label: 'تكرار الآية ٣ مرات (للحفظ)', badge: '٣x', maxRepeats: 3 },
  { mode: 'verse_5x', label: 'تكرار الآية ٥ مرات (تثبيت الحفظ)', badge: '٥x', maxRepeats: 5 },
  { mode: 'verse_infinite', label: 'تكرار مستمر للآية الحالية', badge: '∞', maxRepeats: 0 },
  { mode: 'surah', label: 'إعادة السورة كاملة عند الانتهاء', badge: 'السورة', maxRepeats: 1 },
];

const STORAGE_KEY_RECITER = 'mushaf_selected_reciter';
const STORAGE_KEY_REPEAT = 'mushaf_repeat_mode';

/**
 * Format 3-digit number padded with zeros (e.g. 1 -> "001")
 */
export function pad3(num: number): string {
  return String(num).padStart(3, '0');
}

/**
 * Build EveryAyah direct MP3 URL for a specific verse and reciter
 */
export function getAyahAudioUrl(surahNumber: number, verseNumber: number, reciterFolder: string = 'Husary_128kbps'): string {
  const surahPadded = pad3(surahNumber);
  const versePadded = pad3(verseNumber);
  return `https://everyayah.com/data/${reciterFolder}/${surahPadded}${versePadded}.mp3`;
}

/**
 * Build direct MP3 URL for a complete Surah recitation
 */
export function getSurahAudioUrl(surahNumber: number, reciterId?: string): string {
  const reciter = reciterId ? RECITERS.find((r) => r.id === reciterId) : getSavedReciter();
  const activeReciter = reciter || RECITERS[0];
  const surahPadded = pad3(surahNumber);
  return `${activeReciter.surahServerUrl}${surahPadded}.mp3`;
}

/**
 * Get saved reciter or default to Mishary Alafasy
 */
export function getSavedReciter(): Reciter {
  if (typeof window === 'undefined') return RECITERS[0];
  try {
    const savedId = localStorage.getItem(STORAGE_KEY_RECITER);
    const found = RECITERS.find((r) => r.id === savedId);
    return found || RECITERS[0];
  } catch {
    return RECITERS[0];
  }
}

/**
 * Save selected reciter ID
 */
export function saveSelectedReciter(reciterId: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_RECITER, reciterId);
  } catch {
    // Ignore error
  }
}

/**
 * Get saved repeat mode
 */
export function getSavedRepeatMode(): RepeatMode {
  if (typeof window === 'undefined') return 'none';
  try {
    const saved = localStorage.getItem(STORAGE_KEY_REPEAT) as RepeatMode;
    const found = REPEAT_OPTIONS.some((r) => r.mode === saved);
    return found ? saved : 'none';
  } catch {
    return 'none';
  }
}

/**
 * Save repeat mode
 */
export function saveSelectedRepeatMode(mode: RepeatMode): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_REPEAT, mode);
  } catch {
    // Ignore error
  }
}
