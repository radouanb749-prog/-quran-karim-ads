import quranData from '../data/quran-data.json';

export interface Verse {
  number: number;
  text: string;
}

export type QuranMap = Record<string | number, Verse[]>;

const typedQuranData = quranData as unknown as Record<string, Verse[]>;

/**
 * Retrieves the authentic verses of a Surah by its number (1-114)
 * Source: Tanzil Quran Text (Uthmani, Version 1.1)
 */
export function getSurahVerses(surahNumber: number): Verse[] {
  const verses = typedQuranData[surahNumber.toString()];
  return verses || [];
}

/**
 * Total verses count in a Surah from the authentic source
 */
export function getSurahVersesCount(surahNumber: number): number {
  return typedQuranData[surahNumber.toString()]?.length || 0;
}
