export interface DailyWirdConfig {
  enabled: boolean;
  time: string; // "HH:MM" 24h format, e.g. "06:00"
  targetType: 'pages' | 'hizb' | 'juz' | 'custom';
  targetAmount: number; // e.g. 1 (hizb), 2 (pages), 1 (juz)
  customTitle: string; // e.g. "حزب كامل" or "صفحتان"
  notificationSound: boolean;
  browserNotifications: boolean;
  lastCompletedDate: string | null; // "YYYY-MM-DD"
  streakDays: number;
  lastDismissedDate: string | null; // "YYYY-MM-DD"
}

export const WIRD_STORAGE_KEY = 'mushaf_daily_wird_config';

export const DEFAULT_WIRD_CONFIG: DailyWirdConfig = {
  enabled: true,
  time: '06:30',
  targetType: 'hizb',
  targetAmount: 1,
  customTitle: 'حزب واحد يومياً',
  notificationSound: true,
  browserNotifications: false,
  lastCompletedDate: null,
  streakDays: 0,
  lastDismissedDate: null,
};

export const WIRD_PRESETS = [
  { id: 'fajr', label: 'بعد صلاة الفجر', time: '05:30', icon: '🌅' },
  { id: 'morning', label: 'الصباح الباكر', time: '07:30', icon: '☀️' },
  { id: 'dhuhr', label: 'بعد الظهر', time: '13:00', icon: '🌤️' },
  { id: 'asr', label: 'بعد العصر', time: '16:30', icon: '🌇' },
  { id: 'isha', label: 'المساء وقبل النوم', time: '21:30', icon: '🌙' },
];

export const TARGET_PRESETS = [
  { type: 'pages' as const, amount: 2, title: 'صفحتان (ورقة واحدة)', duration: '٥ دقائق' },
  { type: 'pages' as const, amount: 4, title: '٤ صفحات', duration: '١٠ دقائق' },
  { type: 'hizb' as const, amount: 0.5, title: 'نصف حزب', duration: '١٥ دقيقة' },
  { type: 'hizb' as const, amount: 1, title: 'حزب كامل', duration: '٣٠ دقيقة' },
  { type: 'juz' as const, amount: 1, title: 'جزء كامل', duration: 'ساعة تقريباً' },
];

/**
 * Returns current date string in YYYY-MM-DD format based on local time
 */
export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Formats a 24h time string (e.g. "17:30") to Arabic 12h format (e.g. "٠٥:٣٠ م")
 */
export function formatArabicTime(time24: string): string {
  if (!time24 || !time24.includes(':')) return time24;
  const [hStr, mStr] = time24.split(':');
  let h = parseInt(hStr, 10);
  const m = parseInt(mStr, 10);
  const isPM = h >= 12;
  
  if (h === 0) h = 12;
  else if (h > 12) h -= 12;

  const toArabicNums = (n: number) => n.toLocaleString('ar-EG', { minimumIntegerDigits: 2, useGrouping: false });
  const period = isPM ? 'م' : 'ص';
  return `${toArabicNums(h)}:${toArabicNums(m)} ${period}`;
}

/**
 * Loads the saved daily wird configuration from localStorage
 */
export function getDailyWirdConfig(): DailyWirdConfig {
  if (typeof window === 'undefined') return DEFAULT_WIRD_CONFIG;
  try {
    const raw = localStorage.getItem(WIRD_STORAGE_KEY);
    if (!raw) return DEFAULT_WIRD_CONFIG;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_WIRD_CONFIG, ...parsed };
  } catch (e) {
    console.error('Failed to load daily wird config', e);
    return DEFAULT_WIRD_CONFIG;
  }
}

/**
 * Saves the daily wird configuration to localStorage
 */
export function saveDailyWirdConfig(config: DailyWirdConfig): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(WIRD_STORAGE_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save daily wird config', e);
  }
}

/**
 * Checks if today's wird is marked completed
 */
export function isWirdCompletedToday(config: DailyWirdConfig): boolean {
  return config.lastCompletedDate === getTodayDateString();
}

/**
 * Checks if user dismissed the notification banner for today
 */
export function isWirdDismissedToday(config: DailyWirdConfig): boolean {
  return config.lastDismissedDate === getTodayDateString();
}

/**
 * Marks today's wird as completed, updating streak
 */
export function markWirdCompleted(): DailyWirdConfig {
  const current = getDailyWirdConfig();
  const today = getTodayDateString();

  if (current.lastCompletedDate === today) {
    return current; // already completed
  }

  // Calculate streak: check if yesterday was completed
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;

  let newStreak = 1;
  if (current.lastCompletedDate === yStr) {
    newStreak = (current.streakDays || 0) + 1;
  } else if (!current.lastCompletedDate) {
    newStreak = 1;
  }

  const updated: DailyWirdConfig = {
    ...current,
    lastCompletedDate: today,
    streakDays: newStreak,
    lastDismissedDate: null,
  };

  saveDailyWirdConfig(updated);
  return updated;
}

/**
 * Dismiss the notification banner for today
 */
export function dismissWirdForToday(): DailyWirdConfig {
  const current = getDailyWirdConfig();
  const today = getTodayDateString();
  const updated: DailyWirdConfig = {
    ...current,
    lastDismissedDate: today,
  };
  saveDailyWirdConfig(updated);
  return updated;
}

/**
 * Determines whether the reminder is currently due
 */
export function isReminderTimeReached(targetTime: string): boolean {
  if (!targetTime) return true;
  const now = new Date();
  const [hStr, mStr] = targetTime.split(':');
  const targetH = parseInt(hStr, 10);
  const targetM = parseInt(mStr, 10);
  
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const targetMinutes = targetH * 60 + targetM;

  // It is due if current time is past or at target time
  return currentMinutes >= targetMinutes;
}

/**
 * Play gentle dignified chime using Web Audio API
 */
export function playGentleChime(): void {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    
    // Smooth pleasant two-tone chime (E5 -> B5)
    const tones = [659.25, 987.77];
    tones.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.22);
      
      gain.gain.setValueAtTime(0, ctx.currentTime + idx * 0.22);
      gain.gain.linearRampToValueAtTime(0.12, ctx.currentTime + idx * 0.22 + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.22 + 0.7);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + idx * 0.22);
      osc.stop(ctx.currentTime + idx * 0.22 + 0.8);
    });
  } catch {
    // Ignore audio permission or context creation errors
  }
}

/**
 * Request browser notification permission
 */
export async function requestNotificationPermission(): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }
  try {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  } catch (e) {
    console.error('Error requesting notification permission', e);
    return false;
  }
}

/**
 * Send browser system notification if permitted
 */
export function sendBrowserNotification(title: string, body: string): void {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: '/app-logo.png',
        badge: '/favicon.png',
        dir: 'rtl',
        lang: 'ar',
      });
    } catch {
      // In case Notifications fail in certain browser restrictions
    }
  }
}
