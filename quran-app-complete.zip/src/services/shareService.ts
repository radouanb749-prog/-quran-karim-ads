export interface ShareOptions {
  title?: string;
  text?: string;
  url?: string;
}

export function getShareUrl(): string {
  if (typeof window !== 'undefined') {
    return window.location.origin || window.location.href;
  }
  return '';
}

export const APP_SHARE_INFO: ShareOptions = {
  title: 'القرآن الكريم',
  text: 'اقرأ القرآن الكريم برواية ورش',
};

/**
 * Triggers the Web Share API or invokes the fallback callback.
 * Silently catches any rejection without displaying errors.
 */
export async function executeShare(
  options: Partial<ShareOptions> = {},
  onFallback?: () => void
): Promise<boolean> {
  const title = options.title || APP_SHARE_INFO.title || 'القرآن الكريم';
  const text = options.text || APP_SHARE_INFO.text || 'اقرأ القرآن الكريم برواية ورش';
  const url = options.url || getShareUrl();

  const shareData = { title, text, url };

  if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
    try {
      if (navigator.canShare && !navigator.canShare(shareData)) {
        onFallback?.();
        return false;
      }
      await navigator.share(shareData);
      return true;
    } catch (err: unknown) {
      // User cancelled/aborted or platform doesn't allow iframe share
      if (err instanceof Error && err.name === 'AbortError') {
        // User voluntarily dismissed share sheet
        return false;
      }
      // If permission or other error, open fallback modal cleanly
      onFallback?.();
      return false;
    }
  } else {
    onFallback?.();
    return false;
  }
}
