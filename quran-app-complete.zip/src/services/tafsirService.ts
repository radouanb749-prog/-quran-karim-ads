export interface TafsirSource {
  id: number;
  slug: string;
  name: string;
  author: string;
  description: string;
}

export const TAFSIR_SOURCES: TafsirSource[] = [
  {
    id: 16,
    slug: 'muyassar',
    name: 'التفسير الميسر',
    author: 'مجمع الملك فهد لطباعة المصحف الشريف',
    description: 'تفسير موثق وسهل العبارة يبين معاني الآيات بإيجاز ودقة.',
  },
  {
    id: 91,
    slug: 'saadi',
    name: 'تفسير السعدي',
    author: 'الشيخ عبد الرحمن بن ناصر السعدي',
    description: 'تيسير الكريم الرحمن، أسلوب واضح خالٍ من الحشو والتعقيد.',
  },
  {
    id: 14,
    slug: 'ibn-kathir',
    name: 'تفسير ابن كثير',
    author: 'الحافظ عماد الدين ابن كثير',
    description: 'تفسير القرآن العظيم، من أشهر وأجلّ كتب التفسير بالمأثور.',
  },
];

const tafsirCache = new Map<string, string>();
const STORAGE_PREFIX = 'mushaf_tafsir_cache_';
const SELECTED_TAFSIR_KEY = 'mushaf_selected_tafsir_id';

/**
 * Strip harmful/malformed tags while preserving basic paragraph and emphasis
 */
export function cleanTafsirHtml(html: string): string {
  if (!html) return '';
  return html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
    .replace(/class="[^"]*"/gi, '')
    .replace(/style="[^"]*"/gi, '')
    .replace(/<span[^>]*>/gi, '')
    .replace(/<\/span>/gi, '')
    .trim();
}

/**
 * Get preferred tafsir source ID
 */
export function getSavedTafsirSourceId(): number {
  if (typeof window === 'undefined') return 16;
  try {
    const saved = localStorage.getItem(SELECTED_TAFSIR_KEY);
    if (saved) {
      const parsed = parseInt(saved, 10);
      if (TAFSIR_SOURCES.some((s) => s.id === parsed)) {
        return parsed;
      }
    }
    return 16;
  } catch {
    return 16;
  }
}

/**
 * Save preferred tafsir source ID
 */
export function saveTafsirSourceId(id: number): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(SELECTED_TAFSIR_KEY, id.toString());
  } catch {}
}

/**
 * Fetch Tafsir for a specific Ayah with fallback
 */
export async function getAyahTafsir(
  surahNumber: number,
  verseNumber: number,
  tafsirId: number = 16
): Promise<{ text: string; source: string }> {
  const cacheKey = `${tafsirId}_${surahNumber}_${verseNumber}`;

  // 1. Check in-memory cache
  if (tafsirCache.has(cacheKey)) {
    return {
      text: tafsirCache.get(cacheKey)!,
      source: TAFSIR_SOURCES.find((s) => s.id === tafsirId)?.name || 'التفسير الميسر',
    };
  }

  // 2. Check localStorage cache
  try {
    const localCached = localStorage.getItem(`${STORAGE_PREFIX}${cacheKey}`);
    if (localCached) {
      tafsirCache.set(cacheKey, localCached);
      return {
        text: localCached,
        source: TAFSIR_SOURCES.find((s) => s.id === tafsirId)?.name || 'التفسير الميسر',
      };
    }
  } catch {}

  // 3. Primary Request: Quran.com Tafsir API
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000);

    const response = await fetch(
      `https://api.quran.com/api/v4/tafsirs/${tafsirId}/by_ayah/${surahNumber}:${verseNumber}`,
      {
        signal: controller.signal,
        headers: {
          Accept: 'application/json',
        },
      }
    );
    clearTimeout(timeoutId);

    if (response.ok) {
      const data = await response.json();
      const rawText = data?.tafsir?.text;
      if (rawText && typeof rawText === 'string' && rawText.trim().length > 0) {
        const cleaned = cleanTafsirHtml(rawText);
        tafsirCache.set(cacheKey, cleaned);
        try {
          localStorage.setItem(`${STORAGE_PREFIX}${cacheKey}`, cleaned);
        } catch {}
        return {
          text: cleaned,
          source: data?.tafsir?.resource_name || TAFSIR_SOURCES.find((s) => s.id === tafsirId)?.name || 'التفسير',
        };
      }
    }
  } catch (e) {
    console.warn('Quran.com Tafsir fetch failed, attempting fallback...', e);
  }

  // 4. Fallback Request: QuranEnc (Arabic Moyassar)
  try {
    const fallbackResponse = await fetch(
      `https://quranenc.com/api/v1/translation/aya/arabic_moyassar/${surahNumber}/${verseNumber}`
    );
    if (fallbackResponse.ok) {
      const fallbackData = await fallbackResponse.json();
      const translation = fallbackData?.result?.translation;
      if (translation && typeof translation === 'string') {
        const cleaned = translation.trim();
        tafsirCache.set(cacheKey, cleaned);
        return {
          text: cleaned,
          source: 'التفسير الميسر (مجمع الملك فهد)',
        };
      }
    }
  } catch (err) {
    console.warn('QuranEnc fallback failed:', err);
  }

  throw new Error('تعذر تحميل التفسير في الوقت الحالي. يرجى التحقق من الاتصال بالإنترنت.');
}
