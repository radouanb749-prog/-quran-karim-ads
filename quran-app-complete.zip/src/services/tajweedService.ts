/**
 * Tajweed Rules Engine and Service
 * Implements standard Tajweed color coding (المصحف المجود الملون)
 * covering Madd, Ghunnah, Ikhfa, Idgham, Iqlab, Qalqalah, Tafkheem, and Silent letters.
 */

export type TajweedRuleId = 
  | 'madd_obligatory'     // مد لازم (6 حركات) - أحمر داكن
  | 'madd_permissible'    // مد متصل ومنفصل وصلة كبرى (4-5 حركات) - برتقالي محمر
  | 'madd_normal'         // مد طبيعي وبدل وصلة صغرى (حركتان) - كموني / برتقالي فاتح
  | 'ghunnah'             // غنة مشددة (نّ، مّ) - أخضر غامق
  | 'ikhfa'               // إخفاء حقيقي وشفوي - أخضر نضر
  | 'idgham_ghunnah'      // إدغام بغنة (ينمو) - أخضر ليموني / زيتي
  | 'iqlab'               // إقلاب (قلب النون ميماً) - تركواز / سماوي مخضر
  | 'idgham_no_ghunnah'   // إدغام بغير غنة (ل، ر) - رمادي مزرق
  | 'qalqalah'            // قلقلة (قطب جد ساكن أو موقوف عليه) - أزرق سماوي
  | 'tafkheem'            // تفخيم لام لفظ الجلالة - أزرق داكن / كحلي
  | 'silent';             // حروف لا تُلفظ (همزة وصل، ألف فارقة) - رمادي خافت

export interface TajweedRuleInfo {
  id: TajweedRuleId;
  name: string;
  category: 'madd' | 'noon_meem' | 'qalqalah' | 'sifat' | 'other';
  harakat: string;
  colorHex: string;
  textColorLight: string;
  textColorDark: string;
  bgBadgeLight: string;
  bgBadgeDark: string;
  description: string;
  example: string;
}

export const TAJWEED_RULES: Record<TajweedRuleId, TajweedRuleInfo> = {
  madd_obligatory: {
    id: 'madd_obligatory',
    name: 'مد لازم (كلمي وحرفي)',
    category: 'madd',
    harakat: '6 حركات',
    colorHex: '#dc2626',
    textColorLight: 'text-red-700 dark:text-red-400 font-semibold',
    textColorDark: 'dark:text-red-400',
    bgBadgeLight: 'bg-red-100 text-red-800 border-red-300',
    bgBadgeDark: 'dark:bg-red-950/80 dark:text-red-300 dark:border-red-800',
    description: 'يحدث عندما يلي حرفَ المد سكونٌ أصلي أو حرف مشدد، ويمد لزوماً بمقدار ست حركات.',
    example: 'ٱلضَّآلِّينَ • دَآبَّةٍ • الٓمٓ'
  },
  madd_permissible: {
    id: 'madd_permissible',
    name: 'مد واجب متصل وجائز منفصل وصلة كبرى',
    category: 'madd',
    harakat: '4 - 5 حركات',
    colorHex: '#ea580c',
    textColorLight: 'text-orange-700 dark:text-orange-400 font-semibold',
    textColorDark: 'dark:text-orange-400',
    bgBadgeLight: 'bg-orange-100 text-orange-800 border-orange-300',
    bgBadgeDark: 'dark:bg-orange-950/80 dark:text-orange-300 dark:border-orange-800',
    description: 'حرف مد يليه همزة في الكلمة نفسها (متصل) أو في أول الكلمة التالية (منفصل) أو صلة كبرى.',
    example: 'جَآءَ • إِنَّآ أَعْطَيْنَـٰكَ • سُوٓءَ'
  },
  madd_normal: {
    id: 'madd_normal',
    name: 'مد طبيعي وبدل وصلة صغرى',
    category: 'madd',
    harakat: 'حركتان',
    colorHex: '#d97706',
    textColorLight: 'text-amber-700 dark:text-amber-400',
    textColorDark: 'dark:text-amber-400',
    bgBadgeLight: 'bg-amber-100 text-amber-800 border-amber-300',
    bgBadgeDark: 'dark:bg-amber-950/80 dark:text-amber-300 dark:border-amber-800',
    description: 'المد الأصلي الطبيعي بالألف الخنجرية أو الصلة الصغرى أو حروف المد الطبيعية ويمد حركتين.',
    example: 'ٱلرَّحْمَـٰنِ • ٱلْعَـٰلَمِينَ • إِنَّهُۥ'
  },
  ghunnah: {
    id: 'ghunnah',
    name: 'غنة مشددة (النون والميم المشددتان)',
    category: 'noon_meem',
    harakat: 'حركتان',
    colorHex: '#059669',
    textColorLight: 'text-emerald-700 dark:text-emerald-400 font-semibold',
    textColorDark: 'dark:text-emerald-400',
    bgBadgeLight: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    bgBadgeDark: 'dark:bg-emerald-950/80 dark:text-emerald-300 dark:border-emerald-800',
    description: 'صوت يخرج من الخيشوم عند النطق بالنون أو الميم المشددتين (نّ ، مّ) بمقدار حركتين.',
    example: 'إِنَّ • ٱلنَّاسِ • ثُمَّ • ٱلْجِنَّةِ'
  },
  ikhfa: {
    id: 'ikhfa',
    name: 'إخفاء حقيقي وشفوي',
    category: 'noon_meem',
    harakat: 'حركتان',
    colorHex: '#16a34a',
    textColorLight: 'text-green-700 dark:text-green-400 font-semibold',
    textColorDark: 'dark:text-green-400',
    bgBadgeLight: 'bg-green-100 text-green-800 border-green-300',
    bgBadgeDark: 'dark:bg-green-950/80 dark:text-green-300 dark:border-green-800',
    description: 'ستر النون الساكنة أو التنوين عند حروف الإخفاء الـ 15، أو الميم الساكنة عند الباء بغنة.',
    example: 'مِن شَرِّ • كُنتُمْ • هُم بِهِ'
  },
  idgham_ghunnah: {
    id: 'idgham_ghunnah',
    name: 'إدغام بغنة (ينمو)',
    category: 'noon_meem',
    harakat: 'حركتان',
    colorHex: '#65a30d',
    textColorLight: 'text-lime-700 dark:text-lime-400 font-semibold',
    textColorDark: 'dark:text-lime-400',
    bgBadgeLight: 'bg-lime-100 text-lime-800 border-lime-300',
    bgBadgeDark: 'dark:bg-lime-950/80 dark:text-lime-300 dark:border-lime-800',
    description: 'إدخال النون الساكنة أو التنوين في حروف (ي، ن، م، و) مع إبقاء صفة الغنة حركتين.',
    example: 'مَن يَقُولُ • مِن مَّالٍ • خَيْرًا يَرَهُ'
  },
  iqlab: {
    id: 'iqlab',
    name: 'إقلاب (قلب النون ميماً مخفاة)',
    category: 'noon_meem',
    harakat: 'حركتان',
    colorHex: '#0d9488',
    textColorLight: 'text-teal-700 dark:text-teal-400 font-semibold',
    textColorDark: 'dark:text-teal-400',
    bgBadgeLight: 'bg-teal-100 text-teal-800 border-teal-300',
    bgBadgeDark: 'dark:bg-teal-950/80 dark:text-teal-300 dark:border-teal-800',
    description: 'قلب النون الساكنة أو التنوين ميماً مخفاة مع الغنة عند ملاقاة الباء (يُميز بميم صغيرة ۢ).',
    example: 'مِنۢ بَعْدِ • أَنۢبِئْهُم • عَلِيمٌۢ بِذَاتِ'
  },
  idgham_no_ghunnah: {
    id: 'idgham_no_ghunnah',
    name: 'إدغام بغير غنة (اللام والراء)',
    category: 'noon_meem',
    harakat: 'بدون غنة',
    colorHex: '#64748b',
    textColorLight: 'text-slate-600 dark:text-slate-400',
    textColorDark: 'dark:text-slate-400',
    bgBadgeLight: 'bg-slate-100 text-slate-800 border-slate-300',
    bgBadgeDark: 'dark:bg-slate-900 dark:text-slate-300 dark:border-slate-800',
    description: 'إدخال كامل للنون الساكنة أو التنوين في حرفي (اللام والراء) دون إخراج صوت غنة.',
    example: 'مِّن رَّبِّهِمْ • هُدًى لِّلْمُتَّقِينَ • وَلَمْ يَكُن لَّهُۥ'
  },
  qalqalah: {
    id: 'qalqalah',
    name: 'قلقلة (قطب جد)',
    category: 'qalqalah',
    harakat: 'نبرة صوتية',
    colorHex: '#0284c7',
    textColorLight: 'text-sky-700 dark:text-sky-400 font-semibold',
    textColorDark: 'dark:text-sky-400',
    bgBadgeLight: 'bg-sky-100 text-sky-800 border-sky-300',
    bgBadgeDark: 'dark:bg-sky-950/80 dark:text-sky-300 dark:border-sky-800',
    description: 'اضطراب وتحريك الصوت عند النطق بأحد حروف (ق، ط، ب، ج، د) ساكناً أو موقوفاً عليه.',
    example: 'ٱلْفَلَقِ • خَلَقَ • يَجْعَلْ • أَبْصَارِهِمْ'
  },
  tafkheem: {
    id: 'tafkheem',
    name: 'تفخيم لام لفظ الجلالة',
    category: 'sifat',
    harakat: 'تغليظ اللام',
    colorHex: '#4f46e5',
    textColorLight: 'text-indigo-700 dark:text-indigo-400 font-semibold',
    textColorDark: 'dark:text-indigo-400',
    bgBadgeLight: 'bg-indigo-100 text-indigo-800 border-indigo-300',
    bgBadgeDark: 'dark:bg-indigo-950/80 dark:text-indigo-300 dark:border-indigo-800',
    description: 'تغليظ وتفخيم لام لفظ الجلالة (الله / اللهم) إذا سبقتها فتحة أو ضمة.',
    example: 'قُلْ هُوَ اللَّهُ • شَهِدَ اللَّهُ • عَبْدُ اللَّهِ'
  },
  silent: {
    id: 'silent',
    name: 'حروف تُكتب ولا تُلفظ (همزة وصل، ألف فارقة)',
    category: 'other',
    harakat: 'لا تلفظ',
    colorHex: '#9ca3af',
    textColorLight: 'text-stone-400 dark:text-stone-500 opacity-70',
    textColorDark: 'dark:text-stone-500',
    bgBadgeLight: 'bg-stone-100 text-stone-700 border-stone-300',
    bgBadgeDark: 'dark:bg-stone-900 dark:text-stone-400 dark:border-stone-800',
    description: 'حروف تسقط وصلاً كهمزة الوصل والألف الفارقة والواو الزائدة واللام الشمسية المدغمة.',
    example: 'ٱلَّذِينَ • قَالُوٓا۟ • أُو۟لَـٰٓئِكَ'
  }
};

export const TAJWEED_RULES_LIST = Object.values(TAJWEED_RULES);

export interface TajweedSegment {
  text: string;
  rule?: TajweedRuleInfo;
  tooltip?: string;
}

// Qalqalah letters: قطب جد
const QALQALAH_LETTERS = new Set(['ق', 'ط', 'ب', 'ج', 'د']);

// Ikhfa letters (15 letters): ص ذ ث ك ج ش ق س د ط ز ف ت ض ظ
const IKHFA_LETTERS = new Set(['ص', 'ذ', 'ث', 'ك', 'ج', 'ش', 'ق', 'س', 'د', 'ط', 'ز', 'ف', 'ت', 'ض', 'ظ']);

// Idgham with ghunnah: ي ن م و
const IDGHAM_GHUNNAH_LETTERS = new Set(['ي', 'ن', 'م', 'و']);

// Idgham without ghunnah: ل ر
const IDGHAM_NO_GHUNNAH_LETTERS = new Set(['ل', 'ر']);

// Hamza letters
const HAMZA_LETTERS = new Set(['ء', 'أ', 'إ', 'ئ', 'ؤ', 'ٱ']);

// Diacritics and signs
const SUKUN = '\u0652';
const SHADDAH = '\u0651';
const MADDAH = '\u0653';
const DAGGER_ALEF = '\u0670';
const SMALL_MEEM_ISOLATED = '\u06E2';
const SMALL_MEEM_ABOVE = '\u06ED';
const SMALL_WAW = '\u06E5';
const SMALL_YAA = '\u06E6';
const ROUNDED_ZERO = '\u06DF'; // علامة الحرف الزائد الذي لا ينطق
const ALEF_WASLAH = '\u0671';

// Tanween marks
const FATHATAN = '\u064B';
const DAMMATAN = '\u064C';
const KASRATAN = '\u064D';

const TAJWEED_STORAGE_KEY = 'mushaf_tajweed_colored_active';

export function isTajweedEnabled(): boolean {
  if (typeof window === 'undefined') return true;
  const val = localStorage.getItem(TAJWEED_STORAGE_KEY);
  if (val === null) return true; // Enabled by default for rich Quran experience
  return val === 'true';
}

export function setTajweedEnabled(enabled: boolean): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(TAJWEED_STORAGE_KEY, enabled ? 'true' : 'false');
  }
}

function isDiacritic(char: string): boolean {
  const code = char.charCodeAt(0);
  return (code >= 0x064b && code <= 0x065f) || code === 0x0670 || (code >= 0x06d6 && code <= 0x06ed);
}

function getNextBaseLetter(str: string, startIndex: number): { char: string; index: number } | null {
  for (let i = startIndex; i < str.length; i++) {
    const c = str[i];
    if (c === ' ' || c === '\t' || isDiacritic(c)) continue;
    return { char: c, index: i };
  }
  return null;
}

/**
 * Advanced Tajweed parsing for an Ayah text
 * Splits into semantic color-coded segments while strictly preserving text shaping.
 */
export function parseTajweed(verseText: string): TajweedSegment[] {
  if (!verseText) return [];

  const segments: TajweedSegment[] = [];
  const len = verseText.length;
  let i = 0;

  const pushText = (txt: string) => {
    if (!txt) return;
    if (segments.length > 0 && !segments[segments.length - 1].rule) {
      segments[segments.length - 1].text += txt;
    } else {
      segments.push({ text: txt });
    }
  };

  const pushRule = (txt: string, ruleId: TajweedRuleId, tooltip?: string) => {
    if (!txt) return;
    const rule = TAJWEED_RULES[ruleId];
    segments.push({
      text: txt,
      rule,
      tooltip: tooltip || `${rule.name} (${rule.harakat})`,
    });
  };

  while (i < len) {
    const ch = verseText[i];

    // 1. Silent letter marked with rounded zero (سكون مستدير يكتب ولا ينطق: ا۟، و۟)
    if (ch === ROUNDED_ZERO) {
      i++;
      continue;
    }
    if (i + 1 < len && verseText[i + 1] === ROUNDED_ZERO) {
      pushRule(ch + ROUNDED_ZERO, 'silent', 'حرف يُكتب ولا يُلفظ (سكون مستدير)');
      i += 2;
      continue;
    }

    // 2. Alef Waslah (همزة وصل - تسقط وصلاً) & Solar Lam
    if (ch === ALEF_WASLAH) {
      if (i + 1 < len && verseText[i + 1] === 'ل') {
        const nextLetter = getNextBaseLetter(verseText, i + 2);
        let hasShaddah = false;
        if (nextLetter) {
          for (let k = nextLetter.index; k < Math.min(len, nextLetter.index + 3); k++) {
            if (verseText[k] === SHADDAH) {
              hasShaddah = true;
              break;
            }
          }
        }
        if (hasShaddah) {
          pushRule(ch + 'ل', 'silent', 'همزة وصل ولام شمسية مدغمة (لا تُلفظ)');
          i += 2;
          continue;
        }
      }
      pushRule(ch, 'silent', 'همزة وصل تسقط في دَرَجِ الكلام');
      i++;
      continue;
    }

    // 3. Iqlab with Small Meem (ۢ or ۭ)
    if (ch === SMALL_MEEM_ISOLATED || ch === SMALL_MEEM_ABOVE) {
      pushRule(ch, 'iqlab', 'إقلاب: قلب النون أو التنوين ميماً مخفاة مع الغنة (حركتان)');
      i++;
      continue;
    }

    // 4. Madd letters followed by Maddah Above (ٓ) - المدود
    // Check if current letter is a madd letter (ا / و / ي / ـٰ) with Maddah on it
    const isMaddLetter = ch === 'ا' || ch === 'و' || ch === 'ي' || ch === DAGGER_ALEF || ch === 'آ' || ch === 'آ';
    const hasMaddahNext = i + 1 < len && verseText[i + 1] === MADDAH;

    if (hasMaddahNext && isMaddLetter) {
      const maddCombined = ch + MADDAH;
      const next = getNextBaseLetter(verseText, i + 2);
      let isLazim = false;
      let isHamza = false;

      if (next) {
        if (HAMZA_LETTERS.has(next.char)) {
          isHamza = true;
        } else {
          for (let k = next.index; k < Math.min(len, next.index + 3); k++) {
            if (verseText[k] === SHADDAH || verseText[k] === SUKUN) {
              isLazim = true;
              break;
            }
          }
        }
      }

      if (isLazim) {
        pushRule(maddCombined, 'madd_obligatory', 'مد لازم: يمد بمقدار 6 حركات لزوماً');
      } else if (isHamza) {
        pushRule(maddCombined, 'madd_permissible', 'مد متصل / منفصل: يمد بمقدار 4 إلى 5 حركات');
      } else {
        pushRule(maddCombined, 'madd_permissible', 'مد واجب / جائز: يمد بمقدار 4 إلى 5 حركات');
      }
      i += 2;
      continue;
    }

    // Standalone Maddah if not caught above
    if (ch === MADDAH || ch === 'آ') {
      const next = getNextBaseLetter(verseText, i + 1);
      let isLazim = false;
      if (next) {
        for (let k = next.index; k < Math.min(len, next.index + 3); k++) {
          if (verseText[k] === SHADDAH || verseText[k] === SUKUN) {
            isLazim = true;
            break;
          }
        }
      }
      if (isLazim) {
        pushRule(ch, 'madd_obligatory', 'مد لازم: يمد بمقدار 6 حركات لزوماً');
      } else {
        pushRule(ch, 'madd_permissible', 'مد متصل / منفصل: يمد بمقدار 4 إلى 5 حركات');
      }
      i++;
      continue;
    }

    // 5. Normal Madd (الألف الخنجرية، والواو والياء الصغيرتان)
    if (ch === DAGGER_ALEF || ch === SMALL_WAW || ch === SMALL_YAA) {
      pushRule(ch, 'madd_normal', 'مد طبيعي / صلة صغرى: يمد بمقدار حركتين');
      i++;
      continue;
    }

    // 6. Ghunnah Mushaddadah (نّ أو مّ)
    if ((ch === 'ن' || ch === 'م') && i + 1 < len && (verseText[i + 1] === SHADDAH || (i + 2 < len && verseText[i + 2] === SHADDAH))) {
      let segmentStr = ch;
      let k = i + 1;
      while (k < len && isDiacritic(verseText[k])) {
        segmentStr += verseText[k];
        k++;
      }
      if (segmentStr.includes(SHADDAH)) {
        pushRule(segmentStr, 'ghunnah', 'غنة مشددة: غنة ظاهرة بمقدار حركتين في النون/الميم المشددة');
        i = k;
        continue;
      }
    }

    // 7. Tafkheem in Lafz al-Jalalah (الله / اللهم)
    if (ch === 'ل' && (verseText.startsWith('للَّهِ', i) || verseText.startsWith('للَّهَ', i) || verseText.startsWith('للَّهُ', i))) {
      let prevVowel = '';
      for (let back = i - 1; back >= Math.max(0, i - 5); back--) {
        const b = verseText[back];
        if (b === ' ' || b === ALEF_WASLAH) continue;
        if (b === '\u064E' || b === '\u064F') {
          prevVowel = 'tafkheem';
          break;
        }
        if (b === '\u0650') {
          prevVowel = 'tarqeeq';
          break;
        }
      }
      if (prevVowel !== 'tarqeeq') {
        const matchStr = verseText.substr(i, 6);
        pushRule(matchStr, 'tafkheem', 'تفخيم لام لفظ الجلالة');
        i += matchStr.length;
        continue;
      }
    }

    // 8. Qalqalah: قطب جد (ق، ط، ب، ج، د)
    if (QALQALAH_LETTERS.has(ch)) {
      let hasSukun = false;
      let diacritics = '';
      let k = i + 1;
      while (k < len && isDiacritic(verseText[k])) {
        diacritics += verseText[k];
        if (verseText[k] === SUKUN) {
          hasSukun = true;
        }
        k++;
      }

      const isLastBaseLetter = getNextBaseLetter(verseText, k) === null;

      if (hasSukun) {
        pushRule(ch + diacritics, 'qalqalah', 'قلقلة صغرى: نبرة واضحة في الحرف الساكن');
        i = k;
        continue;
      } else if (isLastBaseLetter) {
        pushRule(ch + diacritics, 'qalqalah', 'قلقلة كبرى: اضطراب ونبر قوي عند الوقف على الحرف');
        i = k;
        continue;
      }
    }

    // 9. Noon Sakinah (Ikhfa, Idgham, Iqlab)
    if (ch === 'ن') {
      let diacritics = '';
      let k = i + 1;
      while (k < len && isDiacritic(verseText[k])) {
        diacritics += verseText[k];
        k++;
      }

      const isNakedNoon = !diacritics.includes('\u064E') && 
                          !diacritics.includes('\u064F') && 
                          !diacritics.includes('\u0650') && 
                          !diacritics.includes(SHADDAH) && 
                          !diacritics.includes(SUKUN);

      if (isNakedNoon) {
        const next = getNextBaseLetter(verseText, k);
        if (next) {
          if (IKHFA_LETTERS.has(next.char)) {
            pushRule(ch + diacritics, 'ikhfa', 'إخفاء حقيقي: ستر النون بغنة بمقدار حركتين');
            i = k;
            continue;
          }
          if (IDGHAM_GHUNNAH_LETTERS.has(next.char)) {
            pushRule(ch + diacritics, 'idgham_ghunnah', 'إدغام بغنة: إدغام النون في الحرف التالي بغنة حركتين');
            i = k;
            continue;
          }
          if (IDGHAM_NO_GHUNNAH_LETTERS.has(next.char)) {
            pushRule(ch + diacritics, 'idgham_no_ghunnah', 'إدغام بغير غنة: إدغام كامل في اللام أو الراء');
            i = k;
            continue;
          }
          if (next.char === 'ب') {
            pushRule(ch + diacritics, 'iqlab', 'إقلاب: قلب النون ميماً عند الباء');
            i = k;
            continue;
          }
        }
      }
    }

    // 10. Tanween rules
    if (ch === FATHATAN || ch === DAMMATAN || ch === KASRATAN) {
      const next = getNextBaseLetter(verseText, i + 1);
      if (next) {
        if (IKHFA_LETTERS.has(next.char)) {
          pushRule(ch, 'ikhfa', 'إخفاء التنوين بغنة حركتين');
          i++;
          continue;
        }
        if (IDGHAM_GHUNNAH_LETTERS.has(next.char)) {
          pushRule(ch, 'idgham_ghunnah', 'إدغام التنوين بغنة حركتين');
          i++;
          continue;
        }
        if (IDGHAM_NO_GHUNNAH_LETTERS.has(next.char)) {
          pushRule(ch, 'idgham_no_ghunnah', 'إدغام التنوين بغير غنة');
          i++;
          continue;
        }
        if (next.char === 'ب') {
          pushRule(ch, 'iqlab', 'إقلاب التنوين ميماً مخفاة عند الباء');
          i++;
          continue;
        }
      }
    }

    // 11. Meem Sakinah: Ikhfa Shafawi
    if (ch === 'م') {
      let diacritics = '';
      let k = i + 1;
      while (k < len && isDiacritic(verseText[k])) {
        diacritics += verseText[k];
        k++;
      }
      const isNakedMeem = !diacritics.includes('\u064E') && 
                          !diacritics.includes('\u064F') && 
                          !diacritics.includes('\u0650') && 
                          !diacritics.includes(SHADDAH) && 
                          !diacritics.includes(SUKUN);
      if (isNakedMeem) {
        const next = getNextBaseLetter(verseText, k);
        if (next && next.char === 'ب') {
          pushRule(ch + diacritics, 'ikhfa', 'إخفاء شفوي: إخفاء الميم الساكنة عند الباء بغنة حركتين');
          i = k;
          continue;
        }
      }
    }

    pushText(ch);
    i++;
  }

  return segments;
}
