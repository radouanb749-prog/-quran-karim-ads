export interface TasbihPreset {
  id: string;
  title: string;
  target: number; // 0 means open/infinite
  virtue?: string;
  isCustom?: boolean;
}

export interface AfterPrayerStep {
  text: string;
  target: number;
}

export const AFTER_PRAYER_SEQUENCE: AfterPrayerStep[] = [
  { text: 'سُبْحَانَ اللَّهِ', target: 33 },
  { text: 'الْحَمْدُ لِلَّهِ', target: 33 },
  { text: 'اللَّهُ أَكْبَرُ', target: 33 },
  { text: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ', target: 1 },
];

export const DEFAULT_TASBIH_PRESETS: TasbihPreset[] = [
  {
    id: 'subhanallah',
    title: 'سُبْحَانَ اللَّهِ',
    target: 33,
    virtue: 'تُمحى الخطايا وتُغرس بها شجرة في الجنة',
  },
  {
    id: 'alhamdulillah',
    title: 'الْحَمْدُ لِلَّهِ',
    target: 33,
    virtue: 'أفضل الدعاء وتملأ ميزان العبد بالحسنات',
  },
  {
    id: 'allahuakbar',
    title: 'اللَّهُ أَكْبَرُ',
    target: 33,
    virtue: 'أحب الكلام إلى الله، وتكبيره وتنزيهه سبحانه',
  },
  {
    id: 'lailahaillallah',
    title: 'لَا إِلَهَ إِلَّا اللَّهُ',
    target: 100,
    virtue: 'أفضل الذكر وكلمة التوحيد ومفتاح الجنة',
  },
  {
    id: 'istighfar',
    title: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ',
    target: 100,
    virtue: 'تفريج الهموم ومغفرة الذنوب وزيادة الرزق والبركة',
  },
  {
    id: 'salawat',
    title: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ',
    target: 100,
    virtue: 'من صلى عليَّ صلاة صلى الله عليه بها عشراً',
  },
  {
    id: 'hawqala',
    title: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
    target: 100,
    virtue: 'كنز من كنوز الجنة ودواء لتسعة وتسعين داء',
  },
  {
    id: 'subhanallah_wabihamdih',
    title: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
    target: 100,
    virtue: 'كلمتان خفيفتان على اللسان ثقيلتان في الميزان حبيبتان إلى الرحمن',
  },
  {
    id: 'tawhid_complete',
    title: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
    target: 100,
    virtue: 'حرز من الشيطان وعتق رقاب ومغفرة للخطايا',
  },
  {
    id: 'hasbiyallah',
    title: 'حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ',
    target: 100,
    virtue: 'أمان لكل خائف وتفويض الأمر لله العلي القدير',
  },
  {
    id: 'ya_hayyu_ya_qayyum',
    title: 'يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ',
    target: 100,
    virtue: 'دعاء الكرب وتفريج الشدائد وإصلاح الشأن كله',
  },
  {
    id: 'open_tasbih',
    title: 'تسبيح وذكر حر مفتوح',
    target: 0,
    virtue: 'عداد مفتوح لأي ذكر بلا حد محدد',
  },
];

const STORAGE_PRESET_KEY = 'mushaf_tasbih_current_preset';
const STORAGE_CUSTOM_KEY = 'mushaf_tasbih_custom_presets';
const STORAGE_STATS_KEY = 'mushaf_tasbih_stats';
const STORAGE_SETTINGS_KEY = 'mushaf_tasbih_settings';

export interface TasbihStats {
  todayDate: string; // YYYY-MM-DD
  todayTotal: number;
  allTimeTotal: number;
  totalRounds: number;
}

export interface TasbihSettings {
  vibration: boolean;
  sound: boolean;
  numeralStyle: 'standard' | 'eastern'; // 'standard' = 1, 2, 3 (عالمية عادية), 'eastern' = ١، ٢، ٣
}

function getTodayString(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function formatTasbihNumber(num: number, style: 'standard' | 'eastern' = 'standard'): string {
  if (style === 'eastern') {
    return num.toLocaleString('ar-EG');
  }
  return num.toLocaleString('en-US'); // 1, 2, 3...
}

export function getTasbihSettings(): TasbihSettings {
  if (typeof window === 'undefined') return { vibration: true, sound: true, numeralStyle: 'standard' };
  try {
    const raw = localStorage.getItem(STORAGE_SETTINGS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        vibration: parsed.vibration ?? true,
        sound: parsed.sound ?? true,
        numeralStyle: parsed.numeralStyle || 'standard',
      };
    }
  } catch {}
  return { vibration: true, sound: true, numeralStyle: 'standard' };
}

export function saveTasbihSettings(settings: TasbihSettings): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_SETTINGS_KEY, JSON.stringify(settings));
  } catch {}
}

export function getCustomTasbihPresets(): TasbihPreset[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_CUSTOM_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

export function saveCustomTasbihPreset(preset: Omit<TasbihPreset, 'id' | 'isCustom'>): TasbihPreset {
  const customList = getCustomTasbihPresets();
  const newPreset: TasbihPreset = {
    id: `custom_${Date.now()}`,
    title: preset.title.trim(),
    target: preset.target || 33,
    virtue: preset.virtue?.trim(),
    isCustom: true,
  };
  customList.push(newPreset);
  try {
    localStorage.setItem(STORAGE_CUSTOM_KEY, JSON.stringify(customList));
  } catch {}
  return newPreset;
}

export function deleteCustomTasbihPreset(id: string): void {
  const customList = getCustomTasbihPresets().filter((p) => p.id !== id);
  try {
    localStorage.setItem(STORAGE_CUSTOM_KEY, JSON.stringify(customList));
  } catch {}
}

export function getAllTasbihPresets(): TasbihPreset[] {
  return [...DEFAULT_TASBIH_PRESETS, ...getCustomTasbihPresets()];
}

export function getSavedPresetId(): string {
  if (typeof window === 'undefined') return DEFAULT_TASBIH_PRESETS[0].id;
  try {
    const saved = localStorage.getItem(STORAGE_PRESET_KEY);
    if (saved) return saved;
  } catch {}
  return DEFAULT_TASBIH_PRESETS[0].id;
}

export function saveCurrentPresetId(id: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_PRESET_KEY, id);
  } catch {}
}

export function getTasbihStats(): TasbihStats {
  const today = getTodayString();
  const defaultStats: TasbihStats = {
    todayDate: today,
    todayTotal: 0,
    allTimeTotal: 0,
    totalRounds: 0,
  };

  if (typeof window === 'undefined') return defaultStats;

  try {
    const raw = localStorage.getItem(STORAGE_STATS_KEY);
    if (raw) {
      const parsed: TasbihStats = JSON.parse(raw);
      if (parsed.todayDate !== today) {
        // New day! Reset today's count but keep allTime and rounds
        parsed.todayDate = today;
        parsed.todayTotal = 0;
        localStorage.setItem(STORAGE_STATS_KEY, JSON.stringify(parsed));
      }
      return parsed;
    }
  } catch {}

  return defaultStats;
}

export function incrementTasbihStats(amount: number = 1): TasbihStats {
  const stats = getTasbihStats();
  stats.todayTotal += amount;
  stats.allTimeTotal += amount;

  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(STORAGE_STATS_KEY, JSON.stringify(stats));
    } catch {}
  }
  return stats;
}

export function incrementTasbihRounds(): TasbihStats {
  const stats = getTasbihStats();
  stats.totalRounds += 1;

  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(STORAGE_STATS_KEY, JSON.stringify(stats));
    } catch {}
  }
  return stats;
}

export function resetTasbihTodayStats(): TasbihStats {
  const stats = getTasbihStats();
  stats.todayTotal = 0;
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(STORAGE_STATS_KEY, JSON.stringify(stats));
    } catch {}
  }
  return stats;
}

/**
 * Play gentle haptic vibration
 */
export function triggerHaptic(type: 'tap' | 'complete' | 'reset' = 'tap'): void {
  if (typeof window === 'undefined' || !navigator.vibrate) return;
  try {
    if (type === 'tap') {
      navigator.vibrate(25);
    } else if (type === 'complete') {
      navigator.vibrate([60, 50, 60, 50, 100]);
    } else if (type === 'reset') {
      navigator.vibrate([40, 40]);
    }
  } catch {}
}

/**
 * Play a gentle, soft mechanical bead click sound using Web Audio API
 */
let audioCtx: AudioContext | null = null;

export function playTasbihSound(): void {
  if (typeof window === 'undefined') return;
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    if (!audioCtx) {
      audioCtx = new AudioContextClass();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(680, audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(320, audioCtx.currentTime + 0.04);

    gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.04);

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.start();
    osc.stop(audioCtx.currentTime + 0.045);
  } catch {}
}
