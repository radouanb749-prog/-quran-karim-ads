export type QuranFontFamily = 'uthmani' | 'amiri' | 'cairo';
export type QuranLineSpacing = 'normal' | 'comfortable' | 'loose';

export interface FontFamilyOption {
  id: QuranFontFamily;
  name: string;
  subname: string;
  badge: string;
  fontClass: string;
  sampleText: string;
}

export const FONT_FAMILY_OPTIONS: FontFamilyOption[] = [
  {
    id: 'uthmani',
    name: 'الخط العثماني',
    subname: 'الرسم العثماني المعتمد برواية حفص',
    badge: 'الأصلي',
    fontClass: 'font-uthmani',
    sampleText: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ',
  },
  {
    id: 'amiri',
    name: 'خط النسخ (Amiri)',
    subname: 'خط نسخي كلاسيكي واضح ومتقن',
    badge: 'كلاسيكي',
    fontClass: 'font-amiri-quran',
    sampleText: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ',
  },
  {
    id: 'cairo',
    name: 'خط كايرو (Cairo)',
    subname: 'خط حديث سلس عالي الوضوح ومريح للعين',
    badge: 'عصري',
    fontClass: 'font-cairo-quran',
    sampleText: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ',
  },
];

export interface LineSpacingOption {
  id: QuranLineSpacing;
  name: string;
  description: string;
  lineHeightClass: string;
  pageLineHeightClass: string;
}

export const LINE_SPACING_OPTIONS: LineSpacingOption[] = [
  {
    id: 'normal',
    name: 'عادي',
    description: 'ارتفاع سطر قياسي',
    lineHeightClass: 'leading-[2.2]',
    pageLineHeightClass: 'leading-[1.9]',
  },
  {
    id: 'comfortable',
    name: 'مريح',
    description: 'تباعد إضافي لراحة العين',
    lineHeightClass: 'leading-[2.6]',
    pageLineHeightClass: 'leading-[2.2]',
  },
  {
    id: 'loose',
    name: 'واسع',
    description: 'تباعد رحب للتدبر والتركيز',
    lineHeightClass: 'leading-[3.0]',
    pageLineHeightClass: 'leading-[2.5]',
  },
];

export interface FontSizeOption {
  level: number;
  label: string;
  sizeClass: string;
  pageSizeClass: string;
}

export const FONT_SIZE_LEVELS: FontSizeOption[] = [
  {
    level: 0,
    label: 'صغير',
    sizeClass: 'text-lg sm:text-xl',
    pageSizeClass: 'text-lg sm:text-xl',
  },
  {
    level: 1,
    label: 'قياسي',
    sizeClass: 'text-xl sm:text-2xl',
    pageSizeClass: 'text-xl sm:text-[1.4rem]',
  },
  {
    level: 2,
    label: 'متوسط (موصى به)',
    sizeClass: 'text-2xl sm:text-3xl',
    pageSizeClass: 'text-2xl sm:text-[1.65rem]',
  },
  {
    level: 3,
    label: 'كبير',
    sizeClass: 'text-3xl sm:text-4xl',
    pageSizeClass: 'text-[1.65rem] sm:text-3xl',
  },
  {
    level: 4,
    label: 'كبير جداً',
    sizeClass: 'text-4xl sm:text-5xl',
    pageSizeClass: 'text-3xl sm:text-[2.2rem]',
  },
  {
    level: 5,
    label: 'ضخم (للشاشات الكبيرة/ضعف النظر)',
    sizeClass: 'text-5xl sm:text-6xl',
    pageSizeClass: 'text-4xl sm:text-5xl',
  },
];

const STORAGE_KEY_FONT_FAMILY = 'mushaf_reader_font_family';
const STORAGE_KEY_FONT_SIZE = 'mushaf_reader_font_size';
const STORAGE_KEY_LINE_SPACING = 'mushaf_reader_line_spacing';

export function getSavedFontFamily(): QuranFontFamily {
  if (typeof window === 'undefined') return 'uthmani';
  try {
    const saved = localStorage.getItem(STORAGE_KEY_FONT_FAMILY) as QuranFontFamily;
    if (saved && (saved === 'uthmani' || saved === 'amiri' || saved === 'cairo')) {
      return saved;
    }
    return 'uthmani';
  } catch {
    return 'uthmani';
  }
}

export function saveFontFamily(font: QuranFontFamily): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_FONT_FAMILY, font);
  } catch {}
}

export function getSavedFontSizeLevel(): number {
  if (typeof window === 'undefined') return 2;
  try {
    const saved = localStorage.getItem(STORAGE_KEY_FONT_SIZE);
    if (saved !== null) {
      const parsed = parseInt(saved, 10);
      if (!isNaN(parsed) && parsed >= 0 && parsed < FONT_SIZE_LEVELS.length) {
        return parsed;
      }
    }
    return 2;
  } catch {
    return 2;
  }
}

export function saveFontSizeLevel(level: number): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_FONT_SIZE, level.toString());
  } catch {}
}

export function getSavedLineSpacing(): QuranLineSpacing {
  if (typeof window === 'undefined') return 'comfortable';
  try {
    const saved = localStorage.getItem(STORAGE_KEY_LINE_SPACING) as QuranLineSpacing;
    if (saved && (saved === 'normal' || saved === 'comfortable' || saved === 'loose')) {
      return saved;
    }
    return 'comfortable';
  } catch {
    return 'comfortable';
  }
}

export function saveLineSpacing(spacing: QuranLineSpacing): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_LINE_SPACING, spacing);
  } catch {}
}
