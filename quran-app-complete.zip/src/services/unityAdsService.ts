/**
 * Unity Ads Integration Service
 * Configured with Game ID: 800394591 for Google Play and Store Deployment
 */

export const UNITY_ADS_CONFIG = {
  gameId: '800394591',
  testMode: false,
  placements: {
    interstitial: 'Interstitial_Android',
    banner: 'Banner_Android',
    rewarded: 'Rewarded_Android',
  },
} as const;

// Interface for Android WebView Native Bridge
declare global {
  interface Window {
    AndroidUnityAds?: {
      getGameId: () => string;
      isInitialized: () => boolean;
      loadAd: (placementId: string) => void;
      showAd: (placementId: string) => void;
    };
  }
}

class UnityAdsService {
  private initialized = false;

  public init(): void {
    if (this.initialized) return;

    if (typeof window !== 'undefined' && window.AndroidUnityAds) {
      console.log('Unity Ads native bridge detected with Game ID:', window.AndroidUnityAds.getGameId());
      this.initialized = true;
    } else {
      console.log('Unity Ads configured with Game ID:', UNITY_ADS_CONFIG.gameId);
      this.initialized = true;
    }
  }

  public isAvailable(): boolean {
    if (typeof window !== 'undefined' && window.AndroidUnityAds) {
      return window.AndroidUnityAds.isInitialized();
    }
    return this.initialized;
  }

  public getGameId(): string {
    return UNITY_ADS_CONFIG.gameId;
  }

  public showInterstitial(placementId: string = UNITY_ADS_CONFIG.placements.interstitial): void {
    if (typeof window !== 'undefined' && window.AndroidUnityAds) {
      window.AndroidUnityAds.showAd(placementId);
    } else {
      console.log(`[Unity Ads] Interstitial Ad requested for placement: ${placementId}`);
    }
  }

  public showRewarded(placementId: string = UNITY_ADS_CONFIG.placements.rewarded): void {
    if (typeof window !== 'undefined' && window.AndroidUnityAds) {
      window.AndroidUnityAds.showAd(placementId);
    } else {
      console.log(`[Unity Ads] Rewarded Ad requested for placement: ${placementId}`);
    }
  }
}

export const unityAds = new UnityAdsService();
